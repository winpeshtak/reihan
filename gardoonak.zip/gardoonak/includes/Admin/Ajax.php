<?php
namespace Gardoonak\Admin;

defined( 'ABSPATH' ) || exit;

class Ajax {

    public function __construct() {
        add_action( 'wp_ajax_gardoonak_save_settings', [ $this, 'save_general_settings' ] );
        add_action( 'wp_ajax_gardoonak_save_wheel', [ $this, 'save_wheel_data' ] );
    }

    /**
     * ذخیره تنظیمات عمومی (فرم تب‌ها)
     */
    public function save_general_settings() {
        check_ajax_referer( 'gardoonak_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }

        // دریافت تمام داده‌های فرم
        $form_data = isset( $_POST['form_data'] ) ? $_POST['form_data'] : [];
        
        // تبدیل رشته سریالایز شده به آرایه
        parse_str( $form_data, $settings );

        // ذخیره تک تک تنظیمات در wp_options با پیشوند gardoonak_
        foreach ( $settings as $key => $value ) {
            // اعتبارسنجی ساده
            $clean_value = is_array( $value ) ? array_map( 'sanitize_text_field', $value ) : sanitize_text_field( $value );
            // اگر html نیاز دارد (مثل ایمیل بادی) از wp_kses استفاده کنید، فعلا ساده ذخیره میکنیم
            if( $key === 'email_body' ) {
                $clean_value = wp_kses_post( $value );
            }
            
            update_option( "gardoonak_{$key}", $clean_value );
        }

        wp_send_json_success( [ 'message' => 'تنظیمات با موفقیت ذخیره شد.' ] );
    }

    /**
     * ذخیره و بروزرسانی گردونه و پره‌ها
     */
    public function save_wheel_data() {
        check_ajax_referer( 'gardoonak_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }

        global $wpdb;
        $wheels_table = $wpdb->prefix . 'gardoonak_wheels';
        $slices_table = $wpdb->prefix . 'gardoonak_slices';

        $wheel_config = isset( $_POST['wheel_config'] ) ? $_POST['wheel_config'] : [];
        $slices       = isset( $_POST['slices'] ) ? $_POST['slices'] : [];

        // ۱. ذخیره یا آپدیت خود گردونه (فعلا فرض میکنیم فقط یک گردونه اصلی داریم با ID=1)
        // در فازهای بعدی می‌توانیم سیستم چند گردونه‌ای را تکمیل کنیم
        $wheel_data = [
            'title'      => 'گردونه اصلی',
            'settings'   => json_encode( $wheel_config ), // تنظیمات فیزیک چرخش
            'status'     => 'active',
            'created_at' => current_time( 'mysql' )
        ];

        // بررسی وجود گردونه
        $existing = $wpdb->get_var( "SELECT id FROM $wheels_table WHERE id = 1" );

        if ( $existing ) {
            $wpdb->update( $wheels_table, $wheel_data, [ 'id' => 1 ] );
            $wheel_id = 1;
        } else {
            $wpdb->insert( $wheels_table, $wheel_data );
            $wheel_id = $wpdb->insert_id;
        }

        // ۲. حذف پره‌های قبلی و ذخیره پره‌های جدید
        $wpdb->delete( $slices_table, [ 'wheel_id' => $wheel_id ] );

        foreach ( $slices as $slice ) {
            $wpdb->insert( $slices_table, [
                'wheel_id'    => $wheel_id,
                'label'       => sanitize_text_field( $slice['label'] ),
                'prize_type'  => sanitize_text_field( $slice['type'] ),
                'prize_value' => sanitize_text_field( $slice['code'] ),
                'probability' => intval( $slice['chance'] ),
                'slice_color' => sanitize_hex_color( $slice['color'] )
            ] );
        }

        wp_send_json_success( [ 'message' => 'گردونه و جوایز با موفقیت ذخیره شدند.' ] );
    }
}