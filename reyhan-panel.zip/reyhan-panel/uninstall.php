<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

$options_to_delete = [
    'reyhan_options',
    'reyhan_license_key',
    'reyhan_license_status',
    'reyhan_do_activation_redirect',
    'reyhan_heavy_panel_menu_structure',
    'reyhan_heavy_ticket_faqs',
    'reyhan_heavy_ticket_support_agents_data',
    'reyhan_heavy_global_notifications_json'
];

foreach ( $options_to_delete as $option_name ) {
    delete_option( $option_name );
}

global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_rp_%' OR option_name LIKE '_transient_timeout_rp_%'" );