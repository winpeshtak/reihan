/* assets/js/admin/app.js */

(function ($) {
    'use strict';

    const GardoonakAdmin = {
        init: function () {
            this.initColorPicker();
            this.handleGlobalModal();
            this.handleWheelBuilder();
        },

        initColorPicker: function () {
            // فعال سازی کالر پیکر برای المان‌های موجود و آینده
            $(document.body).on('focus', '.slice-color', function () {
                if (!$(this).hasClass('wp-color-picker')) {
                    $(this).wpColorPicker({
                        change: function (event, ui) {
                            $(this).trigger('change'); // تریگر کردن تغییر برای آپدیت ویژوال
                        }
                    });
                }
            });
        },

        // --- مدیریت مودال لیست ---
        handleGlobalModal: function () {
            const self = this;
            const $backdrop = $('#gn_global_modal');

            $(document).on('click', '#gn_trigger_list_modal', function (e) {
                e.preventDefault();
                $backdrop.addClass('open');
                self.fetchWheelsList();
            });

            $(document).on('click', '#gn_close_modal, .gn-glass-backdrop', function (e) {
                if (e.target !== this && !$(e.target).closest('#gn_close_modal').length) return;
                $backdrop.removeClass('open');
            });

            this.fetchWheelsList = function () {
                $('#gn_modal_body_content').html('<p style="padding:20px; text-align:center;">در حال بارگذاری...</p>');
                $.ajax({
                    url: gardoonak_ajax.url,
                    type: 'POST',
                    data: { action: 'gardoonak_get_wheels', security: gardoonak_ajax.nonce },
                    success: function (res) {
                        if (res.success && res.data.length > 0) {
                            let html = '<div class="gn-grid-wrapper">';
                            res.data.forEach(w => {
                                html += `
                                <div class="gn-glass-card">
                                    <h4>${w.title}</h4>
                                    <div class="gn-card-actions">
                                        <button class="gn-btn-outline load-wheel-data" data-id="${w.id}">ویرایش</button>
                                        <button class="gn-btn-outline delete-wheel-data" data-id="${w.id}" style="color:red">حذف</button>
                                    </div>
                                </div>`;
                            });
                            html += '</div>';
                            $('#gn_modal_body_content').html(html);
                        } else {
                            $('#gn_modal_body_content').html('<p style="padding:20px;">هنوز گردونه‌ای نساخته‌اید.</p>');
                        }
                    }
                });
            };

            $(document).on('click', '.load-wheel-data', function (e) {
                e.preventDefault();
                self.loadWheelToBuilder($(this).data('id'));
                $backdrop.removeClass('open');
            });

            $(document).on('click', '.delete-wheel-data', function (e) {
                if (!confirm('حذف شود؟')) return;
                const id = $(this).data('id');
                $.ajax({
                    url: gardoonak_ajax.url,
                    type: 'POST',
                    data: { action: 'gardoonak_delete_wheel', security: gardoonak_ajax.nonce, id: id },
                    success: function () { self.fetchWheelsList(); }
                });
            });
        },

        loadWheelToBuilder: function (id) {
            const self = this;
            $.ajax({
                url: gardoonak_ajax.url,
                type: 'POST',
                data: { action: 'gardoonak_get_wheel_data', security: gardoonak_ajax.nonce, id: id },
                success: function (res) {
                    if (res.success) {
                        const w = res.data.wheel;
                        const slices = res.data.slices;

                        $('#gn_wheel_id_input').val(w.id);
                        $('#gn_wheel_title_input').val(w.title);

                        // تنظیمات JSON
                        try {
                            const sets = typeof w.settings === 'string' ? JSON.parse(w.settings) : w.settings;
                            if (sets) {
                                $('#wheel_spin_count').val(sets.spin || 8);
                                $('#wheel_spin_duration').val(sets.duration || 5);
                                $('#gn_campaign_name').val(sets.campaign_name || '');
                            }
                        } catch (e) { }

                        $('#gn_slices_container').empty();
                        slices.forEach((s, i) => {
                            // پارس کردن مقادیر خاص از دیتابیس
                            // فرض میکنیم در prize_value مقادیر JSON ذخیره شده باشند یا ساده
                            let actionData = {};
                            try { actionData = JSON.parse(s.prize_value); } catch (e) { actionData = { val: s.prize_value }; }

                            self.createSliceDOM(i, {
                                label: s.label,
                                color: s.slice_color,
                                type: s.prize_type, // win, loss
                                chance: s.probability,
                                img: actionData.img || '',
                                actionType: actionData.action_type || 'coupon',
                                couponMode: actionData.coupon_mode || 'manual',
                                val: actionData.val || '',
                            });
                        });
                        self.updateWheelVisuals();
                    }
                }
            });
        },

        // --- لاجیک بیلدر ---
        handleWheelBuilder: function () {
            const self = this;
            const $container = $('#gn_slices_container');

            // 1. ساختن پره جدید
            this.createSliceDOM = function (index, data = {}) {
                const defaults = {
                    label: 'آیتم جدید',
                    color: self.getRandomColor(),
                    type: 'win',
                    chance: 10,
                    img: '',
                    actionType: 'coupon',
                    couponMode: 'manual',
                    val: ''
                };
                const config = { ...defaults, ...data };

                let template = $('#gn_slice_template').html();
                template = template.replace(/{INDEX}/g, index); // جایگزینی ایندکس برای نام رادیو باتن‌ها

                const $el = $(template);
                $container.append($el);

                // مقداردهی اولیه فیلدها
                $el.find('.slice-label').val(config.label);
                $el.find('.slice-color').val(config.color);
                $el.find('.slice-chance').val(config.chance);

                $el.find(`.gn-color-circle[data-color="${config.color}"]`).addClass('active');

                // تصویر
                if (config.img) {
                    $el.find('.slice-img-url').val(config.img);
                    $el.find('.slice-img-preview').css('background-image', `url(${config.img})`).html('');
                    $el.find('.gn-slice-thumb-preview').css('background-image', `url(${config.img})`);
                }

                // نوع پره (برد/باخت)
                $el.find(`input[value="${config.type}"]`).prop('checked', true);

                // نوع اکشن (لینک/کد)
                $el.find('.slice-action-type').val(config.actionType);
                $el.find('.slice-coupon-mode').val(config.couponMode);

                if (config.actionType === 'link') $el.find('.slice-link-val').val(config.val);
                else $el.find('.slice-coupon-val').val(config.val);

                // تریگر کردن منطق نمایش/مخفی
                self.updateSliceLogic($el);

                // فعال سازی کالر پیکر
                $el.find('.slice-color').wpColorPicker({
                    change: function () { self.updateWheelVisuals(); }
                });
            };

            // 2. منطق شرطی (نمایش فیلدها)
            this.updateSliceLogic = function ($el) {
                const type = $el.find('.slice-type:checked').val(); // win or loss
                const actionType = $el.find('.slice-action-type').val(); // coupon or link
                const couponMode = $el.find('.slice-coupon-mode').val(); // manual or auto

                if (type === 'loss') {
                    $el.find('.gn-win-options').hide();
                    $el.find('.gn-loss-options').show();
                    $el.addClass('is-loss');
                } else {
                    $el.find('.gn-win-options').show();
                    $el.find('.gn-loss-options').hide();
                    $el.removeClass('is-loss');

                    // مدیریت لینک و کوپن
                    if (actionType === 'link') {
                        $el.find('.gn-action-coupon-box').hide();
                        $el.find('.gn-action-link-box').show();
                    } else {
                        $el.find('.gn-action-coupon-box').show();
                        $el.find('.gn-action-link-box').hide();

                        if (couponMode === 'auto') {
                            $el.find('.slice-coupon-val').hide();
                            $el.find('.gn-coupon-auto-hint').show();
                        } else {
                            $el.find('.slice-coupon-val').show();
                            $el.find('.gn-coupon-auto-hint').hide();
                        }
                    }
                }
            };

            // 3. ایونت لیسنرها
            $container.on('change', 'input, select', function () {
                const $row = $(this).closest('.gn-slice-item');
                self.updateSliceLogic($row);
                self.updateWheelVisuals();
            });

            // باز و بسته کردن آکاردئون
            $container.on('click', '.gn-slice-header', function (e) {
                if ($(e.target).hasClass('gn-slice-remove') || $(e.target).hasClass('dashicons-trash')) return;
                $(this).next('.gn-slice-body').slideToggle(200);
                $(this).find('.gn-slice-toggle-icon').toggleClass('dashicons-arrow-up-alt2 dashicons-arrow-down-alt2');
            });

            // حذف آیتم
            $container.on('click', '.gn-slice-remove', function () {
                if (confirm('حذف شود؟')) {
                    $(this).closest('.gn-slice-item').slideUp(200, function () { $(this).remove(); self.updateWheelVisuals(); });
                }
            });

            // 1. مدیریت کلیک روی دایره‌های رنگی (جدید)
            $container.on('click', '.gn-color-circle', function () {
                const $parent = $(this).closest('.gn-color-selector-box');
                const color = $(this).data('color');

                // مدیریت کلاس active
                $parent.find('.gn-color-circle').removeClass('active');
                $(this).addClass('active');

                // ذخیره در اینپوت مخفی و تریگر تغییر برای آپدیت گردونه
                $parent.next('.slice-color').val(color).trigger('change');
            });

            // 2. آپدیت بخش مدیا آپلودر برای کلاس جدید (gn-upload-box-large)
            $container.on('click', '.gn-upload-box-large', function (e) {
                e.preventDefault();
                const $btn = $(this);

                // استفاده از همان آبجکت مدیا که در فایل وجود دارد
                const frame = wp.media({
                    title: 'انتخاب تصویر آیتم',
                    button: { text: 'استفاده از این تصویر' },
                    multiple: false
                });

                frame.on('select', function () {
                    const attachment = frame.state().get('selection').first().toJSON();
                    $btn.find('.slice-img-url').val(attachment.url);
                    // نمایش پیش‌نمایش در باکس بزرگ
                    $btn.find('.slice-img-preview').css('background-image', `url(${attachment.url})`).html('');

                    // تریگر برای آپدیت گرافیک گردونه
                    self.updateWheelVisuals();
                });

                frame.open();
            });

            // افزودن آیتم جدید
            $('#gn_add_slice_btn').on('click', function () {
                self.createSliceDOM($container.children().length);
                self.updateWheelVisuals();
            });

            // 4. مدیا آپلودر وردپرس
            $container.on('click', '.gn-upload-box-mini', function (e) {
                e.preventDefault();
                const $btn = $(this);

                const frame = wp.media({
                    title: 'انتخاب تصویر آیتم',
                    button: { text: 'استفاده از این تصویر' },
                    multiple: false
                });

                frame.on('select', function () {
                    const attachment = frame.state().get('selection').first().toJSON();
                    $btn.find('.slice-img-url').val(attachment.url);
                    $btn.find('.slice-img-preview').css('background-image', `url(${attachment.url})`).html('');
                    // آپدیت تامنیل هدر
                    $btn.closest('.gn-slice-item').find('.gn-slice-thumb-preview').css('background-image', `url(${attachment.url})`);
                    self.updateWheelVisuals();
                });

                frame.open();
            });

            // 5. رسم گرافیکی گردونه
            this.updateWheelVisuals = function () {
                const $preview = $('#gn_live_wheel');
                $preview.empty(); // پاک کردن قبلی‌ها

                let slices = [];
                $container.find('.gn-slice-item').each(function () {
                    slices.push({
                        label: $(this).find('.slice-label').val(),
                        color: $(this).find('.slice-color').val(),
                        img: $(this).find('.slice-img-url').val()
                    });
                });

                if (slices.length === 0) {
                    $preview.css('background', '#eee'); return;
                }

                // رسم گرادینت پس‌زمینه
                let parts = [];
                const deg = 360 / slices.length;
                slices.forEach((s, i) => {
                    parts.push(`${s.color} ${i * deg}deg ${(i + 1) * deg}deg`);
                });
                $preview.css('background', `conic-gradient(${parts.join(', ')})`);

                // قرار دادن متن و آیکون روی گردونه
                slices.forEach((s, i) => {
                    const rotation = (i * deg) + (deg / 2); // وسط هر قاچ
                    const itemHtml = `
                        <div class="gn-wheel-element" style="position:absolute; top:50%; left:50%; transform:translate(-50%, -50%) rotate(${rotation}deg); height:140px; transform-origin:center; pointer-events:none; display:flex; flex-direction:column; align-items:center; justify-content:flex-start; padding-top:20px;">
                            <div style="transform:translateY(-140px) rotate(0deg); text-align:center;">
                                ${s.img ? `<img src="${s.img}" style="width:30px; height:30px; display:block; margin:0 auto 5px;">` : ''}
                                <span style="color:#fff; font-size:10px; font-weight:bold; text-shadow:0 1px 2px rgba(0,0,0,0.5); display:block; max-width:60px; word-wrap:break-word;">${s.label}</span>
                            </div>
                        </div>
                    `;
                    $preview.append(itemHtml);
                });
            };

            // چرخش تستی
            $('#gn_test_spin').on('click', function () {
                const $wheel = $('#gn_live_wheel');
                const duration = $('#wheel_spin_duration').val() || 5;
                $wheel.css('transition', `transform ${duration}s cubic-bezier(0.17, 0.67, 0.12, 0.99)`);
                $wheel.css('transform', `rotate(${360 * 5 + Math.random() * 360}deg)`);
                setTimeout(() => { $wheel.css('transition', 'none').css('transform', 'rotate(0deg)'); }, duration * 1000 + 500);
            });

            // 6. ذخیره نهایی
            $('#gn_save_wheel_btn').on('click', function (e) {
                e.preventDefault();
                const $btn = $(this);
                const title = $('#gn_wheel_title_input').val();

                if (!title) { alert('عنوان گردونه الزامی است.'); return; }

                // جمع‌آوری دیتا
                let slices = [];
                $container.find('.gn-slice-item').each(function () {
                    const type = $(this).find('.slice-type:checked').val();
                    const actionType = $(this).find('.slice-action-type').val();
                    const val = (actionType === 'link') ? $(this).find('.slice-link-val').val() : $(this).find('.slice-coupon-val').val();

                    // پک کردن دیتای پیچیده در prize_value به صورت JSON
                    const complexValue = JSON.stringify({
                        img: $(this).find('.slice-img-url').val(),
                        action_type: actionType,
                        coupon_mode: $(this).find('.slice-coupon-mode').val(),
                        val: val
                    });

                    slices.push({
                        label: $(this).find('.slice-label').val(),
                        color: $(this).find('.slice-color').val(),
                        type: type, // win / loss
                        probability: $(this).find('.slice-chance').val(),
                        prize_value: complexValue // ذخیره همه تنظیمات در این فیلد
                    });
                });

                $btn.text('در حال ذخیره...').prop('disabled', true);

                $.ajax({
                    url: gardoonak_ajax.url,
                    type: 'POST',
                    data: {
                        action: 'gardoonak_save_wheel',
                        security: gardoonak_ajax.nonce,
                        wheel_id: $('#gn_wheel_id_input').val(),
                        wheel_title: title,
                        wheel_config: {
                            campaign_name: $('#gn_campaign_name').val(),
                            spin: $('#wheel_spin_count').val(),
                            duration: $('#wheel_spin_duration').val()
                        },
                        slices: slices
                    },
                    success: function (res) {
                        alert(res.success ? 'ذخیره شد.' : 'خطا!');
                        if (res.success && res.data.id) $('#gn_wheel_id_input').val(res.data.id);
                    },
                    complete: function () { $btn.text('ذخیره و انتشار گردونه').prop('disabled', false); }
                });
            });

            // شروع اولیه اگر گردونه خالی است
            if ($('#gn_wheel_id_input').val() == '0' && $container.children().length === 0) {
                self.createSliceDOM(0, { label: 'شانس ۱', color: '#ff4757' });
                self.createSliceDOM(1, { label: 'شانس ۲', color: '#2ecc71' });
                self.updateWheelVisuals();
            }
        },

        getRandomColor: function () {
            return '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
        },


    };

    $(document).ready(function () { GardoonakAdmin.init(); });

})(jQuery);