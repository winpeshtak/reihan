jQuery(document).ready(function ($) {
    const $triggerBtn = $('#gn_trigger_btn');
    const displayMode = gardoonak_vars.display_delay || 'fast';

    // تابع نمایش دکمه با انیمیشن ورود
    const showButton = () => {
        $triggerBtn.css({
            'display': 'flex',
            'opacity': '0',
            'transform': 'scale(0.5)'
        }).animate({
            'opacity': '1'
        }, 400);
        // بازگشت به حالت Scale اصلی از طریق CSS (برای حفظ انیمیشن Pulse)
        setTimeout(() => $triggerBtn.css('transform', ''), 450);
    };

    // ۱. منطق نمایش بر اساس بهینه‌سازی مهندس جان
    if (displayMode === 'fast') {
        // نمایش سریع
        showButton();
    } else {
        // حالت بهینه: صبر برای لود کامل صفحه + ۲ ثانیه تاخیر برای عدم تداخل با لودینگ سایت
        $(window).on('load', function () {
            setTimeout(showButton, 2000);
        });
    }

    // ۲. مدیریت باز و بسته شدن مودال (کدهای قبلی)
    $triggerBtn.on('click', function () {
        $('#gn_wheel_modal').addClass('open');
        $('body').css('overflow', 'hidden');
    });

    $('#gn_close_wheel, #gn_wheel_modal').on('click', function (e) {
        if (e.target !== this && !$(e.target).hasClass('gn-close-popup')) return;
        $('#gn_wheel_modal').removeClass('open');
        $('body').css('overflow', 'auto');
    });
});

jQuery(document).ready(function ($) {
    const $modal = $('#gn_wheel_modal');
    let isTriggered = false; // جلوگیری از نمایش چندباره در یک لود صفحه

    const openWheel = () => {
        if (isTriggered) return;
        isTriggered = true;
        $modal.addClass('open');
        $('body').css('overflow', 'hidden');
    };

    // ۱. منطق قصد خروج (Exit Intent) مهندس جان
    if (gardoonak_vars.trigger_exit === '1') {
        $(document).on('mouseleave', function (e) {
            if (e.clientY < 0) openWheel(); // اگر موس به سمت نوار ابزار بالا برود
        });
    }

    // ۲. منطق زمان حضور
    if (gardoonak_vars.trigger_time === '1') {
        const delay = parseInt(gardoonak_vars.trigger_time_value || 10) * 1000;
        setTimeout(openWheel, delay);
    }

    // ۳. منطق میزان اسکرول
    if (gardoonak_vars.trigger_scroll === '1') {
        const targetPercent = parseInt(gardoonak_vars.trigger_scroll_value || 50);
        $(window).on('scroll', function () {
            const scrollPos = $(window).scrollTop();
            const winHeight = $(window).height();
            const docHeight = $(document).height();
            const scrollPercent = (scrollPos / (docHeight - winHeight)) * 100;

            if (scrollPercent >= targetPercent) openWheel();
        });
    }
});

jQuery(document).ready(function ($) {
    const $spinBtn = $('#gn_start_spin');
    const audioPath = gardoonak_vars.audio_url;

    // تعریف آبجکت‌های صوتی مهندس جان
    const sndSpin = new Audio(audioPath + 'spin.mp3');
    const sndWin = new Audio(audioPath + 'win.mp3');
    const sndLost = new Audio(audioPath + 'lost.mp3');

    // ۱. بررسی سیستم ضد اسپم واقعی
    const checkSpamStatus = () => {
        const lastSpin = localStorage.getItem('gn_last_spin_time');
        if (lastSpin) {
            const hoursPassed = (Date.now() - lastSpin) / (1000 * 60 * 60);
            if (hoursPassed < parseInt(gardoonak_vars.spam_limit)) {
                return false; // بلاک است
            }
        }
        return true;
    };

    $spinBtn.on('click', function () {
        // الف) چک کردن محدودیت زمانی
        if (!checkSpamStatus()) {
            alert('مهندس جان، شما قبلاً شانس خود را امتحان کرده‌اید. لطفاً ' + gardoonak_vars.spam_limit + ' ساعت دیگر مراجعه کنید.');
            return;
        }

        // ب) شروع چرخش و پخش صدا
        if (gardoonak_vars.sound_spin === '1') {
            sndSpin.loop = true;
            sndSpin.play();
        }

        // منطق چرخش گردونه (در اینجا شبیه‌سازی شده برای تست شما)
        setTimeout(() => {
            sndSpin.pause();
            sndSpin.currentTime = 0;

            const isWinner = true; // این مقدار از سمت سرور می‌آید

            // ج) پخش صدای نتیجه
            if (gardoonak_vars.sound_result === '1') {
                if (isWinner) sndWin.play();
                else sndLost.play();
            }

            // د) افکت انفجار شادی (Confetti)
            if (isWinner && gardoonak_vars.confetti === '1') {
                triggerConfettiEffect();
            }

            // ه) ثبت زمان بازی برای جلوگیری از اسپم مجدد
            localStorage.setItem('gn_last_spin_time', Date.now());

        }, 4000);
    });

    // تابع افکت انفجاری مهندس جان
    function triggerConfettiEffect() {
        // استفاده از یک کتابخانه سبک یا افکت CSS ساده برای پخش پره‌های رنگی
        $('body').append('<div class="gn-confetti-wrapper"></div>');
        // در پروژه‌های تجاری معمولاً از کتابخانه canvas-confetti استفاده می‌شود
        console.log("افکت انفجار شادی با موفقیت اجرا شد.");
    }
});

jQuery(document).ready(function ($) {
    const $modal = $('#gn_wheel_modal');
    const $formSection = $('.gn-form-section'); // بخش فرم اطلاعات
    const $wheelSection = $('.gn-wheel-section'); // بخش گردونه
    const $spinBtn = $('#gn_start_spin');

    const timing = gardoonak_vars.data_collection_timing; // قبل یا بعد از بازی

    // تابع مدیریت نمایش اولیه مهندس جان
    const initDisplayMode = () => {
        if (timing === 'before') {
            // حالت قبل از بازی: فرم باز باشد، دکمه چرخش قفل یا مخفی
            $formSection.show();
            $wheelSection.addClass('gn-blur-lock'); // گردونه تار و غیرفعال باشد
            $spinBtn.text('ثبت اطلاعات و شروع بازی');
        } else {
            // حالت بعد از بازی: گردونه آزاد باشد، فرم مخفی
            $formSection.hide();
            $wheelSection.removeClass('gn-blur-lock');
            $spinBtn.text('بچرخون و برنده شو!');
        }
    };

    // اجرای تنظیمات اولیه لود صفحه
    initDisplayMode();

    // رویداد کلیک اصلی دکمه مهندس جان
    $spinBtn.on('click', function () {
        if (timing === 'before' && !$formSection.hasClass('is-submitted')) {
            // ۱. اعتبارسنجی و ثبت فرم قبل از بازی
            if (validateLeadForm()) {
                submitLeadData(() => {
                    // بعد از تایید اطلاعات، گردونه آزاد شود
                    $formSection.fadeOut(300, () => {
                        $wheelSection.removeClass('gn-blur-lock');
                        $formSection.addClass('is-submitted');
                        startSpinningProcess(); // تابع چرخش واقعی که قبلا نوشتیم
                    });
                });
            }
        } else if (timing === 'after') {
            // ۲. چرخش مستقیم و نمایش فرم در انتها
            startSpinningProcess(() => {
                // این کالبک وقتی اجرا می‌شود که گردونه بایستد
                setTimeout(() => {
                    $wheelSection.addClass('gn-blur-lock');
                    $formSection.fadeIn(400);
                    $spinBtn.text('دریافت جایزه و ثبت نهایی');
                    // تغییر منطق دکمه برای مرحله دوم
                    gardoonak_vars.data_collection_timing = 'submit_after';
                }, 1000);
            });
        }
    });

    // تابع اعتبارسنجی فیلدهای انتخابی مهندس جان
    function validateLeadForm() {
        let isValid = true;
        let errors = [];

        // ۱. چک کردن فیلد نام (اگر فعال باشد)
        if (gardoonak_vars.field_name_enable === '1') {
            if ($('#gn_user_name').val().trim() === '') {
                isValid = false;
                errors.push('لطفاً نام خود را وارد کنید.');
            }
        }

        // ۲. چک کردن فیلد ایمیل (اگر فعال باشد)
        if (gardoonak_vars.field_email_enable === '1') {
            const email = $('#gn_user_email').val().trim();
            if (email === '' || !email.includes('@')) {
                isValid = false;
                errors.push('لطفاً یک ایمیل معتبر وارد کنید.');
            }
        }

        // ۳. چک کردن فیلد موبایل (اگر فعال باشد)
        if (gardoonak_vars.field_phone_enable === '1') {
            const phone = $('#gn_user_phone').val().trim();
            if (phone.length < 11) {
                isValid = false;
                errors.push('لطفاً شماره موبایل صحیح وارد کنید.');
            }
        }

        if (!isValid) {
            alert("مهندس جان! \n" + errors.join("\n"));
        }
        return isValid;
    }
});