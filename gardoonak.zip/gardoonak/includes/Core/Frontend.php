<?php
namespace Gardoonak\Core;

defined( 'ABSPATH' ) || exit;

class Frontend {

    public function __construct() {
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend_assets' ] );
        add_action( 'wp_footer', [ $this, 'render_wheel_popup' ] );
    }

    /**
     * بررسی هوشمند شرایط نمایش مهندس جان
     */
    private function should_render_floating_system() {
        // ۱. بررسی فعال بودن کلی دکمه شناور
        if ( get_option( 'gardoonak_enable_floating_btn', '1' ) !== '1' ) {
            return false;
        }

        // ۲. بررسی هدف‌گیری مخاطبان
        $audience = get_option( 'gardoonak_target_audience', 'all' );
        $is_logged_in = is_user_logged_in();
        if ( $audience === 'guests' && $is_logged_in ) return false;
        if ( $audience === 'logged_in' && ! $is_logged_in ) return false;

        // ۳. منطق جدید نمایش در صفحات مهندس جان
        $pages_ids = get_option( 'gardoonak_specific_pages_ids', '' );
        
        // اگر "تمام صفحات" انتخاب نشده باشد و فیلد هم خالی نباشد، بررسی شناسه‌ها انجام شود
        if ( ! empty( $pages_ids ) && $pages_ids !== 'all_pages' ) {
            $ids_array = explode( ',', $pages_ids );
            if ( ! is_page( $ids_array ) ) {
                return false;
            }
        } 
        // نکته: اگر مقدار برابر 'all_pages' باشد یا کلا خالی باشد، در تمام صفحات نمایش داده می‌شود

        // ۴. بررسی دستگاه کاربر (دسکتاپ/تبلت/موبایل)
        $is_mobile_wp = wp_is_mobile();
        $user_agent   = strtolower($_SERVER['HTTP_USER_AGENT']);

        if ( ! $is_mobile_wp ) {
            if ( get_option( 'gardoonak_device_desktop', '1' ) !== '1' ) return false;
        } else {
            $is_tablet = (strpos($user_agent, 'tablet') !== false || strpos($user_agent, 'ipad') !== false || (strpos($user_agent, 'android') !== false && strpos($user_agent, 'mobile') === false));
            if ( $is_tablet ) {
                if ( get_option( 'gardoonak_device_tablet', '1' ) !== '1' ) return false;
            } else {
                if ( get_option( 'gardoonak_device_mobile', '1' ) !== '1' ) return false;
            }
        }

        return true;
    }

    public function enqueue_frontend_assets() {
        if ( ! $this->should_render_floating_system() ) return;

        wp_enqueue_style( 'gardoonak-frontend', GARDOONAK_URL . 'assets/css/frontend/wheel.css', [], GARDOONAK_VERSION );
        wp_enqueue_script( 'gardoonak-frontend-js', GARDOONAK_URL . 'assets/js/frontend/frontend.js', ['jquery'], GARDOONAK_VERSION, true );
        
        wp_localize_script( 'gardoonak-frontend-js', 'gardoonak_vars', [
            'ajax_url'               => admin_url( 'admin-ajax.php' ),
            'nonce'                  => wp_create_nonce( 'gardoonak_frontend_nonce' ),
            'data_collection_timing' => get_option( 'gardoonak_data_collection_timing', 'before' ),
            'field_name_enable'      => get_option( 'gardoonak_field_name_enable', '1' ),
            'field_email_enable'     => get_option( 'gardoonak_field_email_enable', '1' ),
            'field_phone_enable'     => get_option( 'gardoonak_field_phone_enable', '1' ),
            'audio_url'      => GARDOONAK_URL . 'assets/audio/',
            'confetti'       => get_option('gardoonak_effect_confetti', '1'),
            'sound_spin'     => get_option('gardoonak_sound_spin', '1'),
            'sound_result'   => get_option('gardoonak_sound_result', '1'),
            'spam_limit'     => get_option('gardoonak_cookie_expiry', '24'),
            'display_delay' => get_option( 'gardoonak_display_delay', 'fast' ),
            'trigger_exit'         => get_option('gardoonak_trigger_exit', '1'),
            'trigger_time'         => get_option('gardoonak_trigger_time', '0'),
            'trigger_time_value'   => get_option('gardoonak_trigger_time_value', '10'),
            'trigger_scroll'       => get_option('gardoonak_trigger_scroll', '0'),
            'trigger_scroll_value' => get_option('gardoonak_trigger_scroll_value', '50'),
        ]);
    }

    public function render_wheel_popup() {
        if ( ! $this->should_render_floating_system() ) return;

        // ۱. دریافت تنظیمات مهندس جان
        $selected_theme  = get_option('gardoonak_wheel_theme', '1');
        $theme_class     = 'gn-theme-' . $selected_theme;
        $cta_text        = get_option('gardoonak_cta_button_text', 'شانست رو امتحان کن!');
        $cta_show_text   = get_option('gardoonak_cta_show_text', '1');
        $selected_pointer = get_option('gardoonak_pointer_style', 'pointer-default');
        
        $pointer_url = GARDOONAK_URL . "assets/images/SVG/pointers/{$selected_pointer}.svg";
        $float_icon  = GARDOONAK_URL . 'assets/images/SVG/float-default.svg';
        ?>

        <div class="gn-floating-trigger" id="gn_trigger_btn">
            <div class="gn-trigger-content" style="display: flex; align-items: center; gap: 10px;">
                <?php if ( $cta_show_text === '1' ) : ?>
                    <span class="gn-trigger-text" style="font-weight: bold; padding: 0 5px;"><?php echo esc_html($cta_text); ?></span>
                <?php endif; ?>
                <img src="<?php echo esc_url( $float_icon ); ?>" alt="گردونه شانس">
            </div>
        </div>

        <div class="gn-frontend-overlay" id="gn_wheel_modal">
            <div class="gn-popup-card <?php echo esc_attr($theme_class); ?>">
                <div class="gn-close-popup" id="gn_close_wheel">&times;</div>
                
                <div class="gn-form-section">
                    <h2>شانست رو امتحان کن!</h2>
                    <p>اطلاعاتت رو وارد کن و برنده جوایز ما باش.</p>
                    
                    <?php if ( get_option('gardoonak_field_name_enable', '1') === '1' ) : ?>
                        <div class="gn-field-group">
                            <input type="text" id="gn_user_name" class="gn-input-field" placeholder="نام و نام خانوادگی">
                        </div>
                    <?php endif; ?>

                    <?php if ( get_option('gardoonak_field_email_enable', '1') === '1' ) : ?>
                        <div class="gn-field-group">
                            <input type="email" id="gn_user_email" class="gn-input-field" placeholder="آدرس ایمیل" style="direction: ltr;">
                        </div>
                    <?php endif; ?>

                    <?php if ( get_option('gardoonak_field_phone_enable', '1') === '1' ) : ?>
                        <div class="gn-field-group">
                            <input type="tel" id="gn_user_phone" class="gn-input-field" placeholder="شماره موبایل" style="direction: ltr;">
                        </div>
                    <?php endif; ?>
                    
                    <button class="gn-spin-button" id="gn_start_spin">بچرخون و برنده شو!</button>
                </div>
                
                <div class="gn-wheel-section" style="position: relative;">
                    <div class="gardoonak-pointer">
                        <img src="<?php echo esc_url($pointer_url); ?>" alt="نشانگر گردونه" style="width: 60px; height: 60px;">
                    </div>
                    <canvas id="gardoonak-canvas" width="400" height="400"></canvas>
                </div>
            </div>
        </div>
        <?php
    }
}