<?php
namespace Gardoonak\Core;

defined( 'ABSPATH' ) || exit;

/**
 * سیستم بارگذاری خودکار کلاس‌ها (Autoloader)
 */
spl_autoload_register( function ( $class ) {
    // فقط کلاس‌هایی که با Gardoonak شروع می‌شوند را بررسی کن
    $prefix = 'Gardoonak\\';
    $base_dir = GARDOONAK_PATH . 'includes/';

    $len = strlen( $prefix );
    if ( strncmp( $prefix, $class, $len ) !== 0 ) {
        return;
    }

    $relative_class = substr( $class, $len );
    $file = $base_dir . str_replace( '\\', '/', $relative_class ) . '.php';

    if ( file_exists( $file ) ) {
        require $file;
    }
});