/* assets/js/admin/app.js */

(function ($) {
    'use strict';

    const GardoonakAdmin = {
        init: function () {
            this.handleTabs();
            this.handleSettingsForm();
            this.handleWheelBuilder();
            this.handleGlobalModal(); // <--- تابع جدید

            // سایر توابع (خالی یا موجود)
            this.handleTriggers();
            this.handleColorPicker();
        },

        // --- مدیریت پاپ‌آپ سراسری ---
        handleGlobalModal: function () {
            const self = this;
            const $modalBackdrop = $('#gn_global_modal');
            const $modalBody = $('#gn_modal_body_content');

            // 1. باز کردن مودال
            $('#gn_trigger_list_modal').on('click', function (e) {
                e.preventDefault();
                $modalBackdrop.addClass('open');
                self.fetchWheelsList(); // دریافت لیست
            });

            // 2. بستن مودال
            $('#gn_close_modal, .gn-modal-backdrop').on('click', function (e) {
                if (e.target !== this && e.target.id !== 'gn_close_modal' && !$(e.target).parent().is('#gn_close_modal')) return;
                $modalBackdrop.removeClass('open');
            });

            // 3. دریافت لیست از سرور
            this.fetchWheelsList = function () {
                $modalBody.html('<div style="text-align:center; padding:30px;"><span class="dashicons dashicons-update spin-anim"></span> در حال دریافت اطلاعات...</div>');

                $.ajax({
                    url: gardoonak_ajax.url,
                    type: 'POST',
                    data: { action: 'gardoonak_get_wheels', security: gardoonak_ajax.nonce },
                    success: function (res) {
                        if (res.success && res.data.length > 0) {
                            let html = '';
                            res.data.forEach(w => {
                                html += `
                                    <div class="gn-wheel-list-item">
                                        <div class="gn-wheel-info">
                                            <h4>${w.title}</h4>
                                            <div class="gn-wheel-meta">
                                                <span><span class="dashicons dashicons-calendar-alt" style="font-size:14px; vertical-align:middle;"></span> ${w.created_at}</span>
                                                <span class="gn-badge-code">[gardoonak id="${w.id}"]</span>
                                            </div>
                                        </div>
                                        <div class="gn-wheel-actions" style="display:flex; gap:10px;">
                                            <button type="button" class="gn-btn gn-btn-outline load-wheel-data" data-id="${w.id}" style="padding: 5px 15px !important; height: 35px !important; font-size:13px !important;">
                                                <span class="dashicons dashicons-edit"></span> ویرایش
                                            </button>
                                            <button type="button" class="gn-btn gn-btn-outline delete-wheel-data" data-id="${w.id}" style="padding: 5px 10px !important; height: 35px !important; border-color:#ef4444; color:#ef4444;">
                                                <span class="dashicons dashicons-trash"></span>
                                            </button>
                                        </div>
                                    </div>
                                `;
                            });
                            $modalBody.html(html);
                        } else {
                            $modalBody.html('<div style="text-align:center; padding:40px; color:#64748b;">هنوز هیچ گردونه‌ای نساخته‌اید.<br><br>پنجره را ببندید و شروع به ساخت کنید!</div>');
                        }
                    },
                    error: function () {
                        $modalBody.html('<div style="color:red; text-align:center;">خطا در ارتباط با سرور</div>');
                    }
                });
            };

            // 4. عملیات ویرایش (لود کردن دیتا در فرم اصلی)
            $modalBody.on('click', '.load-wheel-data', function () {
                const id = $(this).data('id');
                self.loadWheelToBuilder(id);
                $modalBackdrop.removeClass('open'); // بستن مودال
            });

            // 5. عملیات حذف
            $modalBody.on('click', '.delete-wheel-data', function () {
                if (confirm('آیا مطمئن هستید؟ حذف گردونه غیرقابل بازگشت است.')) {
                    const id = $(this).data('id');
                    $.ajax({
                        url: gardoonak_ajax.url,
                        type: 'POST',
                        data: { action: 'gardoonak_delete_wheel', security: gardoonak_ajax.nonce, id: id },
                        success: function (res) {
                            if (res.success) self.fetchWheelsList(); // رفرش لیست
                        }
                    });
                }
            });
        },

        // --- لود کردن اطلاعات گردونه در فرم سازنده ---
        loadWheelToBuilder: function (id) {
            const self = this;
            const $container = $('#gn_slices_container');

            // نمایش حالت لودینگ
            $('.gn-wheel-builder-container').css('opacity', '0.5');

            $.ajax({
                url: gardoonak_ajax.url,
                type: 'POST',
                data: { action: 'gardoonak_get_wheel_data', security: gardoonak_ajax.nonce, id: id },
                success: function (res) {
                    $('.gn-wheel-builder-container').css('opacity', '1');
                    if (res.success) {
                        const data = res.data;

                        // پر کردن فیلدها
                        $('#gn_wheel_id_input').val(data.wheel.id);
                        $('#gn_wheel_title_input').val(data.wheel.title);

                        // بازسازی پره‌ها
                        $container.empty();
                        if (data.slices && data.slices.length > 0) {
                            data.slices.forEach((slice, index) => {
                                // استفاده از منطق موجود برای ساخت پره
                                // ما اینجا دستی HTML تولید میکنیم چون تابع addSlice شما دیتای ورودی نمیگرفت
                                self.createSliceDOM(index, {
                                    label: slice.label,
                                    color: slice.slice_color,
                                    type: slice.prize_type,
                                    chance: slice.probability,
                                    code: slice.prize_value
                                });
                            });
                        }
                        self.updateWheelVisuals();
                        // اسکرول به بالا
                        $('html, body').animate({ scrollTop: $(".gn-card").offset().top - 50 }, 500);
                    }
                }
            });
        },

        // --- بیلدر گردونه (کدهای اصلی شما + اصلاحات جزئی) ---
        handleWheelBuilder: function () {
            const self = this;
            const $container = $('#gn_slices_container');
            const $preview = $('#gn_live_wheel');

            // تابع کمکی برای آپدیت گرافیک
            this.updateWheelVisuals = function () {
                let slices = [];
                $container.find('.gn-slice-item').each(function () {
                    slices.push({ color: $(this).find('.slice-color').val() || '#ccc' });
                });

                if (slices.length === 0) {
                    $preview.css('background', '#eee'); return;
                }

                let parts = [];
                const deg = 360 / slices.length;
                slices.forEach((s, i) => {
                    parts.push(`${s.color} ${i * deg}deg ${(i + 1) * deg}deg`);
                });
                $preview.css('background', `conic-gradient(${parts.join(', ')})`);
            };

            // تابع کمکی ساخت HTML پره (جدا شده برای استفاده در ویرایش)
            this.createSliceDOM = function (index, data = null) {
                const label = data ? data.label : `آیتم ${index + 1}`;
                const color = data ? data.color : self.getRandomColor();
                const chance = data ? data.chance : 10;
                const type = data ? data.type : 'win';
                const code = data ? data.code : '';

                const html = `
                    <div class="gn-slice-item" style="border:1px solid #eee; border-radius:8px; margin-bottom:10px; background:#fff; overflow:hidden;">
                        <div class="gn-slice-header" style="cursor:pointer; padding:10px 15px; background:#f8fafc; display:flex; justify-content:space-between;">
                            <span class="slice-title-txt" style="font-weight:bold;">${label}</span>
                            <span class="gn-slice-remove dashicons dashicons-trash" style="color:#ef4444;"></span>
                        </div>
                        <div class="gn-slice-body" style="padding:15px;">
                            <div style="margin-bottom:10px; display:flex; gap:10px;">
                                <input type="text" class="gn-input slice-label" value="${label}" placeholder="عنوان" style="flex:1;">
                                <input type="color" class="slice-color" value="${color}" style="height:42px; width:50px; padding:0; border:none; background:none;">
                            </div>
                            <div style="display:flex; gap:10px;">
                                <select class="gn-input slice-type" style="width:80px;"><option value="win" ${type === 'win' ? 'selected' : ''}>برد</option><option value="loss" ${type === 'loss' ? 'selected' : ''}>پوچ</option></select>
                                <input type="number" class="gn-input slice-chance" value="${chance}" placeholder="شانس %">
                                <input type="text" class="gn-input slice-code" value="${code}" placeholder="کد/متن">
                            </div>
                        </div>
                    </div>
                `;

                const $el = $(html);
                $container.append($el);

                // رویداد باز/بسته
                $el.find('.gn-slice-header').click(function (e) {
                    if (!$(e.target).hasClass('gn-slice-remove')) $(this).next().slideToggle(200);
                });
            };

            // دکمه افزودن
            $('#gn_add_slice_btn').on('click', function () {
                self.createSliceDOM($container.children().length);
                self.updateWheelVisuals();
            });

            // دکمه حذف
            $container.on('click', '.gn-slice-remove', function () {
                if (confirm('حذف شود؟')) { $(this).closest('.gn-slice-item').remove(); self.updateWheelVisuals(); }
            });

            // تغییرات زنده
            $container.on('input change', 'input, select', function () {
                self.updateWheelVisuals();
                if ($(this).hasClass('slice-label')) {
                    $(this).closest('.gn-slice-item').find('.slice-title-txt').text($(this).val());
                }
            });

            // ذخیره نهایی (Ajax)
            $('#gn_save_wheel_btn').on('click', function (e) {
                e.preventDefault();
                const $btn = $(this);
                const title = $('#gn_wheel_title_input').val();

                if (!title) { alert('لطفا یک عنوان برای گردونه بنویسید.'); return; }

                let slices = [];
                $container.find('.gn-slice-item').each(function () {
                    slices.push({
                        label: $(this).find('.slice-label').val(),
                        color: $(this).find('.slice-color').val(),
                        type: $(this).find('.slice-type').val(),
                        chance: $(this).find('.slice-chance').val(),
                        code: $(this).find('.slice-code').val()
                    });
                });

                if (slices.length < 2) { alert('حداقل ۲ پره لازم است.'); return; }

                $btn.prop('disabled', true).text('در حال ذخیره...');

                $.ajax({
                    url: gardoonak_ajax.url,
                    type: 'POST',
                    data: {
                        action: 'gardoonak_save_wheel',
                        security: gardoonak_ajax.nonce,
                        wheel_id: $('#gn_wheel_id_input').val(),
                        wheel_title: title,
                        wheel_config: { spin: $('#wheel_spin_count').val(), duration: $('#wheel_spin_duration').val() },
                        slices: slices
                    },
                    success: function (res) {
                        alert(res.success ? 'ذخیره شد' : 'خطا');
                        if (res.success && res.data.id) $('#gn_wheel_id_input').val(res.data.id);
                    },
                    complete: function () { $btn.prop('disabled', false).html('<span class="dashicons dashicons-saved"></span> ذخیره گردونه'); }
                });
            });

            // پیش‌فرض اگر خالی بود
            if ($container.children().length === 0) {
                this.createSliceDOM(0);
                this.createSliceDOM(1);
                this.updateWheelVisuals();
            }
        },

        getRandomColor: function () { return '#' + Math.floor(Math.random() * 16777215).toString(16); },

        // --- توابع عمومی (بدون تغییر) ---
        handleTabs: function () {
            $('.gn-tab-link').on('click', function (e) {
                e.preventDefault();
                $('.gn-tab-link').removeClass('active');
                $(this).addClass('active');
                const target = $(this).data('tab');
                $('.gn-tab-content').removeClass('active');
                $('#' + target).addClass('active');
            });
        },
        handleSettingsForm: function () {
            const $form = $('#gardoonak-settings-form');
            $('.gardoonak-sidebar-actions .gn-btn').on('click', function (e) {
                e.preventDefault(); $form.submit();
            });
            $form.on('submit', function (e) {
                e.preventDefault();
                const $btn = $('.gardoonak-sidebar-actions .gn-btn');
                $btn.prop('disabled', true).text('ذخیره...');
                $.ajax({
                    url: gardoonak_ajax.url, type: 'POST',
                    data: { action: 'gardoonak_save_settings', security: gardoonak_ajax.nonce, form_data: $form.serialize() },
                    success: function (res) { alert(res.success ? 'تنظیمات ذخیره شد' : 'خطا'); },
                    complete: function () { $btn.prop('disabled', false).text('ذخیره تغییرات'); }
                });
            });
        },
        handleTriggers: function () { }, handleColorPicker: function () { },
    };

    $(document).ready(function () { GardoonakAdmin.init(); });

})(jQuery);