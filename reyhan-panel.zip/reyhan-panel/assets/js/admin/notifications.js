jQuery(document).ready(function ($) {
    "use strict";

    var notifData = [];
    var editIndex = -1;
    const $notifJson = $('#rp_notif_data_json');
    const ajaxNonce = $('#rp_admin_nonce').val();

    // ۱. لود دیتا
    try {
        const rawData = $('#rp-notif-initial-data').val();
        notifData = JSON.parse(rawData || '[]');
    } catch (e) {
        notifData = [];
    }
    renderNotifGrid();

    function renderNotifGrid() {
        var html = '';
        if (notifData.length === 0) {
            $('#rp-notif-grid').hide();
            $('#rp-empty-state').fadeIn();
        } else {
            $('#rp-empty-state').hide();
            $('#rp-notif-grid').css('display', 'flex');
            
            $.each(notifData, function (i, item) {
                // هندل کردن تاریخ برای آیتم‌های قدیمی که ساعت نداشتند
                let displayDate = item.date;
                if(!displayDate) displayDate = '---';

                html += `
                <div class="rp-notif-card rp-card-${item.type || 'info'}">
                    <div class="rp-card-content-wrapper">
                        <div class="rp-card-header">
                            <span class="rp-card-title">${item.title}</span>
                            <span class="rp-card-date-badge"><span class="dashicons dashicons-clock"></span> ${displayDate}</span>
                        </div>
                        <div class="rp-card-msg">${item.msg}</div>
                    </div>
                    <div class="rp-card-actions">
                        <button type="button" class="rp-btn-sm edit-notif" data-index="${i}"><span class="dashicons dashicons-edit"></span></button>
                        <button type="button" class="rp-btn-sm delete-notif" data-index="${i}"><span class="dashicons dashicons-trash"></span></button>
                    </div>
                </div>`;
            });
            $('#rp-notif-grid').html(html);
        }
        $notifJson.val(JSON.stringify(notifData));
    }

    function persistToDatabase() {
        $.post(ajaxurl, {
            action: 'rp_sync_notifications',
            nonce: ajaxNonce,
            notifications: JSON.stringify(notifData)
        });
    }

    // رفع باگ: دکمه انصراف (بستن)
    $('#rp-btn-cancel').click(function() {
        $('#rp-editor-wrapper').slideUp();
        editIndex = -1;
        $('#edit-title, #edit-msg').val('');
    });

    $('#rp-btn-save-item').click(function (e) {
        e.preventDefault();
        var title = $('#edit-title').val().trim();
        var msg = $('#edit-msg').val().trim();

        if (!title || !msg) {
            if(window.rpShowToast) window.rpShowToast('فیلدها نباید خالی باشند', 'error');
            return;
        }

        // دریافت تاریخ و ساعت دقیق شمسی
        var now = new Date();
        var dateStr = now.toLocaleString('fa-IR', { 
            year: 'numeric', month: '2-digit', day: '2-digit', 
            hour: '2-digit', minute: '2-digit' 
        });

        var newItem = {
            id: editIndex === -1 ? 'n_' + Date.now() : notifData[editIndex].id,
            title: title,
            msg: msg,
            type: $('#edit-type').val(),
            date: dateStr // ذخیره تاریخ همراه با ساعت
        };

        if (editIndex === -1) {
            notifData.unshift(newItem);
        } else {
            // در حالت ویرایش، اگر نمی‌خواهید تاریخ آپدیت شود، خط زیر را تغییر دهید
            // اما معمولا در ویرایش هم تاریخ آپدیت می‌شود:
            notifData[editIndex] = newItem; 
        }

        renderNotifGrid();
        persistToDatabase();
        $('#rp-editor-wrapper').slideUp();
        if(window.rpShowToast) window.rpShowToast('لیست بروزرسانی شد', 'success');
        editIndex = -1;
        $('#edit-title, #edit-msg').val('');
    });

    $(document).on('click', '.edit-notif', function() {
        editIndex = $(this).data('index');
        var item = notifData[editIndex];
        $('#edit-title').val(item.title);
        $('#edit-msg').val(item.msg);
        $('#edit-type').val(item.type);
        $('#rp-editor-wrapper').slideDown();
    });

    var pendingDeleteIndex = -1;

    // ۱. کلیک روی دکمه سطل آشغال -> باز شدن مودال
    $(document).on('click', '.delete-notif', function() {
        pendingDeleteIndex = $(this).data('index');
        // نمایش مودال با افکت
        $('#rp_delete_modal').css('display', 'flex').hide().fadeIn(200);
    });

    // ۲. کلیک روی دکمه "بله، حذف کن" در مودال
    $('#rp-confirm-delete').click(function() {
        if (pendingDeleteIndex > -1) {
            notifData.splice(pendingDeleteIndex, 1);
            renderNotifGrid();
            persistToDatabase();
            if(window.rpShowToast) window.rpShowToast('اطلاعیه حذف شد', 'success');
        }
        // بستن مودال
        $('#rp_delete_modal').fadeOut(200);
        pendingDeleteIndex = -1;
    });

    // ۳. کلیک روی دکمه "انصراف"
    $('#rp-cancel-delete').click(function() {
        $('#rp_delete_modal').fadeOut(200);
        pendingDeleteIndex = -1;
    });

    // بستن مودال با کلیک بیرون باکس (اختیاری برای UX بهتر)
    $('#rp_delete_modal').click(function(e) {
        if (e.target === this) {
            $(this).fadeOut(200);
        }
    });

    $('#rp-btn-add-new').click(function() {
        var $wrapper = $('#rp-editor-wrapper');
        
        // اگر پنجره باز است -> آن را ببند
        if ($wrapper.is(':visible')) {
            $wrapper.slideUp();
            // تغییر آیکون دکمه به حالت اولیه (اختیاری برای زیبایی)
            $(this).find('.dashicons').removeClass('dashicons-minus').addClass('dashicons-plus');
        } 
        // اگر پنجره بسته است -> آن را باز کن
        else {
            editIndex = -1; // حالت افزودن جدید
            $('#rp-editor-title').text('افزودن اطلاعیه جدید');
            $('#edit-title, #edit-msg').val(''); // خالی کردن فیلدها
            $('#edit-type').val('info');
            
            $wrapper.slideDown();
            
            // اسکرول نرم به سمت فرم (برای تجربه کاربری بهتر)
            $('html, body').animate({
                scrollTop: $wrapper.offset().top - 100
            }, 500);

            // تغییر آیکون دکمه به منفی (اختیاری)
            $(this).find('.dashicons').removeClass('dashicons-plus').addClass('dashicons-minus');
        }
    });
});