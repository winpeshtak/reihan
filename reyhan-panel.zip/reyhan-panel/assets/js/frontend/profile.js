(function ($) {
    "use strict";

    Object.assign(window.ReyhanApp, {

        initProfileFeatures: function () {
            var self = this;

            // --- تغییر تصویر پروفایل ---
            $('.rp-avatar-trigger').on('click', function () { $('#rp_profile_avatar').click(); });
            $('#rp_profile_avatar').on('change', function () {
                if (this.files && this.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function (e) { $('#rp-profile-img-preview').attr('src', e.target.result); }
                    reader.readAsDataURL(this.files[0]);
                }
            });

            // --- 1. باز کردن باکس تایید (وقتی هنوز تایید نشده) ---
            $(document).on('click', '.toggle-verify-box', function () {
                var target = $(this).data('target');
                $(target).slideToggle();
            });

            // --- 2. دکمه ویرایش (وقتی قبلاً تایید شده) ---
            $(document).on('click', '.edit-mode-trigger', function () {
                var targetBox = $(this).data('target');
                var inputSel = $(this).data('input');

                // فعال کردن اینپوت برای تایپ
                $(inputSel).prop('disabled', false).focus();

                // باز کردن باکس ارسال کد
                $(targetBox).slideDown();

                // مخفی کردن دکمه ویرایش (چون وارد حالت ویرایش شدیم)
                $(this).slideUp();
            });

            // --- 3. ارسال درخواست کد تایید (AJAX) ---
            $(document).on('click', '.rp-send-otp-btn', function () {
                var btn = $(this);
                var type = btn.data('type'); // mobile یا email
                var inputSelector = btn.data('input');
                var val = $(inputSelector).val();
                var originalText = btn.html();

                if (!val) {
                    self.showNotification('لطفاً ابتدا مقدار را وارد کنید', 'error');
                    return;
                }

                btn.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> در حال ارسال...');

                $.ajax({
                    url: reyhan_front_obj.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'reyhan_send_otp_request', // اتصال به تابع Auth.php
                        security: reyhan_front_obj.nonce,
                        type: type,
                        value: val
                    },
                    success: function (res) {
                        if (res.success) {
                            self.showNotification(res.data, 'success');
                            btn.slideUp(); // مخفی کردن دکمه ارسال
                            btn.siblings('.rp-verify-step-2').slideDown(); // نمایش فیلد ورود کد
                        } else {
                            self.showNotification(res.data, 'error'); // نمایش خطای سرور
                            btn.prop('disabled', false).html(originalText);
                        }
                    },
                    error: function () {
                        self.showNotification('خطای ارتباط با سرور', 'error');
                        btn.prop('disabled', false).html(originalText);
                    }
                });
            });

            // --- 4. بررسی کد تایید نهایی (AJAX) ---
            $(document).on('click', '.rp-confirm-final-btn', function () {
                var btn = $(this);
                var type = btn.data('type');
                var codeInputId = (type === 'mobile') ? '#rp_mobile_code' : '#rp_email_code';
                var valInputId = (type === 'mobile') ? '#rp_main_mobile_input' : '#rp_main_email_input';

                var code = $(codeInputId).val();
                var val = $(valInputId).val();
                var originalText = btn.html();

                if (code.length < 4) {
                    self.showNotification('کد وارد شده صحیح نیست', 'error');
                    return;
                }

                btn.prop('disabled', true).html('بررسی...');

                $.ajax({
                    url: reyhan_front_obj.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'reyhan_verify_contact_final',
                        security: reyhan_front_obj.nonce,
                        type: type,
                        value: val,
                        code: code
                    },
                    success: function (res) {
                        if (res.success) {
                            self.showNotification('تایید شد! در حال بروزرسانی...', 'success');
                            setTimeout(function () { location.reload(); }, 1500);
                        } else {
                            self.showNotification(res.data, 'error');
                            btn.prop('disabled', false).html(originalText);
                        }
                    },
                    error: function () {
                        self.showNotification('خطای سرور', 'error');
                        btn.prop('disabled', false).html(originalText);
                    }
                });
            });

            // --- ذخیره اطلاعات عمومی پروفایل (نام و آدرس) ---
            $('#rp_save_profile_info').on('click', function () {
                var btn = $(this); var originalHtml = btn.html();
                var formData = new FormData();
                formData.append('action', 'reyhan_update_profile_info');
                formData.append('security', reyhan_front_obj.nonce);

                var dataMain = $('#rp-profile-main-form').serializeArray();
                var dataAddr = $('#rp-profile-address-form').serializeArray();

                $.each(dataMain.concat(dataAddr), function (i, field) { formData.append(field.name, field.value); });

                var file = $('#rp_profile_avatar')[0].files[0];
                if (file) formData.append('profile_image', file);

                btn.prop('disabled', true).html(self.labels.wait || '...درحال ذخیره');

                $.ajax({
                    url: reyhan_front_obj.ajax_url, type: 'POST', processData: false, contentType: false, data: formData,
                    success: function (res) {
                        self.resetButton(btn, originalHtml);
                        if (res.success) self.showNotification(res.data || 'تغییرات ذخیره شد', 'success');
                        else self.showNotification(res.data, 'error');
                    },
                    error: function () {
                        self.resetButton(btn, originalHtml);
                        self.showNotification('خطای سرور', 'error');
                    }
                });
            });
        },

        initIranCitiesAndPostal: function () {
            if (typeof RP_IRAN_DATA === 'undefined') return;

            var $stateSelect = $('#rp_state_select');
            var $citySelect = $('#rp_city_select');

            // فعال‌سازی Select2 برای جستجو
            if ($.fn.select2) {
                $stateSelect.select2({ width: '100%', dir: "rtl", placeholder: "انتخاب استان..." });
                $citySelect.select2({ width: '100%', dir: "rtl", placeholder: "انتخاب شهر..." });
            }

            if ($stateSelect.length) {
                var defaultState = $stateSelect.data('default');
                // پر کردن استان‌ها
                $stateSelect.empty().append('<option value="">انتخاب استان...</option>');
                $.each(RP_IRAN_DATA.states, function (key, val) {
                    var sel = (key === defaultState) ? 'selected' : '';
                    $stateSelect.append(`<option value="${key}" ${sel}>${val}</option>`);
                });

                // تغییر شهر با تغییر استان
                $stateSelect.on('change', function () {
                    var stateKey = $(this).val();
                    $citySelect.empty().append('<option value="">انتخاب شهر...</option>');

                    if (stateKey && RP_IRAN_DATA.cities[stateKey]) {
                        RP_IRAN_DATA.cities[stateKey].forEach(city => {
                            $citySelect.append(`<option value="${city}">${city}</option>`);
                        });
                    }
                    // به‌روزرسانی Select2 شهر بعد از تغییر آپشن‌ها
                    if ($.fn.select2) $citySelect.trigger('change');
                });

                // تریگر اولیه برای لود شدن شهرها
                if (defaultState) {
                    $stateSelect.trigger('change');
                    // ست کردن شهر پیش‌فرض با تاخیر کم
                    setTimeout(function () {
                        $citySelect.val($citySelect.data('default')).trigger('change');
                    }, 100);
                }
            }
        },

        checkMandatoryFields: function () {
            // لاجیک پاپ‌آپ
        }
    });
})(jQuery);