/* assets/js/admin/notifications.js */
window.gn_notify = function (message, type = 'success') {
    if (jQuery('#gn-notification-container').length === 0) {
        jQuery('body').append('<div id="gn-notification-container"></div>');
    }

    let icon = 'dashicons-yes-alt';
    if (type === 'error') icon = 'dashicons-dismiss';
    if (type === 'warning') icon = 'dashicons-warning';

    const notification = jQuery(`
        <div class="gn-notification gn-notification-${type}">
            <div class="gn-noti-icon"><span class="dashicons ${icon}"></span></div>
            <div class="gn-noti-message">${message}</div>
        </div>
    `);

    jQuery('#gn-notification-container').append(notification);

    const timer = setTimeout(() => {
        notification.addClass('hide');
        setTimeout(() => notification.remove(), 400);
    }, 5000);

    notification.on('click', function () {
        clearTimeout(timer);
        notification.addClass('hide');
        setTimeout(() => notification.remove(), 400);
    });
};