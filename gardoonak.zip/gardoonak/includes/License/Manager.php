<?php
namespace Gardoonak\License;

defined( 'ABSPATH' ) || exit;

class Manager {

    private $api_endpoint = 'https://license.yoursite.com/api/v1/check'; // آدرس سرور لایسنس شما

    public function __construct() {
        // بررسی لایسنس هنگام فعال‌سازی یا در بازه‌های زمانی خاص
        add_action( 'admin_init', [ $this, 'check_license_status' ] );
    }

    public function check_license_status() {
        // اینجا کد بررسی لایسنس قرار می‌گیرد
        // اگر لایسنس نامعتبر بود، کل عملکرد افزونه متوقف می‌شود
        $license_key = get_option( 'spin_master_license_key' );
        
        if ( empty( $license_key ) ) {
            // نمایش نوتیفیکیشن خطا به ادمین
            return false; 
        }

        // ادامه لاجیک در مراحل بعد...
    }

    public function is_active() {
        return get_option( 'spin_master_license_status' ) === 'valid';
    }
}