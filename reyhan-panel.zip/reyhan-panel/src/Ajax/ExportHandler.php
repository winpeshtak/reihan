<?php
namespace ReyhanPanel\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class ExportHandler {

    public function __construct() {
        // استفاده از admin_post برای هندل کردن دانلود فایل (به جای wp_ajax)
        add_action( 'admin_post_rp_export_data', [ $this, 'handle_export_request' ] );
    }

    public function handle_export_request() {
        // امنیت: بررسی نانس و دسترسی
        if ( ! isset($_POST['security']) || ! wp_verify_nonce($_POST['security'], 'rp_export_secure_nonce') ) {
            wp_die( __('لینک امنیتی منقضی شده است.', 'reyhan-panel') );
        }

        if ( ! current_user_can('manage_options') ) {
            wp_die( __('دسترسی غیرمجاز.', 'reyhan-panel') );
        }

        $type   = sanitize_text_field( $_POST['export_type'] );
        $format = sanitize_text_field( $_POST['format'] );
        $range  = sanitize_text_field( $_POST['date_range'] );
        
        $data = [];
        $filename = 'reyhan-export-' . $type . '-' . date('Y-m-d');

        // جمع‌آوری داده‌ها بر اساس نوع
        switch ( $type ) {
            case 'users':
                $data = $this->get_users_data( $range, $_POST['fields'] ?? [] );
                break;
            case 'tickets':
                $report_type = sanitize_text_field( $_POST['ticket_report_type'] );
                if ( $report_type === 'stats' ) {
                    $this->generate_stats_report( $range, $format ); // متد اختصاصی برای گزارش آماری
                    return;
                }
                $data = $this->get_tickets_data( $range );
                break;
            case 'orders':
                $data = $this->get_orders_data( $range, $_POST['order_status'], $_POST['order_detail'] );
                break;
            default:
                wp_die('Invalid Type');
        }

        // تولید خروجی
        if ( $format === 'excel' ) {
            // تغییر نام متد به متد جدید
            $this->output_excel_download( $data, $filename );
        } else {
            $this->output_html_print( $data, $type, $range );
        }
    }

    // --- Data Retrievers ---

    private function get_date_query( $range, $column = 'post_date' ) {
        if ( $range === 'all' ) return '';
        
        $interval = '1 MONTH';
        if ( $range === 'week' ) $interval = '1 WEEK';
        if ( $range === '3months' ) $interval = '3 MONTH';
        if ( $range === 'year' ) $interval = '1 YEAR';
        
        return " AND $column >= DATE_SUB(NOW(), INTERVAL $interval)";
    }

    private function get_users_data( $range, $fields ) {
        $args = [ 'number' => -1 ];
        
        // فیلتر تاریخ ثبت نام
        if ( $range !== 'all' ) {
            $args['date_query'] = [
                [ 'after' => $this->get_relative_date_string($range), 'inclusive' => true ]
            ];
        }

        $users = get_users( $args );
        $export = [];

        // هدرها
        $headers = ['ID'];
        if(in_array('display_name', $fields)) $headers[] = 'نام کامل';
        if(in_array('user_email', $fields)) $headers[] = 'ایمیل';
        if(in_array('mobile', $fields)) $headers[] = 'موبایل';
        if(in_array('address', $fields)) $headers[] = 'آدرس';
        if(in_array('postcode', $fields)) $headers[] = 'کد پستی';
        $headers[] = 'تاریخ ثبت نام';
        
        $export[] = $headers;

        foreach ( $users as $u ) {
            $row = [ $u->ID ];

            // استفاده از متد هوشمند برای انتخاب داده با اولویت
            if(in_array('display_name', $fields)) {
                $row[] = $this->get_user_field_smart($u, 'name');
            }
            if(in_array('user_email', $fields)) {
                $row[] = $this->get_user_field_smart($u, 'email');
            }
            if(in_array('mobile', $fields)) {
                $row[] = $this->get_user_field_smart($u, 'mobile');
            }
            if(in_array('address', $fields)) {
                $row[] = $this->get_user_field_smart($u, 'address');
            }
            if(in_array('postcode', $fields)) {
                $row[] = $this->get_user_field_smart($u, 'postcode');
            }

            // تاریخ همیشه از وردپرس گرفته می‌شود
            $row[] = date_i18n('Y/m/d H:i', strtotime($u->user_registered));
            
            $export[] = $row;
        }
        return $export;
    }

    private function get_user_field_smart( $user, $type ) {
        $uid = $user->ID;
        $value = '';

        switch ( $type ) {
            case 'name':
                // 1. Reyhan specific display name? (Example: reyhan_full_name)
                $value = get_user_meta( $uid, 'reyhan_full_name', true ); // اگر کلید اختصاصی دارید
                // 2. Fallback to WP Display Name
                if ( empty($value) ) $value = $user->display_name;
                // 3. Fallback to First+Last
                if ( empty($value) ) $value = get_user_meta($uid, 'first_name', true) . ' ' . get_user_meta($uid, 'last_name', true);
                break;

            case 'email':
                // 1. Reyhan specific email?
                $value = get_user_meta( $uid, 'reyhan_email', true );
                // 2. WP Core Email
                if ( empty($value) ) $value = $user->user_email;
                // 3. Woo Billing Email
                if ( empty($value) ) $value = get_user_meta($uid, 'billing_email', true);
                break;

            case 'mobile':
                // 1. Reyhan Panel / Digits / Persinan mobile
                $value = get_user_meta( $uid, 'mobile', true ); 
                if ( empty($value) ) $value = get_user_meta( $uid, 'reyhan_mobile', true );
                // 2. Woo Billing Phone
                if ( empty($value) ) $value = get_user_meta($uid, 'billing_phone', true);
                break;

            case 'address':
                // 1. Reyhan Panel Custom Address
                $value = get_user_meta( $uid, 'reyhan_address', true );
                // 2. Woo Billing Address
                if ( empty($value) ) {
                    $addr = get_user_meta($uid, 'billing_address_1', true);
                    $city = get_user_meta($uid, 'billing_city', true);
                    $state = get_user_meta($uid, 'billing_state', true);
                    if ( $addr ) $value = "$state - $city - $addr";
                }
                break;

            case 'postcode':
                // 1. Reyhan Panel Custom Postcode
                $value = get_user_meta( $uid, 'reyhan_postcode', true );
                // 2. Woo Billing Postcode
                if ( empty($value) ) $value = get_user_meta($uid, 'billing_postcode', true);
                break;
        }

        return trim( $value );
    }

    private function get_tickets_data( $range ) {
        $args = [
            'post_type' => 'ticket',
            'posts_per_page' => -1,
            'post_status' => 'any'
        ];

        if ( $range !== 'all' ) {
            $args['date_query'] = [ [ 'after' => $this->get_relative_date_string($range) ] ];
        }

        $tickets = get_posts( $args );
        $export = [];
        $export[] = ['شناسه', 'عنوان', 'کاربر', 'دپارتمان', 'وضعیت', 'تاریخ ایجاد', 'تاریخ بروزرسانی'];

        foreach ( $tickets as $t ) {
            $user = get_userdata($t->post_author);
            $dept = get_post_meta($t->ID, '_ticket_department', true);
            $status = get_post_meta($t->ID, '_ticket_status', true);

            $export[] = [
                $t->ID,
                $t->post_title,
                $user ? $user->display_name : 'Guest',
                $dept,
                $status,
                $t->post_date,
                $t->post_modified
            ];
        }
        return $export;
    }

    private function generate_stats_report( $range, $format ) {
        // محاسبات آماری پیشرفته
        $args = [ 'post_type' => 'ticket', 'posts_per_page' => -1, 'post_status' => 'any' ];
        if ( $range !== 'all' ) {
            $args['date_query'] = [ [ 'after' => $this->get_relative_date_string($range) ] ];
        }
        $tickets = get_posts($args);
        
        $total = count($tickets);
        $closed = 0;
        $open = 0;
        $by_dept = [];
        $authors = [];

        foreach($tickets as $t) {
            $status = get_post_meta($t->ID, '_ticket_status', true);
            $dept = get_post_meta($t->ID, '_ticket_department', true) ?: 'عمومی';
            
            if($status == 'closed') $closed++; else $open++;
            
            if(!isset($by_dept[$dept])) $by_dept[$dept] = 0;
            $by_dept[$dept]++;

            $authors[$t->post_author] = true;
        }

        // اگر فرمت اکسل باشد، یک گزارش خلاصه متنی ایجاد می‌کنیم
        if ( $format === 'excel' ) {
            $data = [
                ['گزارش آماری تیکت‌ها'],
                ['بازه زمانی', $range],
                ['کل تیکت‌ها', $total],
                ['پاسخ داده شده/بسته', $closed],
                ['باز/در انتظار', $open],
                ['تعداد کاربران درگیر', count($authors)],
                [''],
                ['آمار دپارتمان‌ها'],
            ];
            foreach($by_dept as $d => $c) {
                $data[] = [$d, $c];
            }
            
            // --- اصلاح شده: استفاده از متد جدید اکسل ---
            $this->output_excel_download($data, 'ticket-stats');
            return;
        }

        // اگر PDF باشد، نمای HTML زیبا
        $html = "
        <div style='font-family:Tahoma; direction:rtl; text-align:right; padding:20px;'>
            <h1 style='color:#E65100'>📊 گزارش عملکرد پشتیبانی</h1>
            <p>بازه زمانی: ".esc_html($range)."</p>
            <hr>
            <table style='width:100%; border-collapse:collapse; margin-top:20px;' border='1' cellpadding='10'>
                <tr style='background:#f5f5f5'><td>کل تیکت‌ها</td><td><strong>$total</strong></td></tr>
                <tr><td>تیکت‌های بسته شده</td><td style='color:green'>$closed</td></tr>
                <tr><td>تیکت‌های باز</td><td style='color:red'>$open</td></tr>
                <tr><td>کاربران یونیک</td><td>".count($authors)."</td></tr>
            </table>
            
            <h3>تفکیک دپارتمان</h3>
            <ul>";
            foreach($by_dept as $d => $c) {
                $html .= "<li><strong>$d:</strong> $c تیکت</li>";
            }
        $html .= "</ul>
        </div>";

        $this->output_html_print( $html, 'ticket_stats', $range, true );
    }

    private function get_orders_data( $range, $status, $detail ) {
        if ( ! class_exists('WooCommerce') ) return [['WooCommerce Not Installed']];

        $args = [ 'limit' => -1 ];
        if ( $range !== 'all' ) {
            $args['date_after'] = $this->get_relative_date_string($range);
        }
        if ( $status !== 'any' ) {
            $args['status'] = $status;
        }

        $orders = wc_get_orders( $args );
        $export = [];

        if ( $detail === 'summary' ) {
            $export[] = ['شماره سفارش', 'وضعیت', 'مشتری', 'مبلغ نهایی', 'تاریخ'];
        } else {
            $export[] = ['شماره سفارش', 'وضعیت', 'مشتری', 'ایمیل', 'موبایل', 'شهر', 'آیتم‌ها', 'مبلغ نهایی', 'تاریخ'];
        }

        foreach ( $orders as $o ) {
            // 1. دریافت نام مشتری
            $customer_name = $o->get_formatted_billing_full_name();
            if(empty($customer_name)) $customer_name = 'کاربر مهمان';

            // 2. دریافت مبلغ (اصلاح شده: بدون HTML)
            // نکته: get_total() عدد خام می‌دهد که برای اکسل عالی است.
            // اگر واحد پول را هم کنارش می‌خواهید از strip_tags(html_entity_decode($o->get_formatted_order_total())) استفاده کنید.
            $total = $o->get_total(); 

            $row = [
                $o->get_order_number(),
                wc_get_order_status_name($o->get_status()),
                $customer_name,
            ];

            if ( $detail === 'full' ) {
                // ایمیل
                $row[] = $o->get_billing_email();
                
                // 3. دریافت موبایل با اولویت ریحان پنل
                $user_id = $o->get_user_id();
                $mobile = '';
                
                if ( $user_id ) {
                    // اگر کاربر عضو است، از متد هوشمند استفاده کن
                    $user_obj = get_userdata($user_id);
                    if($user_obj) {
                        $mobile = $this->get_user_field_smart($user_obj, 'mobile');
                    }
                }
                
                // فال‌بک: اگر متد هوشمند خالی برگرداند یا کاربر مهمان بود، از سفارش بگیر
                if ( empty($mobile) ) {
                    $mobile = $o->get_billing_phone();
                }
                
                $row[] = $mobile;
                
                // شهر
                $row[] = $o->get_billing_city();
                
                // آیتم‌ها
                $items = [];
                foreach($o->get_items() as $item) {
                    $items[] = $item->get_name() . ' (' . $item->get_quantity() . ' عدد)';
                }
                $row[] = implode(' | ', $items);
            }

            $row[] = $total; // مبلغ اصلاح شده
            $row[] = wc_format_datetime($o->get_date_created());

            $export[] = $row;
        }
        return $export;
    }

    // --- Helpers ---

    private function get_relative_date_string( $range ) {
        if ( $range === 'week' ) return date('Y-m-d', strtotime('-1 week'));
        if ( $range === 'month' ) return date('Y-m-d', strtotime('-1 month'));
        if ( $range === '3months' ) return date('Y-m-d', strtotime('-3 months'));
        if ( $range === 'year' ) return date('Y-m-d', strtotime('-1 year'));
        return '';
    }

    private function output_excel_download( $data, $filename ) {
        // تنظیم هدرها برای فایل اکسل
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $filename . '.xls"');
        header('Cache-Control: max-age=0');

        // شروع خروجی HTML برای اکسل
        // نکته: استفاده از BOM و متا تگ UTF-8 برای نمایش صحیح فارسی الزامی است
        echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
        echo '<head>';
        echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
        echo '';
        echo '<style>
            body { font-family: Tahoma, sans-serif; }
            table { border-collapse: collapse; width: 100%; }
            th { background-color: #4CAF50; color: white; border: 1px solid #ddd; padding: 10px; text-align: center; }
            td { border: 1px solid #ddd; padding: 8px; text-align: center; vertical-align: middle; }
            .num { mso-number-format:"0"; } /* فرمت اعداد */
            .text { mso-number-format:"\@"; } /* فرمت متنی برای جلوگیری از حذف صفر موبایل */
        </style>';
        echo '</head>';
        echo '<body>';
        echo '<table>';

        // رندر کردن داده‌ها
        foreach ( $data as $index => $row ) {
            echo '<tr>';
            foreach ( $row as $col ) {
                // اگر ردیف اول باشد (هدر)
                if ( $index === 0 ) {
                    echo '<th>' . esc_html( $col ) . '</th>';
                } else {
                    // تشخیص نوع داده برای فرمت‌دهی اکسل
                    // اگر داده با 0 شروع شود و عدد باشد (مثل موبایل)، کلاس text می‌دهیم تا صفرش نیفتد
                    $class = ( is_numeric($col) && strpos($col, '0') === 0 ) ? 'class="text"' : '';
                    echo '<td ' . $class . '>' . esc_html( $col ) . '</td>';
                }
            }
            echo '</tr>';
        }

        echo '</table>';
        echo '</body>';
        echo '</html>';
        exit;
    }

    private function output_html_print( $data, $type, $range, $is_raw_html = false ) {
        // تنظیمات اولیه
        $date_str = date_i18n( 'j F Y - H:i' ); // تاریخ شمسی اگر jdf دارید، وگرنه میلادی
        $logo_url = \REYHAN_URL . 'assets/images/logo.png'; // مسیر لوگوی شما
        
        // استایل‌های مشترک و حیاتی برای چاپ
        $css = "
            @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap');
            
            :root {
                --primary: #FF5722;
                --text: #333;
                --border: #ddd;
                --bg-header: #f8f9fa;
            }
            
            @page {
                size: A4;
                margin: 10mm;
            }
            
            body {
                font-family: 'Vazirmatn', Tahoma, sans-serif;
                direction: rtl;
                text-align: right;
                background: #fff;
                color: var(--text);
                font-size: 12px;
                line-height: 1.5;
                margin: 0;
                padding: 10px;
            }

            /* کلاس‌های کمکی برای چاپ */
            @media print {
                .no-print { display: none !important; }
                body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
                a { text-decoration: none; color: inherit; }
                .page-break { page-break-before: always; }
                table { page-break-inside: auto; }
                tr { page-break-inside: avoid; page-break-after: auto; }
                thead { display: table-header-group; }
                tfoot { display: table-footer-group; }
            }

            /* هدر و فوتر گزارش */
            .rp-print-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 2px solid var(--primary);
                padding-bottom: 15px;
                margin-bottom: 20px;
            }
            .rp-logo { max-height: 50px; }
            .rp-meta { font-size: 11px; color: #777; text-align: left; }
            
            /* استایل جداول */
            .rp-table {
                width: 100%;
                border-collapse: collapse;
                width: 100%;
                margin-top: 10px;
            }
            .rp-table th {
                background-color: var(--bg-header);
                color: #444;
                font-weight: bold;
                padding: 10px;
                border: 1px solid var(--border);
                font-size: 11px;
            }
            .rp-table td {
                border: 1px solid var(--border);
                padding: 8px;
                vertical-align: middle;
            }
            .rp-table tr:nth-child(even) { background-color: #fafafa; }
            
            /* استایل بج‌ها (Badge) */
            .rp-badge {
                padding: 2px 8px;
                border-radius: 4px;
                font-size: 10px;
                font-weight: bold;
                display: inline-block;
            }
            .status-completed, .status-active, .status-closed { background: #e8f5e9; color: #2e7d32; border: 1px solid #c8e6c9; }
            .status-pending, .status-processing { background: #fff3e0; color: #ef6c00; border: 1px solid #ffe0b2; }
            .status-failed, .status-cancelled { background: #ffebee; color: #c62828; border: 1px solid #ffcdd2; }

            /* دکمه پرینت */
            .rp-print-btn {
                position: fixed;
                top: 20px;
                left: 20px;
                background: var(--primary);
                color: #fff;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                cursor: pointer;
                font-family: inherit;
                box-shadow: 0 4px 10px rgba(0,0,0,0.2);
                z-index: 999;
            }
            .rp-print-btn:hover { background: #e64a19; }
        ";

        ob_start();
        ?>
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <title>گزارش <?php echo esc_html($type); ?> - ریحان پنل</title>
            <style><?php echo $css; ?></style>
        </head>
        <body>
            <button class="rp-print-btn no-print" onclick="window.print()">🖨️ چاپ / ذخیره PDF</button>

            <div class="rp-print-header">
                <div class="rp-header-right">
                    <img src="<?php echo esc_url($logo_url); ?>" alt="Logo" class="rp-logo">
                    <h2 style="margin: 10px 0 0 0; font-size: 18px;">گزارش <?php echo $this->get_report_title($type); ?></h2>
                </div>
                <div class="rp-header-left rp-meta">
                    <div>📅 زمان صدور: <?php echo $date_str; ?></div>
                    <div>🏷️ فیلتر زمانی: <?php echo esc_html($range); ?></div>
                    <div>👤 صادر کننده: <?php echo esc_html(wp_get_current_user()->display_name); ?></div>
                </div>
            </div>

            <div class="rp-report-body">
                <?php 
                if ( $is_raw_html ) {
                    echo $data; // برای حالت Stats
                } else {
                    // رندر کردن بر اساس نوع
                    switch ($type) {
                        case 'users':
                            $this->render_users_print_table($data);
                            break;
                        case 'tickets':
                            $this->render_tickets_print_table($data);
                            break;
                        case 'orders':
                            $this->render_orders_print_table($data);
                            break;
                        default:
                            echo '<p>قالب ناشناخته</p>';
                    }
                }
                ?>
            </div>

            <div style="margin-top: 30px; border-top: 1px solid #eee; padding-top: 10px; text-align: center; font-size: 10px; color: #999;">
                این سند به صورت سیستمی توسط افزونه ریحان پنل ایجاد شده است و فاقد مهر و امضا می‌باشد.
                <br>
                <?php echo esc_url( home_url() ); ?>
            </div>

            <script>
                // باز شدن خودکار پرینت
                window.onload = function() { setTimeout(function(){ window.print(); }, 500); };
            </script>
        </body>
        </html>
        <?php
        echo ob_get_clean();
        exit;
    }

    /**
     * Helper: Get Report Title
     */
    private function get_report_title($type) {
        $titles = [
            'users' => 'لیست کاربران',
            'tickets' => 'تیکت‌های پشتیبانی',
            'orders' => 'سفارشات فروشگاه',
            'ticket_stats' => 'عملکرد پشتیبانی'
        ];
        return $titles[$type] ?? 'داده‌ها';
    }

    /**
     * 1. Users Print Template
     */
    private function render_users_print_table($data) {
        if ( empty($data) || count($data) < 2 ) { echo 'داده‌ای یافت نشد.'; return; }
        
        $headers = $data[0];
        $rows = array_slice($data, 1);
        ?>
        <table class="rp-table">
            <thead>
                <tr>
                    <th style="width: 50px;">#</th>
                    <?php foreach($headers as $h): if($h == 'ID') continue; ?>
                        <th><?php echo esc_html($h); ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach($rows as $idx => $row): ?>
                    <tr>
                        <td style="text-align:center; color:#777;"><?php echo $idx + 1; ?></td>
                        <?php foreach($row as $key => $col): if($key === 0) continue; // Skip ID column logic if needed ?> 
                            <td><?php echo esc_html($col); ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div style="margin-top: 10px; font-weight: bold;">تعداد کل کاربران: <?php echo count($rows); ?> نفر</div>
        <?php
    }

    /**
     * 2. Tickets Print Template
     */
    private function render_tickets_print_table($data) {
        if ( empty($data) || count($data) < 2 ) { echo 'تیکتی یافت نشد.'; return; }

        $headers = $data[0];
        $rows = array_slice($data, 1);
        ?>
        <div style="display:flex; gap:10px; margin-bottom:15px;">
            <div class="rp-badge status-active" style="font-size:12px; padding:8px;">تعداد کل: <?php echo count($rows); ?></div>
        </div>

        <table class="rp-table">
            <thead>
                <tr>
                    <th style="width: 60px;">شناسه</th>
                    <th>موضوع</th>
                    <th style="width: 120px;">کاربر</th>
                    <th style="width: 100px;">دپارتمان</th>
                    <th style="width: 100px;">وضعیت</th>
                    <th style="width: 120px;">تاریخ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($rows as $row): 
                    // Assuming structure: [ID, Title, User, Dept, Status, Date, Modified]
                    $status_class = ($row[4] == 'closed') ? 'status-closed' : 'status-processing';
                    $status_label = ($row[4] == 'closed') ? 'بسته شده' : 'باز / در جریان';
                ?>
                    <tr>
                        <td style="font-family:monospace; font-weight:bold;">#<?php echo $row[0]; ?></td>
                        <td><?php echo esc_html($row[1]); ?></td>
                        <td><?php echo esc_html($row[2]); ?></td>
                        <td><span class="rp-badge" style="background:#eee;"><?php echo esc_html($row[3]); ?></span></td>
                        <td><span class="rp-badge <?php echo $status_class; ?>"><?php echo $status_label; ?></span></td>
                        <td style="font-size:10px; direction:ltr;"><?php echo esc_html($row[5]); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    /**
     * 3. Orders Print Template
     */
    private function render_orders_print_table($data) {
        if ( empty($data) || count($data) < 2 ) { echo 'سفارشی یافت نشد.'; return; }

        $headers = $data[0];
        $rows = array_slice($data, 1);
        
        // محاسبه سرجمع مبلغ (فرض بر اینکه ستون مبلغ ایندکس خاصی دارد، اینجا نمایشی است)
        ?>
        <table class="rp-table">
            <thead>
                <tr>
                    <?php foreach($headers as $h): ?>
                        <th><?php echo esc_html($h); ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach($rows as $row): ?>
                    <tr>
                        <?php foreach($row as $idx => $col): ?>
                            <td>
                                <?php 
                                // تشخیص ساده برای استایل دهی وضعیت سفارش
                                if ( in_array($col, ['تکمیل شده', 'completed']) ) {
                                    echo '<span class="rp-badge status-completed">'.esc_html($col).'</span>';
                                } elseif ( in_array($col, ['لغو شده', 'failed', 'refunded']) ) {
                                    echo '<span class="rp-badge status-failed">'.esc_html($col).'</span>';
                                } else {
                                    echo esc_html($col); 
                                }
                                ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div style="margin-top: 20px; text-align: left; padding: 15px; background: #f8f9fa; border: 1px solid #ddd; width: 200px; margin-right: auto;">
            <strong>تعداد سفارشات:</strong> <?php echo count($rows); ?><br>
            <small style="color:#777">محاسبه مالی در فایل اکسل دقیق‌تر است.</small>
        </div>
        <?php
    }
}