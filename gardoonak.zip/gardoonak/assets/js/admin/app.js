/* assets/js/admin/app.js */

(function ($) {
    'use strict';

    const GardoonakAdmin = {
        init: function () {
            this.handleGeneralSettings();
            this.initCustomSelects(); // اجرای اولیه برای تمام Selectها
            this.handleWheelBuilder();
            this.initMediaUploader();

            // یک ترفند مهندسی: اگر بخشی مثل "صفحات خاص" باز شد، مجدد چک کن
            $(document).on('click', '.gardoonak-tabs-nav li', () => {
                this.initCustomSelects();
            });
        },

        /* تبدیل خودکار Selectهای معمولی به نسخه مدرن تجاری */
        initCustomSelects: function () {
            const self = this;

            // ۱. تبدیل Select ها به ساختار HTML سفارشی
            $('select.gn-input').each(function () {
                const $this = $(this);
                // جلوگیری از رپینگ مجدد (Double Wrapping)
                if ($this.parent().hasClass('gn-custom-select-wrapper')) return;

                const $wrapper = $('<div class="gn-custom-select-wrapper"></div>');
                $this.wrap($wrapper);

                // متن گزینه انتخاب شده فعلی
                const selectedText = $this.find('option:selected').text() || 'انتخاب کنید...';

                // مهندس جان، تگ آیکون را حذف کردیم چون CSS شما با شبه‌المنت :after خودش فلش را می‌سازد
                $this.after(`<div class="gn-select-trigger"><span>${selectedText}</span></div>`);

                const $optionsContainer = $('<div class="gn-select-options"></div>');
                $this.find('option').each(function () {
                    const isSelected = $(this).is(':selected') ? 'selected' : '';
                    $optionsContainer.append(`<div class="gn-select-option ${isSelected}" data-value="${$(this).val()}">${$(this).text()}</div>`);
                });

                $this.parent().append($optionsContainer);
            });

            // ۲. مدیریت کلیک روی تریگر (باز و بسته کردن)
            // استفاده از کلاس .open دقیقاً مطابق با فایل ui-forms.css شما
            $(document).off('click', '.gn-select-trigger').on('click', '.gn-select-trigger', function (e) {
                e.preventDefault();
                e.stopPropagation(); // جلوگیری از بسته شدن آنی توسط کلیک داکیومنت

                const $wrapper = $(this).parent();

                // بستن بقیه لیست‌های باز احتمالی
                $('.gn-custom-select-wrapper').not($wrapper).removeClass('open');

                // تغییر وضعیت لیست فعلی
                $wrapper.toggleClass('open');
            });

            // ۳. مدیریت انتخاب گزینه‌ها
            $(document).off('click', '.gn-select-option').on('click', '.gn-select-option', function (e) {
                const $option = $(this);
                const $wrapper = $option.closest('.gn-custom-select-wrapper');
                const $select = $wrapper.find('select');
                const val = $option.data('value');

                // به‌روزرسانی متن نمایش داده شده
                $wrapper.find('.gn-select-trigger span').text($option.text());

                // تغییر کلاس انتخاب شده
                $option.addClass('selected').siblings().removeClass('selected');

                // آپدیت مقدار در Select اصلی و شلیک رویداد تغییر (برای بخش صفحات خاص)
                $select.val(val).trigger('change');

                // بستن منو
                $wrapper.removeClass('open');
            });

            // ۴. بستن لیست با کلیک در هر جای دیگر صفحه
            $(document).on('click', function () {
                $('.gn-custom-select-wrapper').removeClass('open');
            });
        },

        /* مدیریت تب‌ها و رویدادهای تنظیمات عمومی */
        handleGeneralSettings: function () {
            const self = this;

            // ۱. مدیریت تب‌ها
            $('.gardoonak-tabs-nav li').on('click', function () {
                const tabId = $(this).data('tab');
                $('.gardoonak-tabs-nav li').removeClass('active');
                $(this).addClass('active');
                $('.gardoonak-tab-pane').removeClass('active').hide();
                $('#' + tabId).addClass('active').fadeIn(300);
            });

            // ۲. منطق دکمه شناور (Floating Button)
            $('#gn_enable_floating_btn').on('change', function () {
                const isChecked = $(this).is(':checked');
                const $settings = $('#gn_floating_btn_settings');
                const $warning = $('#gn_floating_btn_warning');

                if (isChecked) {
                    $warning.slideUp(300);
                    $settings.slideDown(300);
                } else {
                    $settings.slideUp(300);
                    $warning.slideDown(300);
                }
            });

            $(document).on('change', 'input[name="trigger_time"]', function () {
                if ($(this).val() === '1') {
                    $('#gn_time_input_wrap').slideDown(250);
                } else {
                    $('#gn_time_input_wrap').slideUp(250);
                }
            });

            $(document).on('change', 'input[name="trigger_scroll"]', function () {
                if ($(this).val() === '1') {
                    $('#gn_scroll_input_wrap').slideDown(250);
                } else {
                    $('#gn_scroll_input_wrap').slideUp(250);
                }
            });

            // --- مدیریت صفحات خاص مهندس جان ---
            let searchTimer;
            let selectedPages = [];

            // لود کردن شناسه‌های ذخیره شده قبلی برای جلوگیری از پاک شدن لیست در زمان آپدیت
            const initialIds = $('#gn_specific_pages_ids').val();
            if (initialIds) {
                initialIds.split(',').forEach(id => {
                    if (id) selectedPages.push({ id: id.toString() });
                });
            }

            $('#gn_page_search').on('input', function () {
                const query = $(this).val().trim();
                const $resultsBox = $('#gn_page_search_results');

                clearTimeout(searchTimer);
                if (query.length < 2) {
                    $resultsBox.hide();
                    return;
                }

                searchTimer = setTimeout(() => {
                    $.ajax({
                        url: gardoonak_ajax.url,
                        type: 'POST',
                        data: {
                            action: 'gardoonak_search_pages',
                            security: gardoonak_ajax.nonce,
                            q: query
                        },
                        success: function (res) {
                            if (res.success && res.data.length > 0) {
                                let html = '';
                                res.data.forEach(page => {
                                    html += `<div class="gn-search-result-item" data-id="${page.id}" data-title="${page.title}">${page.title}</div>`;
                                });
                                $resultsBox.html(html).fadeIn(200);
                            } else {
                                $resultsBox.html('<div class="gn-search-no-result">برگه‌ای یافت نشد.</div>').show();
                            }
                        }
                    });
                }, 400);
            });

            // انتخاب برگه از نتایج و تبدیل به تگ (هندلر یکپارچه)
            $(document).off('click', '.gn-search-result-item').on('click', '.gn-search-result-item', function () {
                const id = $(this).data('id').toString();
                const title = $(this).data('title');
                const $resultsBox = $('#gn_page_search_results');

                // بررسی تکراری نبودن در لیست فعلی
                if (!selectedPages.some(p => p.id === id)) {
                    selectedPages.push({ id: id, title: title });

                    // افزودن تگ به رابط کاربری
                    $('#gn_selected_pages_list').append(`
                <div class="gn-page-tag" data-id="${id}">
                    ${title}
                    <span class="remove-tag dashicons dashicons-no-alt"></span>
                </div>
            `);

                    // به‌روزرسانی اینپوت مخفی با کل لیست
                    $('#gn_specific_pages_ids').val(selectedPages.map(p => p.id).join(','));
                }

                $('#gn_page_search').val('').focus();
                $resultsBox.hide();
            });

            // حذف تگ و به‌روزرسانی لیست
            $(document).on('click', '.remove-tag', function () {
                const $tag = $(this).parent();
                const id = $tag.data('id').toString();

                selectedPages = selectedPages.filter(p => p.id !== id);
                $('#gn_specific_pages_ids').val(selectedPages.map(p => p.id).join(','));
                $tag.remove();
            });

            // بستن نتایج جستجو با کلیک بیرون از کانتینر
            $(document).on('click', (e) => {
                if (!$(e.target).closest('.gn-page-selector-container').length) {
                    $('#gn_page_search_results').hide();
                }
            });

            // ۳. ارسال فرم تنظیمات عمومی به صورت AJAX
            $('#gardoonak-settings-form').on('submit', function (e) {
                e.preventDefault();

                const $btn = $(this).find('button[type="submit"]');
                const $btnText = $btn.find('.btn-text');
                const originalText = $btnText.text();

                $btn.prop('disabled', true);
                $btnText.text('در حال ذخیره...');

                const formData = $(this).serialize();

                $.ajax({
                    url: gardoonak_ajax.url,
                    type: 'POST',
                    data: {
                        action: 'gardoonak_save_settings',
                        security: gardoonak_ajax.nonce,
                        form_data: formData
                    },
                    success: function (res) {
                        if (res.success) {
                            if (window.GardoonakNotif) {
                                GardoonakNotif.success(res.data.message);
                            } else {
                                alert(res.data.message);
                            }
                        } else {
                            alert(res.data.message || 'خطایی رخ داد.');
                        }
                    },
                    error: function () {
                        alert('خطا در برقراری ارتباط با سرور.');
                    },
                    complete: function () {
                        $btn.prop('disabled', false);
                        $btnText.text(originalText);
                    }
                });
            });

            const toggleSearchLock = () => {
                const isAllPagesSelected = selectedPages.some(p => p.id === 'all_pages');
                const $searchBar = $('#gn_page_search');
                const $allPagesBtn = $('#gn_select_all_pages');

                if (isAllPagesSelected) {
                    $searchBar.prop('disabled', true).addClass('is-locked').val('وضعیت روی "تمام صفحات" تنظیم شده است');
                    $allPagesBtn.hide(); // مخفی کردن دکمه وقتی انتخاب شده
                } else {
                    $searchBar.prop('disabled', false).removeClass('is-locked').val('');
                    $allPagesBtn.show();
                }
            };

            // رویداد کلیک روی دکمه "انتخاب تمام صفحات"
            $(document).on('click', '#gn_select_all_pages', function () {
                if (!selectedPages.some(p => p.id === 'all_pages')) {
                    // پاک کردن بقیه صفحات چون وقتی "همه" انتخاب می‌شود بقیه معنایی ندارند
                    selectedPages = [{ id: 'all_pages', title: 'تمام صفحات' }];
                    $('#gn_selected_pages_list').html(`
                    <div class="gn-page-tag gn-all-pages-tag" data-id="all_pages">
                        تمام صفحات
                        <span class="remove-tag dashicons dashicons-no-alt"></span>
                    </div>
                `);
                    $('#gn_specific_pages_ids').val('all_pages');
                    toggleSearchLock();
                }
            });

            // اصلاح بخش حذف تگ برای باز کردن قفل
            $(document).on('click', '.remove-tag', function () {
                const $tag = $(this).parent();
                const id = $tag.data('id').toString();

                selectedPages = selectedPages.filter(p => p.id !== id);
                $('#gn_specific_pages_ids').val(selectedPages.map(p => p.id).join(','));
                $tag.remove();

                if (id === 'all_pages') {
                    toggleSearchLock();
                }
            });

            // فراخوانی در ابتدای لود برای چک کردن وضعیت دیتابیس
            toggleSearchLock();

            const toggleTriggerSettingsLock = () => {
                const isFloatingBtnActive = $('#gn_enable_floating_btn').is(':checked');
                const $triggersSection = $('#gn_main_triggers_section');
                const $notice = $('#gn_main_triggers_notice');

                if (!isFloatingBtnActive) {
                    $triggersSection.addClass('gn-section-locked');
                    $notice.slideDown(300);
                } else {
                    $triggersSection.removeClass('gn-section-locked');
                    $notice.slideUp(300);
                }
            };

            // اجرای هنگام تغییر وضعیت سوئیچ و لود اولیه
            $(document).on('change', '#gn_enable_floating_btn', toggleTriggerSettingsLock);
            toggleTriggerSettingsLock();


            /* --- اصلاحیه مهندس جان برای قفل‌گذاری آنی بخش CTA --- */
            const toggleCtaSettingsLock = () => {
                const isFloatingBtnActive = $('#gn_enable_floating_btn').is(':checked');
                const $ctaSection = $('#gn_cta_style_section');
                const $ctaNotice = $('#gn_cta_style_notice');

                if (!isFloatingBtnActive) {
                    $ctaSection.addClass('gn-section-locked');
                    $ctaNotice.slideDown(300);
                } else {
                    $ctaSection.removeClass('gn-section-locked');
                    $ctaNotice.slideUp(300);
                }
            };

            // اجرای هوشمند هنگام تغییر وضعیت سوئیچ و لود اولیه صفحه
            $(document).on('change', '#gn_enable_floating_btn', toggleCtaSettingsLock);
            toggleCtaSettingsLock(); // فراخوانی اولیه برای هماهنگی وضعیت دیتابیس
        },

        // مدیریت آپلودر رسانه برای تصاویر آیتم‌ها
        initMediaUploader: function () {
            $(document).on('click', '.gn-upload-btn', function (e) {
                e.preventDefault();
                const $btn = $(this);
                const $wrapper = $btn.closest('.gn-visual-image-area');
                const $input = $wrapper.find('.slice-img-url');
                const $preview = $wrapper.find('.slice-img-preview');

                const frame = wp.media({
                    title: 'انتخاب تصویر جایزه (فقط یک فایل)',
                    button: { text: 'تایید انتخاب' },
                    multiple: false // مهندس جان، محدودیت انتخاب فقط یک تصویر اینجا اعمال شده
                });

                frame.on('select', function () {
                    const attachment = frame.state().get('selection').first().toJSON();
                    $input.val(attachment.url);
                    $preview.css({
                        'background-image': 'url(' + attachment.url + ')',
                        'background-size': 'contain',
                        'background-repeat': 'no-repeat',
                        'background-position': 'center'
                    }).html('');
                    GardoonakAdmin.updateWheelVisuals();
                });

                frame.open();
            });
        },

        handleWheelBuilder: function () {
            const self = this;
            const $container = $('#gn_slices_container');

            // ۱. لود اطلاعات گردونه
            this.loadSingleWheel = function () {
                $.ajax({
                    url: gardoonak_ajax.url,
                    type: 'POST',
                    data: {
                        action: 'gardoonak_get_wheel_data',
                        security: gardoonak_ajax.nonce,
                        id: 1
                    },
                    success: function (res) {
                        if (res.success && res.data) {
                            self.populateBuilder(res.data);
                        } else {
                            // مقادیر پیش‌فرض در صورت خالی بودن دیتابیس
                            self.createSliceDOM(0, { label: 'جایزه اول', color: '#ff4757' });
                            self.createSliceDOM(1, { label: 'پوچ', color: '#2ecc71', type: 'loss' });
                            self.updateWheelVisuals();
                        }
                    }
                });
            };

            // ۲. پر کردن فرم بیلدر
            this.populateBuilder = function (data) {
                const w = data.wheel;
                const slices = data.slices;

                $('#gn_wheel_id_input').val(1);

                try {
                    const sets = typeof w.settings === 'string' ? JSON.parse(w.settings) : w.settings;
                    if (sets) {
                        $('#gn_campaign_name').val(sets.campaign_name || '');
                        $('#wheel_spin_count').val(sets.spin || 8);
                        $('#wheel_spin_duration').val(sets.duration || 5);
                    }
                } catch (e) { }

                $container.empty();
                if (slices && slices.length > 0) {
                    slices.forEach((s, i) => {
                        let actionData = {};
                        try { actionData = JSON.parse(s.prize_value); } catch (e) { actionData = {}; }

                        self.createSliceDOM(i, {
                            label: s.label,
                            color: s.slice_color,
                            type: s.prize_type,
                            visualType: actionData.img ? 'image' : 'color', // تشخیص هوشمند نوع بصری
                            chance: s.probability,
                            img: actionData.img || '',
                            actionType: actionData.action_type || 'coupon',
                            val: actionData.val || '',
                        });
                    });
                }
                self.updateWheelVisuals();
            };

            // ۳. ساخت DOM هر پره (Slice)
            this.createSliceDOM = function (index, data = {}) {
                const defaults = {
                    label: 'آیتم جدید',
                    color: '#ff4757', // رنگ پیش‌فرض از پالت
                    type: 'win',
                    visualType: 'color',
                    chance: 10,
                    img: '',
                    actionType: 'coupon',
                    val: ''
                };
                const config = { ...defaults, ...data };

                const $templateSource = $('#gn_slice_template');
                if ($templateSource.length === 0) return;

                let template = $templateSource.html();
                template = template.replace(/{INDEX}/g, index);

                const $el = $(template);

                $el.find('.gn-slice-body').hide();
                $el.removeClass('is-open');
                $container.append($el);

                // پر کردن مقادیر فیلدها
                $el.find('.slice-label').val(config.label);
                $el.find('.slice-color').val(config.color);
                $el.find('.slice-chance').val(config.chance);
                $el.find('.slice-img-url').val(config.img);

                // فعال کردن دایره رنگی مربوطه
                $el.find(`.gn-color-circle[data-color="${config.color}"]`).addClass('active');

                if (config.img) {
                    $el.find('.slice-img-preview').css('background-image', `url(${config.img})`).html('');
                }

                $el.find(`input[name="slice_type_${index}"][value="${config.type}"]`).prop('checked', true);
                $el.find(`input[name="slice_visual_${index}"][value="${config.visualType}"]`).prop('checked', true);
                $el.find('.slice-action-type').val(config.actionType);

                if (config.actionType === 'link') $el.find('.slice-link-val').val(config.val);
                else $el.find('.slice-coupon-val').val(config.val);

                self.updateSliceLogic($el);
            };

            // --- رویدادهای تعاملی ---

            // کلیک روی دایره‌های رنگی آماده (جایگزین کالرپیکر)
            $container.on('click', '.gn-color-circle', function () {
                const $circle = $(this);
                const color = $circle.data('color');
                const $parent = $circle.closest('.gn-slice-item');

                $parent.find('.gn-color-circle').removeClass('active');
                $circle.addClass('active');
                $parent.find('.slice-color').val(color);

                self.updateWheelVisuals();
            });

            // تغییر نوع بصری (رنگ یا تصویر)
            $container.on('change', '.slice-visual-type', function () {
                const $row = $(this).closest('.gn-slice-item');
                self.updateSliceLogic($row);
                self.updateWheelVisuals();
            });

            // تغییر برنده/بازنده یا اکشن‌ها
            $container.on('change input', '.slice-type, .slice-action-type, .slice-label, .slice-chance', function () {
                const $row = $(this).closest('.gn-slice-item');
                self.updateSliceLogic($row);
                self.updateWheelVisuals();
            });

            // حذف آیتم
            $container.on('click', '.gn-slice-remove', function () {
                if (confirm('مهندس جان، این آیتم حذف شود؟')) {
                    $(this).closest('.gn-slice-item').remove();
                    self.updateWheelVisuals();
                }
            });

            $container.on('click', '.gn-slice-header', function (e) {
                // اگر روی دکمه حذف کلیک شد، عملیات باز و بسته شدن اجرا نشود
                if ($(e.target).hasClass('gn-slice-remove')) return;

                const $item = $(this).closest('.gn-slice-item');
                const $body = $(this).next('.gn-slice-body');

                // جابجایی وضعیت باز و بسته بودن
                $body.slideToggle(250);
                $item.toggleClass('is-open');

                // تغییر جهت آیکون (اختیاری اگر استایلش را داری)
                const $icon = $(this).find('.gn-slice-toggle-icon');
                $icon.toggleClass('dashicons-arrow-down-alt2 dashicons-arrow-up-alt2');
            });
            // دکمه افزودن شانس جدید
            $(document).off('click', '#gn_add_slice_btn').on('click', '#gn_add_slice_btn', function (e) {
                e.preventDefault();
                self.createSliceDOM($container.children().length);
                self.updateWheelVisuals();
            });

            // مدیریت وضعیت فعال/غیرفعال
            $('.gn-status-btn').on('click', function () {
                $('.gn-status-btn').removeClass('active');
                $(this).addClass('active');
                const status = $(this).data('status');
                $('#gn_wheel_status_input').val(status);
                if (status === 'inactive') $('#gn_builder_main_area').addClass('is-locked');
                else $('#gn_builder_main_area').removeClass('is-locked');
            });

            // دکمه ذخیره نهایی
            $('#gn_save_wheel_btn').on('click', function (e) {
                e.preventDefault();
                const $btn = $(this);
                let slices = [];

                $container.find('.gn-slice-item').each(function () {
                    const $row = $(this);
                    const actionType = $row.find('.slice-action-type').val();
                    const val = (actionType === 'link') ? $row.find('.slice-link-val').val() : $row.find('.slice-coupon-val').val();

                    slices.push({
                        label: $row.find('.slice-label').val(),
                        color: $row.find('.slice-color').val(),
                        type: $row.find('.slice-type:checked').val(),
                        probability: $row.find('.slice-chance').val(),
                        prize_value: JSON.stringify({
                            img: $row.find('.slice-visual-type:checked').val() === 'image' ? $row.find('.slice-img-url').val() : '',
                            action_type: actionType,
                            val: val
                        })
                    });
                });

                $btn.prop('disabled', true).text('در حال ذخیره...');

                $.ajax({
                    url: gardoonak_ajax.url,
                    type: 'POST',
                    data: {
                        action: 'gardoonak_save_wheel',
                        security: gardoonak_ajax.nonce,
                        wheel_id: 1,
                        wheel_config: {
                            campaign_name: $('#gn_campaign_name').val(),
                            spin: $('#wheel_spin_count').val(),
                            duration: $('#wheel_spin_duration').val()
                        },
                        slices: slices
                    },
                    success: function (res) {
                        alert(res.success ? 'تغییرات با موفقیت ذخیره شد مهندس جان!' : 'خطا در ذخیره اطلاعات!');
                    },
                    complete: function () { $btn.prop('disabled', false).text('ذخیره تغییرات نهایی'); }
                });
            });

            /* بخش چرخش آزمایشی - داخل handleWheelBuilder */

            // متغیری برای ذخیره زاویه فعلی که چرخش‌ها روی هم جمع شوند
            let currentRotation = 0;

            $(document).on('click', '#gn_test_spin', function (e) {
                e.preventDefault();
                const $wheel = $('#gn_live_wheel');
                const $btn = $(this);

                // ۱. جلوگیری از کلیک مجدد در حین چرخش
                $btn.prop('disabled', true).css('opacity', '0.5');

                // ۲. محاسبات فیزیک چرخش
                // ۵ دور کامل (۱۸۰۰ درجه) + یک زاویه رندوم برای واقعی شدن
                const extraDegrees = Math.floor(Math.random() * 360) + 1800;
                currentRotation += extraDegrees;

                // ۳. اعمال استایل چرخشی با CSS3
                $wheel.css({
                    'transition': 'transform 4s cubic-bezier(0.15, 0, 0.15, 1)', // شتاب ملایم در انتها
                    'transform': 'rotate(' + currentRotation + 'deg)'
                });

                // ۴. آزاد کردن دکمه بعد از اتمام انیمیشن (۴ ثانیه)
                setTimeout(function () {
                    $btn.prop('disabled', false).css('opacity', '1');

                    // مهندس جان، اینجا می‌توانیم برنده‌ی تست را هم تشخیص بدهیم (اختیاری)
                    console.log("تست چرخش با موفقیت انجام شد.");
                }, 4000);
            });

            this.updateWheelVisuals = function () {
                const $preview = $('#gn_live_wheel');
                const $container = $('#gn_slices_container');
                if (!$preview.length) return;
                $preview.empty();

                let slices = [];
                $container.find('.gn-slice-item').each(function () {
                    const visualType = $(this).find('.slice-visual-type:checked').val();
                    slices.push({
                        label: $(this).find('.slice-label').val() || 'جایزه',
                        color: $(this).find('.slice-color').val() || '#ddd',
                        img: visualType === 'image' ? $(this).find('.slice-img-url').val() : ''
                    });
                });

                if (slices.length === 0) return;

                const totalSlices = slices.length;
                const deg = 360 / totalSlices;

                // ۱. رسم گرادینت گردونه
                let gradientParts = slices.map((s, i) => `${s.color} ${i * deg}deg ${(i + 1) * deg}deg`);
                $preview.css('background', `conic-gradient(${gradientParts.join(', ')})`);

                // ۲. جاگذاری متون با محاسبات برداری
                slices.forEach((s, i) => {
                    // زاویه مرکز هر پره (بدون کسر ۹۰ درجه در این متد جدید)
                    const centerAngle = (i * deg) + (deg / 2);

                    const itemHtml = `
            <div class="gn-slice-content" style="
                position: absolute;
                top: 50%;
                left: 50%;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                width: 80px; /* عرض محدود برای تمرکز در لبه */
                text-align: center;
                pointer-events: none;
                z-index: 10;
                /* جادوی اصلی اینجاست: اول چرخش به سمت پره، بعد پرتاب به لبه (115px)، بعد چرخش متن */
                transform: translate(-50%, -50%) rotate(${centerAngle}deg) translateY(-110px) rotate(0deg);
            ">
                ${s.img ? `<img src="${s.img}" style="width:26px; height:26px; object-fit:contain; margin-bottom:5px;">` : ''}
                <span style="
                    color: #fff; 
                    font-size: 10px; 
                    font-weight: bold; 
                    text-shadow: 0 1px 3px rgba(0,0,0,0.9);
                    white-space: nowrap;
                    max-width: 75px;
                    display: block;
                ">${s.label}</span>
            </div>`;
                    $preview.append(itemHtml);
                });
            };

            this.loadSingleWheel();
        },

        // مدیریت نمایش شرطی فیلدها
        updateSliceLogic: function ($el) {
            // ۱. برنده یا بازنده
            const type = $el.find('.slice-type:checked').val();
            if (type === 'loss') {
                $el.find('.gn-win-options-area').hide();
                $el.find('.gn-loss-options-area').show();
            } else {
                $el.find('.gn-loss-options-area').hide();
                $el.find('.gn-win-options-area').show();

                // نوع جایزه (لینک یا کوپن)
                const actionType = $el.find('.slice-action-type').val();
                if (actionType === 'link') {
                    $el.find('.gn-action-coupon-box').hide();
                    $el.find('.gn-action-link-box').show();
                } else {
                    $el.find('.gn-action-coupon-box').show();
                    $el.find('.gn-action-link-box').hide();
                }
            }

            // ۲. رنگ یا تصویر
            const visualType = $el.find('.slice-visual-type:checked').val();
            if (visualType === 'image') {
                $el.find('.gn-visual-color-area').hide();
                $el.find('.gn-visual-image-area').show();
            } else {
                $el.find('.gn-visual-image-area').hide();
                $el.find('.gn-visual-color-area').show();
            }
        },

        // آپدیت گرافیکی گردونه زنده
        updateWheelVisuals: function () {
            const $preview = $('#gn_live_wheel');
            const $container = $('#gn_slices_container');
            if (!$preview.length) return;
            $preview.empty();

            let slices = [];
            $container.find('.gn-slice-item').each(function () {
                const visualType = $(this).find('.slice-visual-type:checked').val();
                slices.push({
                    label: $(this).find('.slice-label').val() || 'جایزه',
                    color: $(this).find('.slice-color').val() || '#ddd',
                    img: visualType === 'image' ? $(this).find('.slice-img-url').val() : ''
                });
            });

            if (slices.length === 0) return;

            const deg = 360 / slices.length;
            let gradientParts = slices.map((s, i) => `${s.color} ${i * deg}deg ${(i + 1) * deg}deg`);
            $preview.css('background', `conic-gradient(${gradientParts.join(', ')})`);

            slices.forEach((s, i) => {
                const rotation = (i * deg) + (deg / 2);
                $preview.append(`
                    <div class="gn-wheel-element" style="transform:translate(-50%, -50%) rotate(${rotation}deg);">
                        <div style="text-align:center;">
                            ${s.img ? `<img src="${s.img}" style="width:25px; height:25px; display:block; margin:0 auto 5px;">` : ''}
                            <span style="color:#fff; font-size:10px; font-weight:bold; text-shadow:0 1px 2px rgba(0,0,0,0.5);">${s.label}</span>
                        </div>
                    </div>`);
            });
        },

        getRandomColor: function () {
            const colors = ['#ff4757', '#2ecc71', '#3498db', '#f1c40f', '#9b59b6'];
            return colors[Math.floor(Math.random() * colors.length)];
        }
    };

    $(document).ready(function () { GardoonakAdmin.init(); });

})(jQuery);