jQuery(document).ready(function ($) {
    "use strict";

    /* =======================================================
       0. افکت دکمه ذخیره + تنظیم فلگ نوتیفیکیشن
    ======================================================= */
    $(document).on('click', 'input[type="submit"][name="submit"]', function() {
        var $btn = $(this);
        if ($btn.hasClass('button-primary')) {
            $btn.val('در حال ذخیره اطلاعات...');
            $btn.css({'opacity': '0.8', 'cursor': 'wait'});
            localStorage.setItem('reyhan_just_saved', 'yes');
        }
    });

    /* =======================================================
       1. تنظیمات عمومی و ابزارها
    ======================================================= */
    window.LocalData = (typeof reyhan_admin_ajax !== 'undefined') ? reyhan_admin_ajax : { ajax_url: ajaxurl, nonce: '', canned_responses: [] };
    window.DEFAULT_AVATAR = (typeof rp_default_avatar !== 'undefined') ? rp_default_avatar : '';

    window.safeStorage = function (key, value = null) {
        try {
            if (value !== null) localStorage.setItem(key, value);
            else return localStorage.getItem(key);
        } catch (e) { return null; }
    };

    function switchTab(targetId) {
        var $target = $('#' + targetId);
        if ($target.length === 0) return false;
        $('.rp-tab-pane').hide().removeClass('active');
        $target.fadeIn(200).addClass('active');
        $('.rp-tabs-nav li').removeClass('active');
        $('.rp-tabs-nav li[data-tab="' + targetId + '"]').addClass('active');
        safeStorage('reyhan_active_tab', targetId);
        return true;
    }

    if ($('.rp-tabs-nav').length > 0) {
        $(document).on('click', '.rp-tabs-nav li', function (e) {
            e.preventDefault();
            var target = $(this).data('tab');
            if (target) switchTab(target);
        });
        var savedTab = safeStorage('reyhan_active_tab');
        if (!savedTab || !switchTab(savedTab)) {
            var firstTabId = $('.rp-tabs-nav li:first-child').data('tab');
            switchTab(firstTabId);
        }
    }

    $(document).on('change', '.rp-section-toggle', function () {
        var targetId = $(this).data('target');
        if ($(this).is(':checked')) $('#' + targetId).slideDown();
        else $('#' + targetId).slideUp();
    });
    $('.rp-section-toggle').trigger('change');

    /* =======================================================
       2. مدیا آپلودر
    ======================================================= */
    $(document).on('click', '.rp-upload-btn-modern, .rp-preview-circle, .rp-media-upload-btn', function (e) {
        e.preventDefault();
        var $button = $(this);
        var wrap = $button.closest('.rp-media-upload-modern-wrap, .rp-image-uploader-area');
        var isMenuIcon = $button.hasClass('rp-media-upload-btn');
        var isProfile = wrap.find('.rp-preview-img').length > 0;
        var custom_uploader = wp.media({
            title: isMenuIcon ? 'انتخاب آیکون SVG' : 'انتخاب تصویر',
            button: { text: 'استفاده از این فایل' },
            library: { type: isMenuIcon ? 'image/svg+xml' : 'image' },
            multiple: false
        });
        custom_uploader.on('select', function () {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            if (isProfile && !isMenuIcon) {
                var allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
                if (allowedTypes.indexOf(attachment.mime) === -1) { alert('فقط فرمت‌های تصویر مجاز است.'); return; }
            }
            if (isMenuIcon && attachment.mime !== 'image/svg+xml') { alert('فقط SVG مجاز است.'); return; }
            wrap.find('input[type="text"], input[type="hidden"]').first().val(attachment.url).trigger('change');
            var preview = wrap.find('img');
            if (preview.length) { preview.attr('src', attachment.url); wrap.addClass('has-image'); }
            if (isMenuIcon) { $button.text('تغییر فایل').css({'background':'#e8f5e9'}); }
            wrap.find('.rp-remove-btn-modern').fadeIn();
        });
        custom_uploader.open();
    });

    $(document).on('click', '.rp-remove-btn-modern', function (e) {
        e.preventDefault();
        var wrap = $(this).closest('.rp-media-upload-modern-wrap');
        wrap.find('.rp-media-input').val('').trigger('change');
        var img = wrap.find('.rp-preview-img');
        if (img.data('default')) img.attr('src', img.data('default'));
        $(this).fadeOut();
        wrap.removeClass('has-image');
    });

    /* =======================================================
       3. کامپوننت‌های UI (اصلاح شده: کد تنظیم هدرها اضافه شد)
    ======================================================= */
    
    // --- کدی که تیترها را تمام‌عرض می‌کند (درخواستی شما) ---
    jQuery(function ($) {
        $('.form-table tr').each(function () {
            var $tr = $(this);
            var $header = $tr.find('.rp-section-header');
            if ($header.length) {
                var $td = $tr.children('td');
                // حذف ستون سمت چپ (th) و تمام عرض کردن ستون محتوا
                $td.attr('colspan', 2);
                $tr.children('th').remove();
            }
        });
    });
    // -----------------------------------------------------

    $(document).on('click', '.rp-add-row', function () {
        var wrap = $(this).closest('.rp-repeater-wrap');
        var list = wrap.find('.rp-repeater-list');
        var id = wrap.data('id');
        var fields = $(this).data('fields');
        var idx = new Date().getTime();
        var html = '<div class="rp-repeater-item" style="display:none;"><div class="rp-repeater-inputs">';
        $.each(fields, function (key, label) {
            var name = 'reyhan_options[' + id + '][' + idx + '][' + key + ']';
            html += `<div class="rp-input-group-row"><label class="rp-input-label">${label}</label><input type="text" name="${name}" class="rp-full-width"></div>`;
        });
        html += '</div><div class="rp-repeater-actions"><button type="button" class="button rp-remove-row"><span class="dashicons dashicons-no"></span></button></div></div>';
        list.append(html); list.find('.rp-repeater-item:last').fadeIn();
    });

    $(document).on('click', '.rp-add-row-modern', function (e) {
        e.preventDefault();
        var wrap = $(this).closest('.rp-repeater-wrap');
        var list = wrap.find('.rp-repeater-list');
        var id = wrap.data('id');
        var idx = new Date().getTime();
        var html = `
        <div class="rp-canned-item" style="display:none;">
            <div class="rp-drag-handle"><span class="dashicons dashicons-move"></span></div>
            <div class="rp-canned-inputs">
                <div><input type="text" name="reyhan_options[${id}][${idx}][title]" class="rp-mod-input-sm" placeholder="عنوان"></div>
                <div><textarea name="reyhan_options[${id}][${idx}][content]" class="rp-mod-input-sm" placeholder="متن"></textarea></div>
            </div>
            <button type="button" class="rp-btn-delete rp-remove-row-circle"><span class="dashicons dashicons-trash"></span></button>
        </div>`;
        list.append(html); list.find('.rp-canned-item:last').fadeIn();
    });

    $(document).on('click', '.rp-remove-row, .rp-remove-row-circle', function (e) {
        e.preventDefault();
        if (confirm('حذف شود؟')) $(this).closest('.rp-repeater-item, .rp-canned-item').slideUp(200, function(){$(this).remove();});
    });

    if ($.fn.sortable) $('.rp-repeater-list').sortable({ handle: '.rp-item-header, .rp-drag-handle', placeholder: "ui-state-highlight", opacity: 0.8 });
    if ($.fn.select2) $('.rp-select2').select2({ width: '100%', dir: "rtl", dropdownCssClass: 'rp-select2-drop' });
    if ($.fn.wpColorPicker) $('.rp-color-field').wpColorPicker();

    $('#rp_admin_state').on('change', function () {
        var state = $(this).val(); var city = $('#rp_admin_city'); city.empty().append('<option value="">انتخاب...</option>');
        const cities = { 'Tehran': ['تهران','شهریار'], 'Alborz': ['کرج','هشتگرد'], 'Isfahan': ['اصفهان','کاشان'], 'Fars': ['شیراز'], 'Razavi Khorasan': ['مشهد'] };
        if (cities[state]) cities[state].forEach(c => city.append(`<option value="${c}">${c}</option>`));
    });

    $(document).on('click', '.rp-mini-tabs-nav li', function () {
        var $t = $(this); var method = $t.data('method'); var $w = $t.closest('.rp-mini-tabs-wrapper');
        $w.find('li').removeClass('active'); $t.addClass('active');
        $w.find('.rp-mini-tab-content').hide(); $w.find('.content-' + method).fadeIn(200);
        var $inp = $w.prev('.rp-sms-method-input');
        if(!$inp.length) $inp = $('#rp_sms_method_input');
        if(!$inp.length) $inp = $w.find('.rp-sms-method-input');
        $inp.val(method).trigger('change');
    });

    /* =======================================================
       4. سیستم نوتیفیکیشن سراسری (Global Toast)
    ======================================================= */
    window.rpShowToast = function(msg, type = 'success') {
        $('.rp-modern-toast').remove(); 
        var icon = (type === 'success') ? 'dashicons-saved' : (type === 'error') ? 'dashicons-no' : 'dashicons-warning';
        $('body').append(`<div class="rp-modern-toast rp-toast-${type}"><span class="dashicons ${icon}"></span><span>${msg}</span></div>`);
        requestAnimationFrame(() => { $('.rp-modern-toast').addClass('show'); });
        setTimeout(function(){ 
            $('.rp-modern-toast').removeClass('show');
            setTimeout(function(){ $('.rp-modern-toast').remove(); }, 500);
        }, 3000);
    };

    /* =======================================================
       5. بررسی نهایی: نمایش پیام بر اساس LocalStorage
    ======================================================= */
    try {
        var currentUrl = new URL(window.location.href);
        var param = currentUrl.searchParams.get('settings-updated');
        var justSaved = localStorage.getItem('reyhan_just_saved');

        if (justSaved === 'yes' || param === 'true' || param === '1') {
            window.rpShowToast('تغییرات شما با موفقیت ذخیره شد.', 'success');
            localStorage.removeItem('reyhan_just_saved');
            if (param) {
                currentUrl.searchParams.delete('settings-updated');
                window.history.replaceState({}, '', currentUrl.toString());
            }
        }
    } catch (e) {
        console.error('ReyhanPanel: Init Error', e);
    }
});