<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="wrap reyhanpanel-wrap">
    <?php 
    if ( file_exists( \REYHAN_DIR . 'templates/admin/partials/admin-header.php' ) ) {
        include \REYHAN_DIR . 'templates/admin/partials/admin-header.php';
    } 
    ?>
    
    <?php 
    if ( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
        echo '<div id="reyhan-toast-msg" class="rp-modern-toast"><span class="dashicons dashicons-saved"></span> <span>'.esc_html__('تغییرات با موفقیت ذخیره شد.', 'reyhan-panel').'</span></div>';
    }
    ?>

    <form method="post" action="options.php">
        <?php settings_fields('reyhan_master_group'); ?>
        <div class="rp-settings-container">
            <div class="rp-settings-sidebar">
                <div class="rp-sidebar-logo"><img src="<?php echo REYHAN_URL . 'assets/images/logo.png'; ?>" alt="Logo"></div>
                <ul class="rp-tabs-nav">
                    <li class="active" data-tab="tab-style-login"><span class="dashicons dashicons-lock"></span> <?php esc_html_e('استایل ورود / عضویت', 'reyhan-panel'); ?></li>
                    <li data-tab="tab-style-panel"><span class="dashicons dashicons-layout"></span> <?php esc_html_e('استایل پنل کاربری', 'reyhan-panel'); ?></li>
                </ul>
                <div class="rp-save-box">
                    <?php submit_button(__('ذخیره تغییرات', 'reyhan-panel'), 'primary', 'submit', false); ?>
                    <div class="rp-version-info"><?php printf( esc_html__('نسخه %s', 'reyhan-panel'), REYHAN_VERSION ); ?></div>
                </div>
            </div>
            <div class="rp-settings-content">
                <div id="tab-style-login" class="rp-tab-pane active">
                    <h2><?php esc_html_e('ظاهر صفحه ورود', 'reyhan-panel'); ?></h2>
                    <table class="form-table"><?php do_settings_fields('reyhan-user-panel', 'sec_style_login'); ?></table>
                </div>
                <div id="tab-style-panel" class="rp-tab-pane">
                    <h2><?php esc_html_e('ظاهر داشبورد', 'reyhan-panel'); ?></h2>
                    <table class="form-table"><?php do_settings_fields('reyhan-user-panel', 'sec_style_panel'); ?></table>
                </div>
            </div>
        </div>
    </form>
</div>