<?php 
defined('ABSPATH') || exit; 

// ۱. تشخیص صفحه جاری
$current_page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';

// ۲. تنظیمات صفحات (آیکون، عنوان، توضیحات)
$pages_config = [
    'reyhan-settings' => [
        'title' => __('تنظیمات عمومی', 'reyhan-panel'),
        'desc'  => __('مدیریت تنظیمات اصلی، درگاه‌های پیامک و ایمیل', 'reyhan-panel'),
        'icon'  => 'dashicons-admin-settings'
    ],
    'reyhan-user-panel' => [
        'title' => __('استایل پنل کاربری', 'reyhan-panel'),
        'desc'  => __('شخصی‌سازی ظاهر فرم ورود و داشبورد کاربران', 'reyhan-panel'),
        'icon'  => 'dashicons-layout'
    ],
    'reyhan-notifications' => [
        'title' => __('اطلاعیه‌های پنل', 'reyhan-panel'),
        'desc'  => __('مدیریت اعلانات عمومی و پیام‌های سراسری', 'reyhan-panel'),
        'icon'  => 'dashicons-megaphone'
    ],
    'reyhan-personal-msg' => [
        'title' => __('پیام شخصی', 'reyhan-panel'),
        'desc'  => __('ارسال پیام اختصاصی، یا ایمیل به کاربران خاص', 'reyhan-panel'),
        'icon'  => 'dashicons-email-alt'
    ],
    'reyhan-export-data' => [
        'title' => __('استخراج داده', 'reyhan-panel'),
        'desc'  => __('دریافت خروجی های مختلف از داده های کاربران', 'reyhan-panel'),
        'icon'  => 'dashicons-database-export'
    ],
    'reyhan-tickets' => [
        'title' => __('مدیریت تیکت‌ها', 'reyhan-panel'),
        'desc'  => __('پاسخگویی به درخواست‌های پشتیبانی کاربران', 'reyhan-panel'),
        'icon'  => 'dashicons-tickets-alt'
    ],
];

// ۳. دریافت اطلاعات صفحه فعلی (یا پیش‌فرض)
$active_data = $pages_config[$current_page] ?? [
    'title' => __('پنل ریحان', 'reyhan-panel'),
    'desc'  => __('مدیریت سیستم', 'reyhan-panel'),
    'icon'  => 'dashicons-admin-generic'
];
?>

<div class="rp-header-hero">
    <div class="rp-hero-icon-box">
        <span class="dashicons <?php echo esc_attr($active_data['icon']); ?>"></span>
    </div>
    <div class="rp-hero-content">
        <h1><?php echo esc_html($active_data['title']); ?></h1>
        <p><?php echo esc_html($active_data['desc']); ?></p>
    </div>
</div>