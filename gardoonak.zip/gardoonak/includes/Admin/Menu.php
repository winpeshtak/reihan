<?php
namespace Gardoonak\Admin;

defined( 'ABSPATH' ) || exit;

class Menu {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'register_custom_menus' ] );
    }

    /**
     * ثبت منوی اصلی و زیرمنوهای سه‌گانه
     */
    public function register_custom_menus() {
        $capability = 'manage_options';
        $icon_url   = GARDOONAK_URL . 'assets/images/logo.svg';

        // ۱. منوی اصلی (گردونک)
        add_menu_page(
            'گردونک',
            'گردونک',
            $capability,
            'gardoonak',
            [ $this, 'render_general_settings_page' ], // صفحه پیش‌فرض (تنظیمات عمومی)
            $icon_url,
            25
        );

        // ۲. زیرمنو: تنظیمات عمومی (همان صفحه اصلی منو)
        add_submenu_page(
            'gardoonak',
            'تنظیمات عمومی',
            'تنظیمات عمومی',
            $capability,
            'gardoonak',
            [ $this, 'render_general_settings_page' ]
        );

        // ۳. زیرمنو: گردونه‌ها
        add_submenu_page(
            'gardoonak',
            'مدیریت گردونه‌ها',
            'گردونه‌ها',
            $capability,
            'gardoonak-wheels',
            [ $this, 'render_wheels_management_page' ]
        );

        // ۴. زیرمنو: آمار و داده‌ها
        add_submenu_page(
            'gardoonak',
            'آمار و داده‌ها',
            'آمار و داده‌ها',
            $capability,
            'gardoonak-stats',
            [ $this, 'render_statistics_page' ]
        );
    }

    /**
     * رندر صفحه: تنظیمات عمومی
     */
    public function render_general_settings_page() {
        echo '<div class="wrap"><h1>تنظیمات عمومی گردونک</h1><p>بخش تنظیمات پایه، لایسنس و پیامک در اینجا قرار می‌گیرد.</p></div>';
    }

    /**
     * رندر صفحه: مدیریت گردونه‌ها
     */
    public function render_wheels_management_page() {
        echo '<div class="wrap"><h1>مدیریت گردونه‌ها</h1><p>طراحی ظاهر گردونه و تعریف اسلایس‌ها (جوایز) در این بخش انجام می‌شود.</p></div>';
    }

    /**
     * رندر صفحه: آمار و داده‌ها
     */
    public function render_statistics_page() {
        echo '<div class="wrap"><h1>آمار و داده‌ها</h1><p>لیست برندگان، کدهای تخفیف صادر شده و تحلیل رفتار کاربران در این بخش قابل مشاهده است.</p></div>';
    }
}