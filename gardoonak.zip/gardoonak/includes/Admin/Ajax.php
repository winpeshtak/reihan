<?php
namespace Gardoonak\Admin;

defined( 'ABSPATH' ) || exit;

class Ajax {

    public function __construct() {
        // اتصال هوک به تابع صحیح مهندس جان
        add_action( 'wp_ajax_gardoonak_save_settings', [ $this, 'save_general_settings' ] );
        add_action( 'wp_ajax_gardoonak_save_wheel', [ $this, 'save_wheel_data' ] );
        add_action( 'wp_ajax_gardoonak_get_wheels', [ $this, 'get_wheels_list' ] );
        add_action( 'wp_ajax_gardoonak_get_wheel_data', [ $this, 'get_wheel_data' ] );
        add_action( 'wp_ajax_gardoonak_delete_wheel', [ $this, 'delete_wheel' ] );
        add_action( 'wp_ajax_gardoonak_search_pages', [ $this, 'search_pages' ] );
    }

    /**
     * ذخیره تنظیمات عمومی (فرم تب‌ها)
     */
    public function save_general_settings() {
        check_ajax_referer( 'gardoonak_nonce', 'security' );
        parse_str( $_POST['form_data'], $settings );

        // فقط مواردی که واقعاً تیک‌باکس هستند (اگر تیک نخورند ارسال نمی‌شوند)
        $checkboxes = [
            'enable_floating_btn', 'device_desktop', 'device_tablet', 'device_mobile',
            'field_name_enable', 'field_email_enable', 'field_phone_enable'
        ];

        // ۱. ذخیره چک‌باکس‌ها
        foreach ( $checkboxes as $key ) {
            update_option( "gardoonak_{$key}", isset($settings[$key]) ? '1' : '0' );
        }

        // ۲. ذخیره سایر تنظیمات (رادیوها مثل صوتی/انفجار و فیلدهای متنی)
        foreach ( $settings as $key => $value ) {
            if ( ! in_array($key, $checkboxes) ) {
                update_option( "gardoonak_{$key}", sanitize_text_field($value) );
            }
        }
        
        wp_send_json_success( ['message' => 'تغییرات با موفقیت در دیتابیس ثبت شد مهندس جان!'] );
    }

    // متد جستجوی لایو (مورد ۲)
    public function search_pages() {
        check_ajax_referer( 'gardoonak_nonce', 'security' );
        $pages = get_posts([ 'post_type' => 'page', 's' => $_POST['q'], 'posts_per_page' => 10 ]);
        $results = array_map(function($p) { return ['id' => $p->ID, 'title' => $p->post_title]; }, $pages);
        wp_send_json_success( $results );
    }

    /**
     * ذخیره و بروزرسانی گردونه و پره‌ها
     */
    public function save_wheel_data() {
        check_ajax_referer( 'gardoonak_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }

        global $wpdb;
        $wheels_table = $wpdb->prefix . 'gardoonak_wheels';
        $slices_table = $wpdb->prefix . 'gardoonak_slices';

        $wheel_id     = isset( $_POST['wheel_id'] ) ? intval( $_POST['wheel_id'] ) : 0;
        $wheel_title  = isset( $_POST['wheel_title'] ) ? sanitize_text_field( $_POST['wheel_title'] ) : 'گردونه بدون عنوان';
        $wheel_config = isset( $_POST['wheel_config'] ) ? $_POST['wheel_config'] : [];
        $slices       = isset( $_POST['slices'] ) ? $_POST['slices'] : [];

        // آماده‌سازی داده‌های گردونه
        $wheel_data = [
            'title'      => $wheel_title,
            'settings'   => json_encode( $wheel_config ),
            'status'     => 'active',
            'created_at' => current_time( 'mysql' )
        ];

        // بررسی: آپدیت یا ایجاد جدید؟
        if ( $wheel_id > 0 ) {
            // آپدیت گردونه موجود
            $wpdb->update( $wheels_table, $wheel_data, [ 'id' => $wheel_id ] );
        } else {
            // ایجاد گردونه جدید
            $wpdb->insert( $wheels_table, $wheel_data );
            $wheel_id = $wpdb->insert_id;
        }

        // حذف پره‌های قبلی و ذخیره پره‌های جدید
        $wpdb->delete( $slices_table, [ 'wheel_id' => $wheel_id ] );

        foreach ( $slices as $slice ) {
            $wpdb->insert( $slices_table, [
                'wheel_id'    => $wheel_id,
                'label'       => sanitize_text_field( $slice['label'] ),
                'prize_type'  => sanitize_text_field( $slice['type'] ),
                'prize_value' => sanitize_text_field( $slice['code'] ),
                'probability' => intval( $slice['chance'] ),
                'slice_color' => sanitize_hex_color( $slice['color'] )
            ] );
        }

        wp_send_json_success( [ 'message' => 'گردونه و جوایز با موفقیت ذخیره شدند.', 'id' => $wheel_id ] );
    }

    /**
     * دریافت لیست تمام گردونه‌ها
     */
    public function get_wheels_list() {
        check_ajax_referer( 'gardoonak_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }

        global $wpdb;
        $wheels_table = $wpdb->prefix . 'gardoonak_wheels';

        // دریافت لیست گردونه‌ها به ترتیب جدیدترین
        $wheels = $wpdb->get_results( 
            "SELECT id, title, created_at, status FROM $wheels_table ORDER BY id DESC",
            ARRAY_A 
        );

        if ( $wheels ) {
            wp_send_json_success( $wheels );
        } else {
            wp_send_json_success( [] );
        }
    }

    /**
     * دریافت اطلاعات کامل یک گردونه برای ویرایش
     */
    public function get_wheel_data() {
        check_ajax_referer( 'gardoonak_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }

        $wheel_id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;

        if ( ! $wheel_id ) {
            wp_send_json_error( [ 'message' => 'شناسه گردونه معتبر نیست.' ] );
        }

        global $wpdb;
        $wheels_table = $wpdb->prefix . 'gardoonak_wheels';
        $slices_table = $wpdb->prefix . 'gardoonak_slices';

        // دریافت اطلاعات گردونه
        $wheel = $wpdb->get_row( 
            $wpdb->prepare( "SELECT * FROM $wheels_table WHERE id = %d", $wheel_id ),
            ARRAY_A 
        );

        if ( ! $wheel ) {
            wp_send_json_error( [ 'message' => 'گردونه یافت نشد.' ] );
        }

        // دریافت پره‌های گردونه
        $slices = $wpdb->get_results( 
            $wpdb->prepare( "SELECT * FROM $slices_table WHERE wheel_id = %d", $wheel_id ),
            ARRAY_A 
        );

        wp_send_json_success( [
            'wheel'  => $wheel,
            'slices' => $slices ?: []
        ] );
    }

    /**
     * حذف گردونه و پره‌های مرتبط
     */
    public function delete_wheel() {
        check_ajax_referer( 'gardoonak_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }

        $wheel_id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;

        if ( ! $wheel_id ) {
            wp_send_json_error( [ 'message' => 'شناسه گردونه معتبر نیست.' ] );
        }

        global $wpdb;
        $wheels_table = $wpdb->prefix . 'gardoonak_wheels';
        $slices_table = $wpdb->prefix . 'gardoonak_slices';

        // حذف پره‌های مرتبط
        $wpdb->delete( $slices_table, [ 'wheel_id' => $wheel_id ] );

        // حذف خود گردونه
        $deleted = $wpdb->delete( $wheels_table, [ 'id' => $wheel_id ] );

        if ( $deleted ) {
            wp_send_json_success( [ 'message' => 'گردونه با موفقیت حذف شد.' ] );
        } else {
            wp_send_json_error( [ 'message' => 'خطا در حذف گردونه.' ] );
        }
    }

    public function gardoonak_save_settings() {
        check_ajax_referer( 'gardoonak_nonce', 'security' );
        parse_str( $_POST['form_data'], $settings );

        // لیست کلیدهایی که چک‌باکس هستند (بسیار مهم!)
        $checkboxes = [
            'enable_floating_btn',
            'device_desktop', 'device_tablet', 'device_mobile',
            'field_name_enable', 'field_email_enable', 'field_phone_enable',
            'effect_confetti', 'sound_spin', 'sound_result',
            'trigger_time', 'trigger_scroll'
        ];

        // ابتدا همه چک‌باکس‌ها را به عنوان خاموش (0) ذخیره کن، مگر اینکه در فرم تیک خورده باشند
        foreach ( $checkboxes as $key ) {
            $val = isset( $settings[$key] ) ? '1' : '0';
            update_option( 'gardoonak_' . $key, $val );
        }

        // ذخیره بقیه فیلدها (رادیو باتن‌ها و اعداد)
        foreach ( $settings as $key => $value ) {
            if ( ! in_array( $key, $checkboxes ) ) {
                update_option( 'gardoonak_' . $key, sanitize_text_field( $value ) );
            }
        }

        wp_send_json_success( [ 'message' => 'تغییرات با موفقیت ذخیره شد مهندس جان!' ] );
    }
}