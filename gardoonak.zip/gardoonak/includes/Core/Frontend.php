<?php
namespace Gardoonak\Core;

defined( 'ABSPATH' ) || exit;

/**
 * مدیریت بخش نمایش در فرانت‌اکشن (سمت کاربر)
 */
class Frontend {

    public function __construct() {
        // هوک برای چاپ HTML در فوتر تمام صفحات
        add_action( 'wp_footer', [ $this, 'render_wheel_popup' ] );
    }

    /**
     * رندر کردن دکمه شناور و مودال گردونه
     */
    public function render_wheel_popup() {
        // فعلاً به صورت پیش‌فرض آیکون را می‌گذاریم (در آینده از تنظیمات خوانده می‌شود)
        $float_icon = plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/images/SVG/float-default.svg';
        ?>
        
        <div class="gn-floating-trigger" id="gn_trigger_btn">
            <img src="<?php echo esc_url( $float_icon ); ?>" alt="گردونه شانس">
        </div>

        <div class="gn-frontend-overlay" id="gn_wheel_modal">
            <div class="gn-popup-card">
                <div class="gn-close-popup" id="gn_close_wheel">&times;</div>
                
                <div class="gn-form-section">
                    <h2>شانست رو امتحان کن!</h2>
                    <p>اطلاعاتت رو وارد کن و با چرخاندن گردونه، برنده جوایز ارزشمند ما باش.</p>
                    
                    <div class="gn-field-group">
                        <input type="text" id="gn_user_name" class="gn-input-field" placeholder="نام و نام خانوادگی">
                    </div>
                    <div class="gn-field-group">
                        <input type="tel" id="gn_user_phone" class="gn-input-field" placeholder="شماره موبایل (مثلا ۰۹۱۲...)">
                    </div>
                    
                    <button class="gn-spin-button" id="gn_start_spin">بچرخون و برنده شو!</button>
                </div>

                <div class="gn-wheel-section">
                    <div class="gardoonak-pointer"></div>
                    <canvas id="gardoonak-canvas" width="400" height="400"></canvas>
                </div>
            </div>
        </div>
        <?php
    }
}