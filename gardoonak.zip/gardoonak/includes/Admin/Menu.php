<?php
namespace Gardoonak\Admin;

defined( 'ABSPATH' ) || exit;

class Menu {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'register_custom_menus' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_init', [ $this, 'check_license_and_redirect' ] );
        add_filter( 'admin_body_class', [ $this, 'add_wizard_body_class' ] );

        // اکشن AJAX برای فعال‌سازی لایسنس
        add_action( 'wp_ajax_gardoonak_activate_license', [ $this, 'handle_license_activation' ] );
    }

    public function add_wizard_body_class( $classes ) {
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'gardoonak-activation' ) {
            return "$classes gardoonak-wizard-mode";
        }
        return $classes;
    }

    public function check_license_and_redirect() {
        if ( $this->is_license_active() ) {
            return;
        }

        if ( isset( $_GET['page'] ) && strpos( $_GET['page'], 'gardoonak' ) !== false ) {
            if ( $_GET['page'] !== 'gardoonak-activation' ) {
                wp_redirect( admin_url( 'admin.php?page=gardoonak-activation' ) );
                exit;
            }
        }
    }

    public function enqueue_assets( $hook ) {
        $version = defined('GARDOONAK_VERSION') ? GARDOONAK_VERSION : time();

        if ( strpos( $hook, 'gardoonak' ) !== false ) {
            // ۱. بارگذاری UI Kit و سیستم نوتیفیکیشن سراسری
            wp_enqueue_style( 'gardoonak-ui-kit', GARDOONAK_URL . 'assets/css/admin/ui-kit.css', [], $version );
            wp_enqueue_script( 'gardoonak-notifications', GARDOONAK_URL . 'assets/js/admin/notifications.js', ['jquery'], $version, true );

            // ۲. اگر در صفحه ویزارد هستیم
            if ( strpos( $hook, 'gardoonak-activation' ) !== false ) {
                wp_enqueue_style( 'gardoonak-wizard', GARDOONAK_URL . 'assets/css/admin/wizard.css', ['gardoonak-ui-kit', 'dashicons'], $version );
                wp_enqueue_script( 'gardoonak-wizard', GARDOONAK_URL . 'assets/js/admin/wizard.js', ['jquery', 'gardoonak-notifications'], $version, true );
                
                wp_localize_script( 'gardoonak-wizard', 'gardoonak_assets', [
                    'ajax_url'    => admin_url( 'admin-ajax.php' ),
                    'nonce'       => wp_create_nonce( 'gardoonak_wizard_nonce' ),
                    'img_success' => GARDOONAK_URL . 'assets/images/SVG/wizard-success.svg',
                    'img_error'   => GARDOONAK_URL . 'assets/images/SVG/wizard-error.svg',
                    'img_key'     => GARDOONAK_URL . 'assets/images/SVG/wizard-key.svg',
                ]);
            } 
            // ۳. سایر صفحات پنل
            else {
                wp_enqueue_style( 'gardoonak-layout', GARDOONAK_URL . 'assets/css/admin/layout.css', ['gardoonak-ui-kit'], $version );
                wp_enqueue_style( 'gardoonak-dashboard', GARDOONAK_URL . 'assets/css/admin/dashboard.css', ['gardoonak-layout'], $version );
                wp_enqueue_script( 'gardoonak-admin-js', GARDOONAK_URL . 'assets/js/admin/app.js', ['jquery', 'gardoonak-notifications'], $version, true );
            }
        }
    }

    public function register_custom_menus() {
        $capability = 'manage_options';
        $icon_url   = GARDOONAK_URL . 'assets/images/logo.svg';

        add_submenu_page( null, 'فعال‌سازی گردونک', 'فعال‌سازی', $capability, 'gardoonak-activation', [ $this, 'render_activation_wizard' ] );
        add_menu_page( 'گردونک', 'گردونک', $capability, 'gardoonak', [ $this, 'render_general_settings_page' ], $icon_url, 25 );
        add_submenu_page( 'gardoonak', 'تنظیمات عمومی', 'تنظیمات عمومی', $capability, 'gardoonak', [ $this, 'render_general_settings_page' ] );
        add_submenu_page( 'gardoonak', 'مدیریت گردونه‌ها', 'گردونه‌ها', $capability, 'gardoonak-wheels', [ $this, 'render_wheels_management_page' ] );
        add_submenu_page( 'gardoonak', 'آمار و داده‌ها', 'آمار و داده‌ها', $capability, 'gardoonak-stats', [ $this, 'render_statistics_page' ] );
    }

    public function handle_license_activation() {
        check_ajax_referer( 'gardoonak_wizard_nonce', 'security' );
        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( $_POST['license_key'] ) : '';

        if ( $license_key === '123456789' ) {
            update_option( 'gardoonak_license_key', $license_key );
            update_option( 'gardoonak_license_status', 'active' );
            wp_send_json_success( [ 'message' => 'لایسنس با موفقیت ثبت و فعال شد.' ] );
        } else {
            wp_send_json_error( [ 'message' => 'لایسنس معتبر نیست.' ] );
        }
    }

    private function is_license_active() {
        return get_option( 'gardoonak_license_status' ) === 'active' && get_option( 'gardoonak_license_key' ) === '123456789';
    }

    public function render_activation_wizard() {
        ?>
        <div class="gardoonak-wizard-wrapper">
            <div class="gardoonak-wizard-card">
                <div class="wizard-icon-container" id="wizard-icon-box">
                    <img src="<?php echo GARDOONAK_URL . 'assets/images/SVG/wizard-key.svg'; ?>" alt="License Key">
                </div>
                <h1 class="wizard-title">لایسنس گردونک رو وارد کن</h1>
                <p class="wizard-desc">برای استفاده کامل از افزونه لازمه که لایسنس قانونی رو در باکس زیر وارد کنی.</p>

                <div class="wizard-form">
                    <input type="text" id="license_key_input" class="gn-input" autocomplete="off">
                    <button id="btn-activate-wizard" class="gn-btn">
                        <span>بررسی کد</span>
                        <div class="gn-btn-icon">
                            <span class="dashicons dashicons-arrow-left-alt"></span>
                        </div>
                    </button>
                </div>

                <div id="wizard-message" class="wizard-alert"></div>

                <div class="wizard-footer">
                    <a href="https://zhaket.com" target="_blank">خرید لایسنس اورجینال</a> | <a href="<?php echo admin_url(); ?>">بازگشت به پیشخوان</a>
                </div>
            </div>
        </div>
        <?php
    }

    private function render_admin_header( $title, $description ) {
        ?>
        <div class="gardoonak-header-card">
            <div class="gardoonak-header-icon-box">
                <span class="dashicons dashicons-superhero"></span>
            </div>
            <div class="gardoonak-header-text">
                <h1><?php echo esc_html( $title ); ?></h1>
                <p><?php echo esc_html( $description ); ?></p>
            </div>
        </div>
        <?php
    }

    public function render_general_settings_page() {
        ?>
        <div class="wrap gardoonak-admin-wrapper">
            <?php $this->render_admin_header( 'تنظیمات عمومی گردونک', 'پیکربندی پیشرفته و مدیریت بخش‌های مختلف افزونه.' ); ?>

            <form id="gardoonak-settings-form">
                <div class="gardoonak-dashboard-container">
                    
                    <div class="gardoonak-sidebar">
                        <ul class="gardoonak-tabs-nav">
                            <?php
                            $tabs = [
                                'base'        => 'پیکربندی پایه',
                                'main'        => 'پیکربندی اصلی',
                                'fields'      => 'فیلدهای ورودی',
                                'style'       => 'استایل',
                                'security'    => 'محدودیت و امنیت',
                                'integration' => 'یکپارچه‌سازی',
                                'email'       => 'ایمیل',
                                'sms'         => 'پیامک',
                            ];

                            $first = true;
                            foreach ( $tabs as $slug => $label ) :
                                $active_class = $first ? 'active' : '';
                                $icon_url = GARDOONAK_URL . "assets/images/SVG/tab-{$slug}.svg";
                                ?>
                                <li class="<?php echo $active_class; ?>" data-tab="tab-<?php echo $slug; ?>">
                                    <img src="<?php echo $icon_url; ?>" class="gn-tab-icon" alt="<?php echo $label; ?>">
                                    <?php echo $label; ?>
                                </li>
                                <?php
                                $first = false;
                            endforeach;
                            ?>
                        </ul>

                        <div class="gardoonak-sidebar-actions">
                            <button type="submit" class="gn-btn gn-btn-block">
                                <span class="btn-text">ذخیره کلیه تنظیمات</span>
                                <div class="gn-btn-icon"><span class="dashicons dashicons-saved"></span></div>
                            </button>
                        </div>
                    </div>

                    <div class="gardoonak-content">
                        <div id="tab-base" class="gardoonak-tab-pane active">
                            <?php 
                            $this->render_tab_content_header( 
                                'پیکربندی پایه', 
                                'تنظیمات زیرساختی، محل نمایش در صفحات و مدیریت وضعیت کلی افزونه در سایت.',
                                'dashicons-admin-settings' 
                            ); 
                            ?>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-location-alt"></span> محل نمایش گردونه</label>
                                <p class="gn-desc">تعیین کنید گردونه در کدام صفحات به کاربر نشان داده شود.</p>
                                
                                <select name="display_location" class="gn-input" id="gn_display_location">
                                    <option value="all">در تمامی صفحات سایت</option>
                                    <option value="specific">فقط در صفحات خاص</option>
                                </select>

                                <div id="specific_pages_wrapper" style="display:none; margin-top:20px;">
                                    <div class="gn-page-selector-container">
                                        <label style="font-size: 13px; font-weight: 700; margin-bottom: 8px; display: block;">انتخاب صفحات از لیست:</label>
                                        <select id="gn_page_dropdown" class="gn-input">
                                            <option value="">یک صفحه را انتخاب کنید...</option>
                                            <?php
                                            $pages = get_pages();
                                            foreach ( $pages as $page ) {
                                                echo '<option value="' . esc_attr( $page->ID ) . '">' . esc_html( $page->post_title ) . '</option>';
                                            }
                                            ?>
                                        </select>
                                        
                                        <div id="gn_selected_pages_list" class="gn-selected-tags"></div>
                                        <input type="hidden" name="specific_pages_ids" id="gn_specific_pages_ids" value="">
                                    </div>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-external"></span> پاپ‌آپ اختصاصی گردونک</label>
                                <p class="gn-desc">تعیین کنید که آیا سیستم پاپ‌آپ هوشمند برای این کمپین فعال باشد یا خیر.</p>
                                
                                <div class="gn-choice-container">
                                    <?php 
                                    // FIX: Added false for is_image, true for checked
                                    $this->render_choice_item('radio', 'enable_popup', '1', 'فعال باشد', 'dashicons-yes-alt', false, true);
                                    $this->render_choice_item('radio', 'enable_popup', '0', 'غیرفعال', 'dashicons-dismiss', false);
                                    ?>
                                </div>

                                <div style="margin-top: 20px;">
                                    <?php 
                                    $shortcode = '<code>[gardoonak_wheel]</code>';
                                    $this->render_notice( 'warning', 'نکته مهندسی', "شما می‌توانید گردونه را با شورت‌کد $shortcode یا ویجت اختصاصی المنتور در صفحات قرار دهید." ); 
                                    ?>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-performance"></span> بهینه‌سازی زمان نمایش</label>
                                <p class="gn-desc">زمان لود شدن گردونه برای بهبود تجربه کاربری و سرعت سایت را انتخاب کنید.</p>
                                
                                <div class="gn-choice-container">
                                    <?php 
                                    // FIX: Added false for is_image, true for checked
                                    $this->render_choice_item('radio', 'display_delay', 'fast', 'سریع‌ترین زمان', 'dashicons-clock', false, true);
                                    $this->render_choice_item('radio', 'display_delay', 'optimized', 'نمایش بهینه', 'dashicons-dashboard', false);
                                    ?>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-groups"></span> هدف‌گیری مخاطبان</label>
                                <p class="gn-desc">تعیین کنید گردونه برای چه طیفی از کاربران نمایش داده شود.</p>
                                
                                <div class="gn-choice-container">
                                    <?php 
                                    // FIX: Added false for is_image, true for checked
                                    $this->render_choice_item('radio', 'target_audience', 'all', 'همه کاربران', 'dashicons-groups', false, true);
                                    $this->render_choice_item('radio', 'target_audience', 'guests', 'فقط مهمانان', 'dashicons-admin-users', false);
                                    $this->render_choice_item('radio', 'target_audience', 'logged_in', 'فقط اعضا', 'dashicons-admin-network', false);
                                    ?>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-smartphone"></span> نمایش در دستگاه‌ها</label>
                                <p class="gn-desc">محدودیت نمایش گردونه بر اساس نوع دستگاه کاربر را تعیین کنید.</p>
                                
                                <div class="gn-choice-container">
                                    <?php 
                                    // FIX: Added false for is_image, true for checked for all 3 items
                                    $this->render_choice_item('checkbox', 'device_desktop', '1', 'دسکتاپ', 'dashicons-desktop', false, true);
                                    $this->render_choice_item('checkbox', 'device_tablet', '1', 'تبلت', 'dashicons-tablet', false, true);
                                    $this->render_choice_item('checkbox', 'device_mobile', '1', 'موبایل', 'dashicons-smartphone', false, true);
                                    ?>
                                </div>
                            </div>
                        </div>

                        <div id="tab-main" class="gardoonak-tab-pane">
                            <?php 
                            $this->render_tab_content_header( 
                                'پیکربندی اصلی', 
                                'مدیریت هوشمند زمان‌بندی، صداها و مکانیسم‌های فنی چرخش گردونه.',
                                'dashicons-performance' 
                            ); 
                            ?>

                            <div class="gn-form-row" style="padding: 40px;">
                                <label class="gn-label" style="margin-bottom: 25px;"><span class="dashicons dashicons-external"></span> زمان و نحوه ظاهر شدن</label>
                                
                                <div style="display: flex; flex-direction: column; gap: 40px;">
                                    
                                    <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #f9f9f9; padding-bottom: 20px;">
                                        <div style="flex: 1;">
                                            <h4 style="margin: 0 0 5px 0; font-size: 15px;">نمایش هنگام قصد خروج (Exit Intent)</h4>
                                            <p class="gn-desc" style="margin: 0;">وقتی کاربر قصد بستن صفحه را دارد، گردونه نمایش داده شود؟</p>
                                        </div>
                                        <div class="gn-choice-container" style="gap: 20px;">
                                            <?php 
                                            // FIX: Added false for is_image, true for checked
                                            $this->render_choice_item('radio', 'trigger_exit', '1', 'بله', 'dashicons-yes-alt', false, true);
                                            $this->render_choice_item('radio', 'trigger_exit', '0', 'خیر', 'dashicons-dismiss');
                                            ?>
                                        </div>
                                    </div>

                                    <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #f9f9f9; padding-bottom: 20px;">
                                        <div style="flex: 1;">
                                            <h4 style="margin: 0 0 5px 0; font-size: 15px;">نمایش بعد از حضور کاربر</h4>
                                            <p class="gn-desc" style="margin: 0;">چند ثانیه بعد از ورود کاربر، گردونه شلیک شود؟</p>
                                        </div>
                                        <div style="display: flex; align-items: center; gap: 20px;">
                                            <div class="gn-conditional-input" style="width: 120px;">
                                                <input type="number" name="trigger_time_value" class="gn-input" placeholder="ثانیه">
                                            </div>
                                            <div class="gn-choice-container">
                                                <?php 
                                                // FIX: ensure correct false/true order
                                                $this->render_choice_item('radio', 'trigger_time', '1', 'فعال', 'dashicons-clock', false);
                                                $this->render_choice_item('radio', 'trigger_time', '0', 'غیرفعال', 'dashicons-dismiss', false, true);
                                                ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div style="display: flex; align-items: center; justify-content: space-between;">
                                        <div style="flex: 1;">
                                            <h4 style="margin: 0 0 5px 0; font-size: 15px;">نمایش بر اساس میزان اسکرول</h4>
                                            <p class="gn-desc" style="margin: 0;">پس از چند درصد پیمایش صفحه توسط کاربر، گردونه باز شود؟</p>
                                        </div>
                                        <div style="display: flex; align-items: center; gap: 20px;">
                                            <div class="gn-conditional-input" style="width: 120px;">
                                                <input type="number" name="trigger_scroll_value" class="gn-input" placeholder="درصد %">
                                            </div>
                                            <div class="gn-choice-container">
                                                <?php 
                                                // FIX: ensure correct false/true order
                                                $this->render_choice_item('radio', 'trigger_scroll', '1', 'فعال', 'dashicons-arrow-down-alt', false);
                                                $this->render_choice_item('radio', 'trigger_scroll', '0', 'غیرفعال', 'dashicons-dismiss', false, true);
                                                ?>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px;">
                                
                                <div class="gn-form-row">
                                    <label class="gn-label"><span class="dashicons dashicons-shield"></span> جلوگیری از اسپم</label>
                                    <p class="gn-desc">محدودیت نمایش مجدد (تعداد روز):</p>
                                    <input type="number" name="cookie_expiry" class="gn-input" value="7" style="width: 100px;">
                                    <div style="margin-top: 15px;">
                                        <?php $this->render_notice('warning', 'توجه', 'عدد ۰ یعنی نمایش در هر بار لود صفحه.'); ?>
                                    </div>
                                </div>

                                <div class="gn-form-row">
                                    <label class="gn-label"><span class="dashicons dashicons-awards"></span> افکت انفجار شادی</label>
                                    <p class="gn-desc">پخش انیمیشن Confetti در صورت برنده شدن؟</p>
                                    <div class="gn-choice-container">
                                        <?php 
                                        // FIX: Added false for is_image, true for checked
                                        $this->render_choice_item('radio', 'effect_confetti', '1', 'فعال', 'dashicons-star-filled', false, true);
                                        $this->render_choice_item('radio', 'effect_confetti', '0', 'غیرفعال', 'dashicons-dismiss');
                                        ?>
                                    </div>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label" style="margin-bottom: 20px;"><span class="dashicons dashicons-megaphone"></span> تنظیمات صوتی گردونه</label>
                                <div style="display: flex; gap: 60px;">
                                    <div>
                                        <p class="gn-desc">صدای تیک‌تیک چرخش:</p>
                                        <div class="gn-choice-container">
                                            <?php 
                                            // FIX: Added false for is_image, true for checked
                                            $this->render_choice_item('radio', 'sound_spin', '1', 'فعال', 'dashicons-volume-on', false, true); 
                                            $this->render_choice_item('radio', 'sound_spin', '0', 'غیرفعال', 'dashicons-volume-off'); 
                                            ?>
                                        </div>
                                    </div>
                                    <div>
                                        <p class="gn-desc">صدای اعلام نتیجه:</p>
                                        <div class="gn-choice-container">
                                            <?php 
                                            // FIX: Added false for is_image, true for checked
                                            $this->render_choice_item('radio', 'sound_result', '1', 'فعال', 'dashicons-format-audio', false, true); 
                                            $this->render_choice_item('radio', 'sound_result', '0', 'غیرفعال', 'dashicons-dismiss'); 
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label" style="margin-bottom: 20px;"><span class="dashicons dashicons-update"></span> زمان‌بندی موتور چرخش (ثانیه)</label>
                                <div style="display: flex; gap: 40px; align-items: center;">
                                    <div style="flex: 1;">
                                        <label style="font-size: 13px; display: block; margin-bottom: 8px;">زمان چرخش</label>
                                        <input type="number" name="spin_duration" class="gn-input" value="8">
                                    </div>
                                    <div style="flex: 1;">
                                        <label style="font-size: 13px; display: block; margin-bottom: 8px;">حداقل دور کامل</label>
                                        <input type="number" name="min_revolutions" class="gn-input" value="10">
                                    </div>
                                    <div style="flex: 1;">
                                        <label style="font-size: 13px; display: block; margin-bottom: 8px;">بستن خودکار پاپ‌آپ</label>
                                        <input type="number" name="auto_close_time" class="gn-input" value="5">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab-fields" class="gardoonak-tab-pane">
                            <?php 
                            $this->render_tab_content_header( 
                                'فیلدهای دریافت اطلاعات', 
                                'مدیریت زمان دریافت داده‌ها، فیلدهای مورد نیاز و تنظیمات دکمه‌های فراخوان.',
                                'dashicons-edit' 
                            ); 
                            ?>

                            <div class="gn-form-row" style="padding: 40px;">
                                <label class="gn-label" style="margin-bottom: 25px;"><span class="dashicons dashicons-clock"></span> زمان دریافت اطلاعات از کاربر</label>
                                <div style="display: flex; align-items: center; justify-content: space-between;">
                                    <div style="flex: 1;">
                                        <h4 style="margin: 0 0 5px 0; font-size: 15px;">اولویت دریافت داده‌ها</h4>
                                        <p class="gn-desc" style="margin: 0;">تعیین کنید کاربر چه زمانی باید فرم اطلاعات را تکمیل کند.</p>
                                    </div>
                                    <div class="gn-choice-container" style="gap: 20px;">
                                        <?php 
                                        // FIX: Added false for is_image, true for checked
                                        $this->render_choice_item('radio', 'data_collection_timing', 'before', 'قبل از بازی', 'dashicons-id', false, true);
                                        $this->render_choice_item('radio', 'data_collection_timing', 'after', 'بعد از بازی', 'dashicons-awards');
                                        ?>
                                    </div>
                                </div>
                            </div>

                            <div class="gn-form-row" style="padding: 40px;">
                                <label class="gn-label" style="margin-bottom: 25px;"><span class="dashicons dashicons-list-view"></span> فیلدهای مورد نیاز</label>
                                <p class="gn-desc">فیلدهایی که مایل هستید کاربر در فرم تکمیل کند را انتخاب کنید.</p>
                                <div class="gn-choice-container" style="gap: 30px; justify-content: flex-start;">
                                    <?php 
                                    // FIX: Added false for is_image, true for checked for all 3
                                    $this->render_choice_item('checkbox', 'field_name_enable', '1', 'نام و نشان', 'dashicons-admin-users', false, true);
                                    $this->render_choice_item('checkbox', 'field_email_enable', '1', 'ایمیل', 'dashicons-email-alt', false, true);
                                    $this->render_choice_item('checkbox', 'field_phone_enable', '1', 'شماره موبایل', 'dashicons-smartphone', false, true);
                                    ?>
                                </div>
                            </div>

                            <div class="gn-form-row" style="padding: 40px;">
                                <label class="gn-label" style="margin-bottom: 25px;"><span class="dashicons dashicons-testimonial"></span> پذیرش قوانین و مقررات</label>
                                <div style="display: flex; flex-direction: column; gap: 30px;">
                                    <div style="display: flex; align-items: center; justify-content: space-between;">
                                        <div style="flex: 1;">
                                            <h4 style="margin: 0 0 5px 0; font-size: 15px;">نمایش چک‌باکس قوانین</h4>
                                            <p class="gn-desc" style="margin: 0;">اجبار کاربر به تایید قوانین سایت قبل از انجام بازی.</p>
                                        </div>
                                        <div class="gn-choice-container">
                                            <?php 
                                            // FIX: ensure correct false/true order
                                            $this->render_choice_item('radio', 'enable_terms', '1', 'فعال', 'dashicons-yes-alt', false);
                                            $this->render_choice_item('radio', 'enable_terms', '0', 'غیرفعال', 'dashicons-dismiss', false, true);
                                            ?>
                                        </div>
                                    </div>

                                    <div id="terms_page_wrapper" style="display: none; align-items: center; justify-content: space-between; border-top: 1px solid #f9f9f9; padding-top: 25px;">
                                        <div style="flex: 1;">
                                            <h4 style="margin: 0 0 5px 0; font-size: 14px;">انتخاب برگه قوانین</h4>
                                        </div>
                                        <div style="width: 300px;">
                                            <select name="terms_page_id" class="gn-input">
                                                <option value="">برگه مورد نظر را انتخاب کنید...</option>
                                                <?php
                                                $pages = get_pages();
                                                foreach ( $pages as $page ) {
                                                    echo '<option value="' . esc_attr( $page->ID ) . '">' . esc_html( $page->post_title ) . '</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="gn-form-row" style="padding: 40px;">
                                <label class="gn-label" style="margin-bottom: 25px;"><span class="dashicons dashicons-admin-links"></span> متن سفارشی دکمه‌ها</label>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px;">
                                    <div>
                                        <label style="font-size: 13px; display: block; margin-bottom: 10px; font-weight: 700;">قبل از دریافت جایزه</label>
                                        <input type="text" name="btn_text_before" class="gn-input" value="شانست رو امتحان کن">
                                    </div>
                                    <div>
                                        <label style="font-size: 13px; display: block; margin-bottom: 10px; font-weight: 700;">بعد از دریافت جایزه</label>
                                        <input type="text" name="btn_text_after" class="gn-input" value="دریافت جایزه">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab-style" class="gardoonak-tab-pane">
                            <?php $this->render_tab_content_header( 'شخصی‌سازی بصری', 'تنظیمات گرافیکی و تم‌های آماده.', 'dashicons-art' ); ?>

                            <div class="gn-form-row" style="padding: 40px;">
                                <label class="gn-label">انتخاب پالت رنگی (تم‌های آماده)</label>
                                <div class="gn-choice-container">
                                    <?php 
                                    $this->render_choice_item('radio', 'wheel_theme', '1', 'گردونک', 'themes/theme-1.png', true, true);
                                    $this->render_choice_item('radio', 'wheel_theme', '2', 'لاکچری', 'themes/theme-2.png', true);
                                    $this->render_choice_item('radio', 'wheel_theme', '3', 'نئونی', 'themes/theme-3.png', true);
                                    ?>
                                </div>
                            </div>

                            <div class="gn-form-row" style="padding: 40px;">
                                <label class="gn-label">طرح نشانگر (Pointer)</label>
                                <div class="gn-choice-container">
                                    <?php 
                                    $this->render_choice_item('radio', 'pointer_style', 'p1', 'کلاسیک', 'SVG/pointers/pointer-1.svg', true, true);
                                    $this->render_choice_item('radio', 'pointer_style', 'p2', 'مدرن', 'SVG/pointers/pointer-2.svg', true);
                                    ?>
                                </div>
                            </div>

                            <div class="gn-form-row" style="padding: 40px;">
                                <label class="gn-label">دکمه شناور فراخوان</label>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 50px;">
                                    <div>
                                        <label style="font-size: 13px; font-weight: 700; margin-bottom: 15px; display: block;">رنگ دکمه</label>
                                        <div class="gn-modern-color-picker">
                                            <div class="gn-color-preview" id="float_color_preview" style="background: #7079f0;"></div>
                                            <input type="color" name="float_btn_color" id="float_btn_color" value="#7079f0">
                                            <span class="gn-color-hex">#7079f0</span>
                                        </div>
                                    </div>
                                    <div>
                                        <label style="font-size: 13px; font-weight: 700; margin-bottom: 15px; display: block;">آیکون دکمه شناور</label>
                                        <div style="display: flex; gap: 20px; align-items: flex-end;">
                                            <div class="gn-choice-container">
                                                <?php $this->render_choice_item('radio', 'float_icon_type', 'default', 'پیش‌فرض', 'SVG/float-default.svg', true, true); ?>
                                            </div>
                                            <div class="gn-upload-box-mini">
                                                <input type="hidden" name="custom_float_icon" id="gn_custom_float_icon">
                                                <div class="gn-icon-preview-box" id="gn_float_icon_preview">
                                                    <span class="dashicons dashicons-upload"></span>
                                                </div>
                                                <button type="button" class="gn-btn gn-btn-sm" id="gn_upload_float_icon">آپلود آیکون</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </form>
        </div>
        <?php
    }

    public function render_wheels_management_page() {
        echo '<div class="wrap gardoonak-admin-wrapper">';
        $this->render_admin_header( 'مدیریت گردونه‌ها', 'کمپین‌های خود را بسازید.' );
        echo '</div>';
    }

    public function render_statistics_page() {
        echo '<div class="wrap gardoonak-admin-wrapper">';
        $this->render_admin_header( 'آمار و گزارشات', 'تحلیل دقیق رفتار کاربران.' );
        echo '</div>';
    }

    /**
     * رندر کردن هدر محتوای هر تب به صورت سراسری
     */
    private function render_tab_content_header( $title, $description, $icon = 'dashicons-admin-generic' ) {
        ?>
        <div class="gn-content-header">
            <div class="gn-content-header-icon">
                <span class="dashicons <?php echo esc_attr( $icon ); ?>"></span>
            </div>
            <div class="gn-content-header-info">
                <h2><?php echo esc_html( $title ); ?></h2>
                <p><?php echo esc_html( $description ); ?></p>
            </div>
        </div>
        <?php
    }

    /**
     * تابع کمکی برای رندر کردن باکس‌های راهنما
     */
    private function render_notice( $type = 'warning', $title = '', $message = '' ) {
        $icon = ( $type === 'critical' ) ? 'dashicons-info' : 'dashicons-warning';
        $class = ( $type === 'critical' ) ? 'gn-notice-critical' : 'gn-notice-warning';
        ?>
        <div class="gn-notice-box <?php echo esc_attr( $class ); ?>">
            <div class="gn-notice-icon">
                <span class="dashicons <?php echo esc_attr( $icon ); ?>"></span>
            </div>
            <div class="gn-notice-content">
                <strong class="gn-notice-title"><?php echo esc_html( $title ); ?></strong>
                <p class="gn-notice-desc">
                    <?php 
                    // اجازه دادن به تگ code برای نمایش شکیل شورت‌کدها
                    echo wp_kses( $message, [
                        'code' => [],
                        'strong' => [],
                        'b' => []
                    ] ); 
                    ?>
                </p>
            </div>
        </div>
        <?php
    }

    /**
     * رندر کردن آیتم‌های انتخابی (Tile Choice)
     */
    private function render_choice_item( $type, $name, $value, $label, $source, $is_image = false, $checked = false ) {
        $is_checked = $checked ? 'checked' : '';
        $content = $is_image 
            ? '<img src="' . GARDOONAK_URL . 'assets/images/' . $source . '" alt="' . $label . '" class="gn-choice-img">'
            : '<span class="dashicons ' . esc_attr( $source ) . '"></span>';
        ?>
        <label class="gn-choice-item">
            <input type="<?php echo esc_attr( $type ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" class="gn-choice-input" <?php echo $is_checked; ?>>
            <div class="gn-choice-tile <?php echo $is_image ? 'gn-has-image' : ''; ?>">
                <div class="gn-choice-icon">
                    <?php echo $content; ?>
                </div>
                <span class="gn-choice-label"><?php echo esc_html( $label ); ?></span>
            </div>
        </label>
        <?php
    }
}