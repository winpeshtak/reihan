<?php
namespace Gardoonak\Game;

defined( 'ABSPATH' ) || exit;

class Engine {

    /**
     * اجرای اصلی چرخش
     * این تابع توسط API صدا زده می‌شود.
     */
    public function spin( $user_data ) {
        // ۱. دریافت تنها گردونه موجود در سیستم
        $campaign = $this->get_single_wheel_config();
        
        if ( ! $campaign || empty($campaign['slices']) ) {
            return [ 'success' => false, 'message' => 'مهندس جان، ابتدا گردونه را تنظیم و ذخیره کنید.' ];
        }

        // ۲. انتخاب برنده
        $winning_slice = $this->calculate_winner( $campaign['slices'] );

        // ۳. ثبت لاگ با آیدی ثابت ۱
        $this->log_result( 1, $user_data, $winning_slice );

        return [
            'success'       => true,
            'slice_index'   => $winning_slice['index'],
            'prize_title'   => $winning_slice['label'],
            'prize_type'    => $winning_slice['prize_type'],
            'prize_value'   => $winning_slice['prize_value'],
            'message'       => 'تبریک! شما برنده شدید.'
        ];
    }

    /**
     * الگوریتم انتخاب برنده بر اساس شانس (وزن)
     */
    private function calculate_winner( $slices ) {
        $total_weight = 0;
        
        // محاسبه مجموع کل شانس‌ها (مثلاً جمع کل می‌شود ۱۰۰ یا ۱۰۰۰)
        foreach ( $slices as $slice ) {
            // اگر شانس تعریف نشده بود، پیش‌فرض ۱ در نظر می‌گیریم
            $weight = isset($slice['probability']) ? intval($slice['probability']) : 1;
            $total_weight += $weight;
        }

        // انتخاب یک عدد تصادفی بین ۱ تا مجموع وزن‌ها
        // استفاده از mt_rand برای تولید عدد تصادفی بهتر نسبت به rand معمولی
        $random_point = mt_rand( 1, $total_weight );
        
        $current_point = 0;

        foreach ( $slices as $index => $slice ) {
            $weight = isset($slice['probability']) ? intval($slice['probability']) : 1;
            $current_point += $weight;

            // اگر عدد تصادفی در بازه این اسلایس بود، این برنده است
            if ( $random_point <= $current_point ) {
                $slice['index'] = $index; // ذخیره شماره اسلایس برای فرانت
                return $slice;
            }
        }
        
        // جهت اطمینان، اگر باگی رخ داد، آخرین گزینه را برمی‌گرداند (Fallback)
        $last_slice = end($slices);
        $last_slice['index'] = count($slices) - 1;
        return $last_slice; 
    }

    /**
     * خواندن تنظیمات از دیتابیس (شبیه‌سازی فعلی)
     */
    private function get_single_wheel_config() {
        global $wpdb;
        // همیشه اولین رکورد را می‌گیریم
        $wheel = $wpdb->get_row( "SELECT id, settings FROM {$wpdb->prefix}gardoonak_wheels LIMIT 1" );
        if ( ! $wheel ) return false;

        $slices = $wpdb->get_results( $wpdb->prepare( 
            "SELECT * FROM {$wpdb->prefix}gardoonak_slices WHERE wheel_id = %d", 
            $wheel->id 
        ), ARRAY_A );
        
        return [
            'settings' => json_decode( $wheel->settings, true ),
            'slices'   => $slices
        ];
    }

    /**
     * ثبت لاگ در دیتابیس
     */
    private function log_result( $campaign_id, $user_data, $slice ) {
        global $wpdb;
        $table = $wpdb->prefix . 'gardoonak_logs';

        $wpdb->insert(
            $table,
            [
                'campaign_id'     => $campaign_id,
                'user_identifier' => $user_data['mobile'] ?? 'unknown', // شماره موبایل یا IP
                'prize_index'     => $slice['index'],
                'prize_code'      => $slice['value'], // کد تخفیف برنده شده
                'ip_address'      => $_SERVER['REMOTE_ADDR'],
                'user_agent'      => $_SERVER['HTTP_USER_AGENT'],
                'created_at'      => current_time( 'mysql' )
            ]
        );
    }
}