jQuery(document).ready(function ($) {
    // مقداردهی اولیه گردونه (داده‌ها از ادمین پاس داده می‌شوند)
    // فرض می‌کنیم داده‌های اسلایس‌ها در یک متغیر سراسری به نام gardoonak_settings موجود است
    const wheel = new GardoonakWheel('gardoonak-canvas', gardoonak_settings.slices);

    $('#gardoonak-spin-btn').on('click', function (e) {
        e.preventDefault();

        const $btn = $(this);
        const mobile = $('#gardoonak-mobile').val();

        // ۱. اعتبارسنجی اولیه موبایل
        if (!mobile || mobile.length < 11) {
            alert('مهندس جان، لطفاً شماره موبایل معتبر وارد کنید!');
            return;
        }

        // جلوگیری از کلیک مجدد هنگام پردازش
        $btn.prop('disabled', true).text('در حال بررسی...');

        // ۲. ارسال درخواست به سرور
        $.ajax({
            url: gardoonak_data.api_url,
            method: 'POST',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', gardoonak_data.nonce);
            },
            data: {
                campaign_id: gardoonak_settings.campaign_id,
                mobile: mobile
            },
            success: function (response) {
                if (response.success) {
                    // ۳. دریافت ایندکس برنده و شروع انیمیشن چرخش
                    const winnerIndex = response.slice_index;

                    wheel.spinTo(winnerIndex, function () {
                        // این بخش پس از پایان انیمیشن اجرا می‌شود
                        alert('تبریک! شما برنده شدید: ' + response.prize_title);
                        console.log('کد تخفیف شما: ' + response.prize_value);
                        $btn.prop('disabled', false).text('دوباره بچرخون!');
                    });
                }
            },
            error: function (error) {
                const msg = error.responseJSON ? error.responseJSON.message : 'خطایی رخ داد!';
                alert('خطا: ' + msg);
                $btn.prop('disabled', false).text('بچرخون!');
            }
        });
    });
});