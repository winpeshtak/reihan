<?php
// جلوگیری از لود تکراری
if ( defined( 'RP_POPUP_COMPLETION_LOADED' ) ) { return; }
define( 'RP_POPUP_COMPLETION_LOADED', true );

if ( ! defined( 'ABSPATH' ) ) { exit; }

$uid = get_current_user_id();
if ( ! $uid ) { return; }

$u = get_userdata($uid);
if ( ! $u ) { return; }

// نانس امنیتی
$secure_nonce = wp_create_nonce( 'reyhan_auth_nonce' );

// بررسی وضعیت
$has_real_email = ( strpos($u->user_email, '@user.reyhan') === false ); 
$mobile         = get_user_meta($uid, 'mobile', true);
$has_mobile     = !empty($mobile);

// شروط نمایش
$ask_mobile = false; $ask_email  = false; $ask_names  = false;
$title = ''; $desc = '';

// منطق تصمیم‌گیری PHP (سمت سرور)
if ( $has_real_email && ! $has_mobile ) {
    $ask_mobile = true;
    $title = 'تایید شماره موبایل';
    $desc  = 'برای امنیت بیشتر حساب کاربری، لطفاً شماره موبایل خود را ثبت کنید.';
}
elseif ( ! $has_real_email ) {
    $ask_email = true; $ask_names = true;
    $title = 'تکمیل اطلاعات کاربری';
    $desc  = 'لطفاً نام و ایمیل خود را جهت تکمیل پروفایل وارد نمایید.';
}
elseif ( empty($u->first_name) || empty($u->last_name) ) {
    $ask_names = true;
    $title = 'تکمیل نام و نام خانوادگی';
    $desc  = 'لطفاً نام خود را وارد کنید.';
}
else {
    return; // اگر اطلاعات کامل است، هیچ چیزی چاپ نکن
}
?>

<div id="rp-completion-overlay">
    <div class="rp-completion-box">
        <div class="rp-comp-icon">
            <span class="dashicons dashicons-admin-users"></span>
        </div>

        <h3 class="rp-font-target"><?php echo esc_html($title); ?></h3>
        <p class="rp-font-target"><?php echo esc_html($desc); ?></p>

        <form id="rp-forced-completion-form" onsubmit="return false;">
            <?php if ( $ask_names ): ?>
                <div class="rp-form-row-2">
                    <input type="text" name="first_name" class="rp-inp-modern rp-font-target" placeholder="نام" required>
                    <input type="text" name="last_name" class="rp-inp-modern rp-font-target" placeholder="نام خانوادگی" required>
                </div>
            <?php endif; ?>

            <?php if ( $ask_email ): ?>
                <div class="rp-inp-group">
                    <input type="email" name="email" class="rp-inp-modern ltr-inp rp-font-target" placeholder="ایمیل (مثال: name@gmail.com)" required>
                </div>
            <?php endif; ?>

            <?php if ( $ask_mobile ): ?>
                <div class="rp-inp-group">
                    <input type="tel" id="rp_mobile_final_input" name="mobile" class="rp-inp-modern ltr-inp rp-font-target"
                           placeholder="شماره موبایل (مثال: 0912xxxxxxx)" maxlength="11" required inputmode="numeric" dir="ltr" autocomplete="off">
                </div>
            <?php endif; ?>

            <button type="button" onclick="window.rp_submit_profile_data(this)" class="rp-btn-submit-comp rp-font-target">
                <span class="dashicons dashicons-saved"></span> ذخیره اطلاعات
            </button>
        </form>
    </div>
</div>

<style>
    /* استایل‌های اصلی */
    #rp-completion-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.9);
        z-index: 9999990;
        display: flex; align-items: center; justify-content: center;
        backdrop-filter: blur(8px);
        transition: opacity 0.4s ease;
    }
    .rp-completion-box {
        background: #fff; width: 90%; max-width: 400px;
        padding: 30px; border-radius: 20px; text-align: center;
        box-shadow: 0 25px 60px rgba(0,0,0,0.5);
        position: relative;
        z-index: 9999991;
    }
    .rp-comp-icon {
        width: 70px; height: 70px; background: #e3f2fd; color: #1565c0;
        border-radius: 50%; margin: 0 auto 20px; display: flex;
        align-items: center; justify-content: center;
    }
    .rp-comp-icon .dashicons { font-size: 32px; width: 32px; height: 32px; font-family: dashicons !important; }
    .rp-inp-modern { margin-bottom: 12px; width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; font-family: sans-serif !important; font-size: 16px; }
    .ltr-inp { direction: ltr; text-align: left; }
    
    .rp-btn-submit-comp {
        width: 100%; background: #2196F3; color: #fff; border: none; padding: 12px; border-radius: 10px; cursor: pointer; margin-top: 10px;
        display: flex; align-items: center; justify-content: center; gap: 8px;
        transition: 0.3s;
    }
    .rp-btn-submit-comp:hover { background: #1976D2; }
    .rp-form-row-2 { display: flex; gap: 10px; }

    /* استایل نوتیفیکیشن */
    .rp-js-toast {
        position: fixed; bottom: 30px; left: 30px; min-width: 300px; padding: 15px 20px; border-radius: 8px;
        font-size: 13px; font-weight: bold; z-index: 2147483647 !important;
        box-shadow: 0 10px 30px rgba(0,0,0,0.5); color: #fff; font-family: tahoma, sans-serif; text-align: right; direction: rtl;
        line-height: 1.6; animation: rpSlideUp 0.3s ease-out; display: none;
    }
    @keyframes rpSlideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .rp-js-toast.rp-error { background: #d32f2f; border-right: 6px solid #b71c1c; }
    .rp-js-toast.rp-success { background: #388e3c; border-right: 6px solid #1b5e20; }
</style>

<script>
(function() {
    "use strict";

    var RP_UID = "<?php echo $uid; ?>"; // شناسه کاربر برای ذخیره وضعیت
    var RP_NONCE = "<?php echo esc_js($secure_nonce); ?>";
    var RP_AJAX_URL = "<?php echo esc_js(admin_url('admin-ajax.php')); ?>";

    // --- ۱. بررسی فوری: آیا کاربر قبلاً این کار را انجام داده؟ ---
    // این بخش جلوی نمایش پاپ آپ کش شده را می‌گیرد
    var storageKey = 'rp_completed_' + RP_UID;
    if (localStorage.getItem(storageKey) === '1') {
        var overlay = document.getElementById('rp-completion-overlay');
        if (overlay) {
            overlay.style.display = 'none'; // مخفی کردن فوری
        }
    }

    // --- ۲. تابع نمایش نوتیفیکیشن ---
    window.rp_create_and_show_toast = function(type, msg) {
        var el = document.getElementById('rp-js-injected-toast');
        if (!el) {
            el = document.createElement('div');
            el.id = 'rp-js-injected-toast';
            el.className = 'rp-js-toast';
            document.body.appendChild(el);
        }
        el.style.display = 'block';
        el.className = 'rp-js-toast rp-' + type;
        el.innerHTML = '<span class="dashicons ' + (type==='success'?'dashicons-yes':(type==='error'?'dashicons-warning':'dashicons-info')) + '" style="vertical-align:middle; margin-left:10px; font-size:20px;"></span>' + msg;
        if(window.rpTmr) clearTimeout(window.rpTmr);
        window.rpTmr = setTimeout(function(){ el.style.display = 'none'; }, 4000);
    };

    function rp_to_en(s) {
        if(!s) return "";
        return String(s).replace(/[۰-۹]/g, d => "0123456789"["۰۱۲۳۴۵۶۷۸۹".indexOf(d)]).replace(/[٠-٩]/g, d => "0123456789"["٠١٢٣٤٥٦٧٨٩".indexOf(d)]);
    }

    // --- ۳. تابع ارسال اطلاعات ---
    window.rp_submit_profile_data = function(btn) {
        var form = document.getElementById("rp-forced-completion-form");
        var errorText = "";
        
        // اصلاح موبایل
        var mobileInputEl = document.getElementById("rp_mobile_final_input");
        var mobileVal = "";
        
        if (mobileInputEl) {
            mobileVal = rp_to_en(mobileInputEl.value).trim();
            mobileVal = mobileVal.replace(/[^0-9]/g, ''); 
            
            if (mobileVal.length === 10 && mobileVal.startsWith('9')) mobileVal = '0' + mobileVal;
            if (mobileVal.length === 12 && mobileVal.startsWith('98')) mobileVal = '0' + mobileVal.substring(2);

            mobileInputEl.value = mobileVal; 

            if (mobileVal.length !== 11 || !mobileVal.startsWith('09')) {
                errorText = "شماره موبایل نامعتبر است.";
            }
        }
        
        // سایر فیلدها
        if (!errorText) {
             var emailInp = form.querySelector('input[name="email"]');
             if(emailInp) {
                 var em = emailInp.value.trim();
                 if(em.indexOf('@') === -1 || em.length < 5) errorText = "ایمیل نامعتبر است.";
             }
             var fName = form.querySelector('input[name="first_name"]');
             var lName = form.querySelector('input[name="last_name"]');
             if(fName && lName) {
                 if(fName.value.trim().length < 2 || lName.value.trim().length < 2) errorText = "نام و نام خانوادگی را کامل کنید.";
             }
        }

        if(errorText) {
            window.rp_create_and_show_toast('error', errorText);
            return;
        }

        // ارسال
        if(btn) { 
            btn.dataset.originalText = btn.innerHTML;
            btn.disabled = true; 
            btn.innerHTML = '<span class="dashicons dashicons-update spin"></span> ذخیره...'; 
        }
        
        var fd = new FormData(form);
        if(mobileInputEl) fd.set('mobile', mobileInputEl.value);
        
        fd.append("action", "reyhan_save_forced_completion");
        fd.append("security", RP_NONCE); 

        fetch(RP_AJAX_URL, {method:'POST', body:fd})
        .then(function(r){ return r.text(); })
        .then(function(txt){
            var res;
            try {
                var jsonStart = txt.indexOf('{');
                var jsonEnd = txt.lastIndexOf('}');
                if (jsonStart !== -1 && jsonEnd !== -1) {
                    var cleanJson = txt.substring(jsonStart, jsonEnd + 1);
                    res = JSON.parse(cleanJson);
                } else {
                    throw new Error("Invalid JSON");
                }
            } catch(e) {
                res = {success:false, data:"خطای سرور."};
            }
            
            if(res.success) {
                // الف) ثبت نشان موفقیت در مرورگر (برای مقابله با کش)
                localStorage.setItem(storageKey, '1');

                // ب) نمایش پیام
                window.rp_create_and_show_toast('success', res.data || 'ذخیره شد.');
                
                // ج) حذف پاپ آپ
                var overlay = document.getElementById('rp-completion-overlay');
                if(overlay) {
                    overlay.style.opacity = '0';
                    setTimeout(function(){ overlay.style.display = 'none'; }, 500);
                }

                // د) رفرش صفحه
                setTimeout(function(){ location.reload(); }, 1500);
            } else {
                window.rp_create_and_show_toast('error', res.data || 'خطایی رخ داد.');
                if(btn) { btn.disabled = false; btn.innerHTML = btn.dataset.originalText; }
            }
        })
        .catch(function(err){
            window.rp_create_and_show_toast('error', 'خطای اینترنت.');
            if(btn) { btn.disabled = false; btn.innerHTML = btn.dataset.originalText; }
        });
    };

})();
</script>