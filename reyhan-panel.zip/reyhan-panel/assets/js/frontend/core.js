(function ($) {
    "use strict";

    if (typeof reyhan_front_obj === 'undefined') {
        console.error('Reyhan Panel: reyhan_front_obj is missing.');
        return;
    }

    // تعریف آبجکت اصلی برنامه در سطح ویندو
    window.ReyhanApp = {
        currentEmail: '',
        notifTimer: null,
        labels: {
            wait: '<span class="dashicons dashicons-update spin" style="font-size:16px; width:auto; height:auto; vertical-align:middle;"></span> منتظر بمانید...',
            save: 'ذخیره تغییرات'
        },

        init: function () {
            this.bindEvents();
            this.initDashboardInteractions();
            
            // ماژول‌های دیگر اگر لود شده باشند، متدهایشان را صدا می‌زنیم
            if(typeof this.initProfileFeatures === 'function') this.initProfileFeatures();
            if(typeof this.initIranCitiesAndPostal === 'function') this.initIranCitiesAndPostal();
            if(typeof this.checkMandatoryFields === 'function') this.checkMandatoryFields();

            // اکسپوز کردن توابع برای استفاده در HTML (مثل دکمه‌های onclick)
            window.loadUserTickets  = this.loadTickets ? this.loadTickets.bind(this) : function(){};
            window.loadSingleTicket = this.loadSingleTicket ? this.loadSingleTicket.bind(this) : function(){};
            window.loadOrders       = this.loadOrders ? this.loadOrders.bind(this) : function(){};
            window.loadSingleOrder  = this.loadSingleOrder ? this.loadSingleOrder.bind(this) : function(){};
            window.backToOrderList  = this.backToOrderList ? this.backToOrderList.bind(this) : function(){};
        },

        bindEvents: function () {
            $(document).on('click', '.rp-menu li', this.handleTabSwitch.bind(this));
            $('#rp-mobile-menu-trigger').on('click', function () { $('#rp-main-sidebar').addClass('rp-open'); $('#rp-mobile-overlay').addClass('active'); });
            $('#rp-mobile-overlay').on('click', function () { $('#rp-main-sidebar').removeClass('rp-open'); $(this).removeClass('active'); });
        },

        handleTabSwitch: function (e) {
            var item = $(e.currentTarget);
            var target = item.data('tab');
            if (item.hasClass('rp-menu-logout')) { window.location.href = item.data('url'); return; }
            if (item.hasClass('rp-menu-link')) { window.open(item.data('url'), '_blank'); return; }
            e.preventDefault();
            $('.rp-menu li').removeClass('active'); item.addClass('active');
            $('.rp-tab-content').hide().removeClass('active');
            var targetSection = $('#rp-section-' + target);
            if (targetSection.length) targetSection.fadeIn(200).addClass('active');
            if (target === 'tickets' && this.loadTickets) this.loadTickets();
            if (target === 'orders' && this.loadOrders) this.loadOrders();
            $('#rp-main-sidebar').removeClass('rp-open'); $('#rp-mobile-overlay').removeClass('active');
        },

        initDashboardInteractions: function () {
            $(document).on('click', '.rp-copy-discount-btn', function () {
                var code = $(this).data('code'); var $btn = $(this);
                navigator.clipboard.writeText(code).then(function () {
                    var originalText = $btn.find('.rp-copy-btn').html();
                    $btn.find('.rp-copy-btn').html('<span class="dashicons dashicons-yes"></span> کپی شد');
                    setTimeout(function () { $btn.find('.rp-copy-btn').html(originalText); }, 2000);
                });
            });
            $(document).on('click', '.rp-toggle-ticket-box', function (e) { e.preventDefault(); $('#rp-ticket-creation-area').slideToggle(); });
            $(document).on('click', '.rp-faq-q', function () { $(this).next('.rp-faq-a').slideToggle(); });
        },

        showNotification: function (msg, type = 'error') {
            if ($('.rp-notification').length === 0) $('body').append('<div class="rp-notification"></div>');
            var notif = $('.rp-notification');
            notif.html(msg).removeClass('error success').addClass(type).fadeIn();
            setTimeout(function () { notif.fadeOut(); }, 4000);
        },

        resetButton: function (btn, text) { btn.prop('disabled', false).html(text); }
    };

    // اجرای برنامه پس از لود شدن کامل دام
    $(document).ready(function () { ReyhanApp.init(); });

})(jQuery);