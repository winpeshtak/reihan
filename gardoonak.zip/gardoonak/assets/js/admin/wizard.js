/* assets/js/admin/wizard.js */
jQuery(document).ready(function ($) {

    const $btn = $('#btn-activate-wizard');
    const $input = $('#license_key_input');
    const $msg = $('#wizard-message');
    const $iconBox = $('#wizard-icon-box');
    const $img = $iconBox.find('img');

    $btn.on('click', function (e) {
        e.preventDefault();

        const licenseKey = $input.val().trim();

        // ریست کردن حالت‌ها
        $msg.removeClass('error success').text('');
        $input.removeClass('shake-animation');
        $img.attr('src', gardoonak_assets.img_key); // بازگشت به آیکون پیش‌فرض

        if (!licenseKey) {
            // نمایش نوتیفیکیشن هشدار در صورت خالی بودن فیلد
            gn_notify('لطفا لایسنس را وارد کنید.', 'warning');

            $input.addClass('shake-animation');
            setTimeout(() => $input.removeClass('shake-animation'), 600);
            return;
        }

        // حالت لودینگ
        const originalText = $btn.find('.btn-text').text();
        $btn.prop('disabled', true).find('.btn-text').text('در حال بررسی...');

        // شبیه‌سازی درخواست AJAX (بعدا به API واقعی وصل می‌شود)
        setTimeout(function () {

            $.ajax({
                url: gardoonak_assets.ajax_url,
                type: 'POST',
                data: {
                    action: 'gardoonak_activate_license',
                    license_key: licenseKey,
                    security: gardoonak_assets.nonce
                },
                success: function (response) {
                    if (response.success) {
                        gn_notify(response.data.message, 'success');

                        $img.fadeOut(200, function () {
                            $(this).attr('src', gardoonak_assets.img_success).fadeIn(200).addClass('pop-animation');
                        });

                        setTimeout(function () {
                            window.location.href = 'admin.php?page=gardoonak';
                        }, 2000);
                    } else {
                        gn_notify(response.data.message, 'error');
                        $img.attr('src', gardoonak_assets.img_error);
                        $btn.prop('disabled', false).find('.btn-text').text(originalText);
                        $input.addClass('shake-animation');
                        setTimeout(() => $input.removeClass('shake-animation'), 600);
                    }
                },
                error: function () {
                    gn_notify('خطایی در ارتباط با سرور رخ داد.', 'error');
                    $btn.prop('disabled', false).find('.btn-text').text(originalText);
                }
            });

        }, 1500);
    });

    function showError(text) {
        $msg.addClass('error').text(text);
        $input.addClass('shake-animation'); // لرزش فیلد

        // حذف کلاس انیمیشن بعد از اجرا تا دوباره قابل اجرا باشد
        setTimeout(() => $input.removeClass('shake-animation'), 600);
    }

    function showSuccess(text) {
        $msg.addClass('success').text(text);
        $input.prop('disabled', true);
        $btn.text('ورود به سیستم...');
    }
});