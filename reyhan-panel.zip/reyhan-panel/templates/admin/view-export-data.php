<?php defined('ABSPATH') || exit; ?>

<div class="wrap rp-wrap">
    <?php 
    // فراخوانی هدر استاندارد
    if ( file_exists( \REYHAN_DIR . 'templates/admin/partials/admin-header.php' ) ) {
        include \REYHAN_DIR . 'templates/admin/partials/admin-header.php';
    } else {
        echo '<h1>' . esc_html__('مرکز داده و گزارشات', 'reyhan-panel') . '</h1>';
    }
    ?>
    <hr class="wp-header-end">

    <div class="rp-modern-dashboard" style="border:none; box-shadow:none; background:transparent; padding:0; max-width: 100%; margin: 20px 0;">
        
        <div class="rp-row-flex" style="grid-template-columns: repeat(3, 1fr); gap: 20px;">
            
            <div class="rp-card-modern rp-export-card" data-type="users" style="height: 100%; display: flex; flex-direction: column; justify-content: space-between;">
                <div class="rp-card-header" style="background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); border-bottom:none;">
                    <div class="rp-header-icon" style="background: #fff; color: #1976D2;">
                        <span class="dashicons dashicons-admin-users"></span>
                    </div>
                    <div>
                        <h3 style="color:#0d47a1"><?php esc_html_e('گزارش کاربران', 'reyhan-panel'); ?></h3>
                        <span style="font-size:12px; color:#546e7a;margin: 10px;"><?php esc_html_e('خروجی لیست کاربران با جزئیات کامل', 'reyhan-panel'); ?></span>
                    </div>
                </div>
                <div class="rp-card-body" style="padding: 25px;text-align: center;">
                    <p style="color:#666; font-size:13px; margin-bottom:20px; line-height:1.8;">
                        <?php esc_html_e('دریافت لیست کاربران سایت شامل نام، ایمیل، موبایل و آدرس‌ها با قابلیت فیلتر بر اساس زمان ثبت‌نام.', 'reyhan-panel'); ?>
                    </p>
                    <button type="button" class="rp-btn-primary-hero rp-trigger-export" data-target="users" style="width:100%; justify-content:center; color:#fff; background:#0d47a1; box-shadow:none;">
                        <span class="dashicons dashicons-download"></span>
                        <?php esc_html_e('استخراج اطلاعات کاربران', 'reyhan-panel'); ?>
                    </button>
                </div>
            </div>

            <div class="rp-card-modern rp-export-card" data-type="tickets" style="height: 100%; display: flex; flex-direction: column; justify-content: space-between;">
                <div class="rp-card-header" style="background: linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%); border-bottom:none;">
                    <div class="rp-header-icon" style="background: #fff; color: #F57C00;">
                        <span class="dashicons dashicons-tickets-alt"></span>
                    </div>
                    <div>
                        <h3 style="color:#e65100"><?php esc_html_e('تحلیل و گزارش تیکت‌ها', 'reyhan-panel'); ?></h3>
                        <span style="font-size:12px; color:#795548;margin: 10px;"><?php esc_html_e('آمار عملکرد پشتیبانی و لیست تیکت‌ها', 'reyhan-panel'); ?></span>
                    </div>
                </div>
                <div class="rp-card-body" style="padding: 25px;text-align: center;">
                    <p style="color:#666; font-size:13px; margin-bottom:20px; line-height:1.8;">
                        <?php esc_html_e('دریافت گزارش عملکرد ایجنت‌ها، وضعیت پاسخگویی، تیکت‌های باز و بسته و آمارهای تحلیلی.', 'reyhan-panel'); ?>
                    </p>
                    <button type="button" class="rp-btn-primary-hero rp-trigger-export" data-target="tickets" style="width:100%; justify-content:center; color:#fff; background:#e65100; box-shadow:none;">
                        <span class="dashicons dashicons-chart-pie"></span>
                        <?php esc_html_e('استخراج گزارش تیکت‌ها', 'reyhan-panel'); ?>
                    </button>
                </div>
            </div>

            <div class="rp-card-modern rp-export-card" data-type="orders" style="height: 100%; display: flex; flex-direction: column; justify-content: space-between;">
                <div class="rp-card-header" style="background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%); border-bottom:none;">
                    <div class="rp-header-icon" style="background: #fff; color: #388E3C;">
                        <span class="dashicons dashicons-cart"></span>
                    </div>
                    <div>
                        <h3 style="color:#1b5e20"><?php esc_html_e('مدیریت گزارشات فروش', 'reyhan-panel'); ?></h3>
                        <span style="font-size:12px; color:#33691e;margin: 10px;"><?php esc_html_e('خروجی لیست سفارشات فروشگاه شما', 'reyhan-panel'); ?></span>
                    </div>
                </div>
                <div class="rp-card-body" style="padding: 25px;text-align: center;">
                    <?php if ( class_exists('WooCommerce') ) : ?>
                        <p style="color:#666; font-size:13px; margin-bottom:20px; line-height:1.8;">
                            <?php esc_html_e('استخراج سفارشات موفق، ناموفق و مرجوعی با قابلیت انتخاب جزئیات و بازه زمانی.', 'reyhan-panel'); ?>
                        </p>
                        <button type="button" class="rp-btn-primary-hero rp-trigger-export" data-target="orders" style="width:100%; justify-content:center; color:#fff; background:#1b5e20; box-shadow:none;">
                            <span class="dashicons dashicons-media-spreadsheet"></span>
                            <?php esc_html_e('استخراج لیست سفارشات', 'reyhan-panel'); ?>
                        </button>
                    <?php else: ?>
                        <div class="rp-info-box" style="background:#fff; border:1px dashed #ccc; color:#777;">
                            <?php esc_html_e('ووکامرس نصب نیست.', 'reyhan-panel'); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="rp-modal-overlay" id="rp-export-modal">
    <div class="rp-modal-content" style="max-width: 500px;">
        <div class="rp-modal-header">
            <h3 id="rp-export-modal-title" style="padding: unset !important;"><?php esc_html_e('تنظیمات استخراج', 'reyhan-panel'); ?></h3>
            <div class="rp-modal-close" onclick="document.getElementById('rp-export-modal').classList.remove('active')">
                <span class="dashicons dashicons-no-alt"></span>
            </div>
        </div>
        
        <div class="rp-modal-body" style="padding: 25px !important; text-align: right;">
            <form id="rp-export-form" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post" target="_blank">
                <input type="hidden" name="action" value="rp_export_data">
                <input type="hidden" name="export_type" id="rp-export-type-input">
                <?php wp_nonce_field('rp_export_secure_nonce', 'security'); ?>

                <div class="rp-field-group">
                    <label class="rp-input-label-text"><?php esc_html_e('بازه زمانی', 'reyhan-panel'); ?></label>
                    <select name="date_range" class="rp-full-input">
                        <option value="week"><?php esc_html_e('یک هفته گذشته', 'reyhan-panel'); ?></option>
                        <option value="month" selected><?php esc_html_e('یک ماه گذشته', 'reyhan-panel'); ?></option>
                        <option value="3months"><?php esc_html_e('سه ماه گذشته', 'reyhan-panel'); ?></option>
                        <option value="year"><?php esc_html_e('یک سال گذشته', 'reyhan-panel'); ?></option>
                        <option value="all"><?php esc_html_e('همه زمان‌ها', 'reyhan-panel'); ?></option>
                    </select>
                </div>

                <div id="rp-export-dynamic-fields">
                    </div>

                <div class="rp-field-group" style="margin-top: 25px; border-top: 1px dashed #eee; padding-top: 20px;">
                    <label class="rp-input-label-text" style="margin-bottom: 15px; display:block;"><?php esc_html_e('فرمت فایل خروجی را انتخاب کنید', 'reyhan-panel'); ?></label>
    
                    <div class="rp-format-selector">
        
                        <label class="rp-format-option">
                            <input type="radio" name="format" value="excel" checked>
                        <div class="rp-format-card excel-theme">
                        <div class="rp-format-icon">
                        <span class="dashicons dashicons-media-spreadsheet"></span>
                    </div>
                    <div class="rp-format-info">
                    <span class="rp-fmt-title">Excel (CSV)</span>
                    <span class="rp-fmt-desc">مناسب برای تحلیل داده</span>
                    </div>
                    <div class="rp-check-mark">
                    <span class="dashicons dashicons-yes"></span>
                    </div>
                    </div>
                    </label>

                    <label class="rp-format-option">
                     <input type="radio" name="format" value="pdf">
                    <div class="rp-format-card pdf-theme">
                 <div class="rp-format-icon">
                    <span class="dashicons dashicons-media-document"></span>
                 </div>
                 <div class="rp-format-info">
                    <span class="rp-fmt-title">PDF / Print</span>
                    <span class="rp-fmt-desc">نسخه چاپی و رسمی</span>
                  </div>
                 <div class="rp-check-mark">
                    <span class="dashicons dashicons-yes"></span>
                 </div>
                </div>
                </label>

                </div>
            </div>

                <div class="rp-modal-footer" style="padding:0 !important; margin-top:20px; border:none !important; background:transparent !important;">
                    <button type="submit" class="rp-btn-primary-hero" style="width:100%; justify-content:center;">
                        <?php esc_html_e('دریافت خروجی', 'reyhan-panel'); ?>
                        <span class="dashicons dashicons-arrow-left-alt"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<template id="tpl-users-fields">
    <div class="rp-field-group">
        <label class="rp-input-label-text" style="margin-bottom: 15px; display:block;">
            <?php esc_html_e('فیلدهای مورد نظر را انتخاب کنید', 'reyhan-panel'); ?>
        </label>
        
        <div class="rp-fields-grid-modern">
            
            <label class="rp-field-option-modern">
                <input type="checkbox" name="fields[]" value="display_name" checked>
                <div class="rp-field-card-item">
                    <span class="rp-field-icon dashicons dashicons-id"></span>
                    <span class="rp-field-text"><?php esc_html_e('نام کامل', 'reyhan-panel'); ?></span>
                </div>
            </label>

            <label class="rp-field-option-modern">
                <input type="checkbox" name="fields[]" value="user_email" checked>
                <div class="rp-field-card-item">
                    <span class="rp-field-icon dashicons dashicons-email"></span>
                    <span class="rp-field-text"><?php esc_html_e('ایمیل', 'reyhan-panel'); ?></span>
                </div>
            </label>

            <label class="rp-field-option-modern">
                <input type="checkbox" name="fields[]" value="mobile" checked>
                <div class="rp-field-card-item">
                    <span class="rp-field-icon dashicons dashicons-smartphone"></span>
                    <span class="rp-field-text"><?php esc_html_e('شماره موبایل', 'reyhan-panel'); ?></span>
                </div>
            </label>

            <label class="rp-field-option-modern">
                <input type="checkbox" name="fields[]" value="address">
                <div class="rp-field-card-item">
                    <span class="rp-field-icon dashicons dashicons-location"></span>
                    <span class="rp-field-text"><?php esc_html_e('آدرس پستی', 'reyhan-panel'); ?></span>
                </div>
            </label>

            <label class="rp-field-option-modern">
                <input type="checkbox" name="fields[]" value="postcode">
                <div class="rp-field-card-item">
                    <span class="rp-field-icon dashicons dashicons-marker"></span>
                    <span class="rp-field-text"><?php esc_html_e('کد پستی', 'reyhan-panel'); ?></span>
                </div>
            </label>

        </div>
    </div>
</template>

<template id="tpl-tickets-fields">
    <div class="rp-field-group">
        <label class="rp-input-label-text"><?php esc_html_e('نوع گزارش', 'reyhan-panel'); ?></label>
        <select name="ticket_report_type" class="rp-full-input">
            <option value="list"><?php esc_html_e('لیست ریز تیکت‌ها', 'reyhan-panel'); ?></option>
            <option value="stats"><?php esc_html_e('تحلیل آماری و عملکرد ایجنت‌ها', 'reyhan-panel'); ?></option>
        </select>
        <p class="rp-modern-desc">
            <span class="dashicons dashicons-info"></span>
            <?php esc_html_e('در حالت تحلیل آماری، عملکرد پاسخگویی و تعداد تیکت‌ها بررسی می‌شود.', 'reyhan-panel'); ?>
        </p>
    </div>
</template>

<template id="tpl-orders-fields">
    <div class="rp-field-group">
        <label class="rp-input-label-text"><?php esc_html_e('فیلتر بر اساس وضعیت سفارش', 'reyhan-panel'); ?></label>
        <select name="order_status" class="rp-full-input" style="height:45px;">
            <option value="any"><?php esc_html_e('همه وضعیت‌ها', 'reyhan-panel'); ?></option>
            <option value="completed"><?php esc_html_e('تکمیل شده', 'reyhan-panel'); ?></option>
            <option value="processing"><?php esc_html_e('در حال پردازش', 'reyhan-panel'); ?></option>
            <option value="on-hold"><?php esc_html_e('در انتظار پرداخت', 'reyhan-panel'); ?></option>
            <option value="refunded"><?php esc_html_e('مسترد شده', 'reyhan-panel'); ?></option>
            <option value="failed"><?php esc_html_e('ناموفق', 'reyhan-panel'); ?></option>
            <option value="cancelled"><?php esc_html_e('لغو شده', 'reyhan-panel'); ?></option>
        </select>
    </div>

    <div class="rp-field-group" style="margin-top: 20px;">
        <label class="rp-input-label-text" style="margin-bottom: 15px; display:block;">
            <?php esc_html_e('میزان جزئیات گزارش را انتخاب کنید', 'reyhan-panel'); ?>
        </label>
        
        <div class="rp-format-selector">
            
            <label class="rp-format-option">
                <input type="radio" name="order_detail" value="summary" checked>
                <div class="rp-format-card summary-theme">
                    <div class="rp-format-icon">
                        <span class="dashicons dashicons-media-text"></span>
                    </div>
                    <div class="rp-format-info">
                        <span class="rp-fmt-title"><?php esc_html_e('گزارش خلاصه', 'reyhan-panel'); ?></span>
                        <span class="rp-fmt-desc"><?php esc_html_e('شماره، مشتری، قیمت کل', 'reyhan-panel'); ?></span>
                    </div>
                    <div class="rp-check-mark">
                        <span class="dashicons dashicons-yes"></span>
                    </div>
                </div>
            </label>

            <label class="rp-format-option">
                <input type="radio" name="order_detail" value="full">
                <div class="rp-format-card full-theme">
                    <div class="rp-format-icon">
                        <span class="dashicons dashicons-clipboard"></span>
                    </div>
                    <div class="rp-format-info">
                        <span class="rp-fmt-title"><?php esc_html_e('گزارش جامع', 'reyhan-panel'); ?></span>
                        <span class="rp-fmt-desc"><?php esc_html_e('به همراه ریز آیتم‌ها و آدرس', 'reyhan-panel'); ?></span>
                    </div>
                    <div class="rp-check-mark">
                        <span class="dashicons dashicons-yes"></span>
                    </div>
                </div>
            </label>

        </div>
    </div>
</template>

<div class="rp-guide-box" style="margin-top: 60px; margin-left: 20px; box-sizing: border-box; background-color: #fff5f5; border: 1px solid #ffcdd2; border-right: 5px solid #d32f2f; font-family: 'ReyhanFont', Tahoma, sans-serif !important;">
            <div class="rp-guide-title" style="color: #d32f2f; font-family: 'ReyhanFont', Tahoma, sans-serif !important;">
                <span class="dashicons dashicons-warning"></span> 
                <?php esc_html_e('توجه', 'reyhan-panel'); ?>
            </div>
            <p style="color: #b71c1c; font-family: 'ReyhanFont', Tahoma, sans-serif !important;">
                <?php esc_html_e('گزارش‌هایی که افزونه ی ریحان پنل ارائه می‌دهد صرفاً بر اساس دیتابیس سایت شما و سیستمی می‌باشد. بنابراین اگر مشکل یا خللی در دیتابیس باشد یا ایجاد شود، احتمال گزارش اشتباه نیز وجود دارد و تبعات از عهده ی تیم ریحان پنل خارج است.', 'reyhan-panel'); ?>
            </p>
        </div>