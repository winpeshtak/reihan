jQuery(document).ready(function($) {
    
    // Trigger Export Modal
    $('.rp-trigger-export').on('click', function(e) {
        e.preventDefault();
        
        let type = $(this).data('target');
        let modal = $('#rp-export-modal');
        let dynamicContainer = $('#rp-export-dynamic-fields');
        let typeInput = $('#rp-export-type-input');
        
        // Reset Container
        dynamicContainer.empty();
        typeInput.val(type);
        
        // Load Specific Fields
        let tplId = 'tpl-' + type + '-fields';
        let templateContent = document.getElementById(tplId);
        
        if(templateContent) {
            let clone = document.importNode(templateContent.content, true);
            dynamicContainer.append(clone);
        }
        
        // Update Title
        let titleMap = {
            'users': 'استخراج کاربران',
            'tickets': 'گزارش و آمار تیکت‌ها',
            'orders': 'خروجی سفارشات'
        };
        $('#rp-export-modal-title').text(titleMap[type] || 'تنظیمات استخراج');
        
        // Show Modal
        modal.addClass('active');
    });

    // Close Modal on Overlay Click
    $('.rp-modal-overlay').on('click', function(e) {
        if($(e.target).hasClass('rp-modal-overlay')) {
            $(this).removeClass('active');
        }
    });

    // Handle Form Submit (Optional UI feedback)
    $('#rp-export-form').on('submit', function() {
        // We can close modal after a slight delay
        setTimeout(function(){
            $('#rp-export-modal').removeClass('active');
        }, 1000);
    });
});