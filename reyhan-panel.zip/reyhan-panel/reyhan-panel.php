<?php
/*
Plugin Name: ریحان پنل
Description: یک سیستم جامع پنل کاربری با امکاناتی فوق العاده به همراه یک سیستم اختصاصی تیکتینگ برای پاسخگویی به کاربرانتان. رابط کاربری آسان | کاربردی | سبک
Version: 1.2
Author: AliREYHANI
Author URI: https://example.com
Text Domain: reyhan-panel
Domain Path: /languages
*/

use ReyhanPanel\Core\Assets;
use ReyhanPanel\Core\PostTypes;
use ReyhanPanel\Core\AuthRedirects;
use ReyhanPanel\Admin\Settings;
use ReyhanPanel\Admin\Wizard;
use ReyhanPanel\Frontend\Controller as FrontendController;
use ReyhanPanel\Core\License;
use ReyhanPanel\Admin\UserFieldsManager;

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'REYHAN_VERSION', '1.2' );
define( 'REYHAN_DIR', plugin_dir_path( __FILE__ ) );
define( 'REYHAN_URL', plugin_dir_url( __FILE__ ) );

spl_autoload_register(function ($class) {
    $prefix = 'ReyhanPanel\\';
    $base_dir = REYHAN_DIR . 'src/';
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) return;
    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
    if (file_exists($file)) require $file;
});

final class ReyhanPlugin {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action( 'plugins_loaded', [ $this, 'load_textdomain' ] );
        add_action( 'admin_notices', [ $this, 'check_license_notice' ] );

        $this->init_core();

        if ( License::is_active() ) {
            $this->init_admin();
        } else {
            if ( is_admin() ) {
                new Wizard();
            }
        }

        $this->init_frontend();
        $this->init_ajax();
    }

    public function load_textdomain() {
        load_plugin_textdomain( 'reyhan-panel', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }

    public function check_license_notice() {
        if ( isset($_GET['page']) && $_GET['page'] === 'reyhan-setup' ) return;

        if ( ! License::is_active() ) {
            ?>
            <div class="notice notice-error is-dismissible">
                <p>
                    <strong><?php _e('هشدار مهم:', 'reyhan-panel'); ?></strong>
                    <?php _e('لایسنس افزونه "ریحان پنل" فعال نشده است. لطفا لایسنس معتبر را وارد کنید', 'reyhan-panel'); ?>
                    <a href="<?php echo admin_url('index.php?page=reyhan-setup'); ?>" class="button button-primary" style="margin-right: 10px;"><?php _e('فعال‌سازی لایسنس', 'reyhan-panel'); ?></a>
                </p>
            </div>
            <?php
        }
    }

    private function init_core() {
        new Assets();
        new PostTypes();
        new AuthRedirects();

        if ( ! class_exists( 'ReyhanPanel\Core\License' ) ) {
            require_once REYHAN_DIR . 'src/Core/License.php';
        }
        
        // فراخوانی متد نمایش نوار ابزار در سطح هسته (برای اجرا در فرانت)
        add_action('init', [ $this, 'force_agent_toolbar' ], 999);
    }

    /**
     * متد جدید: اجبار نمایش نوار ابزار برای ایجنت‌ها
     */
    public function force_agent_toolbar() {
        if ( ! is_user_logged_in() ) return;
        
        $uid = get_current_user_id();

        // استفاده از تابع سراسری تعریف شده در پایین فایل
        if ( function_exists('rp_is_support_agent') && rp_is_support_agent( $uid ) ) {
            // 1. نمایش نوار ابزار
            add_filter( 'show_admin_bar', '__return_true', 99999 );
            
            // 2. اوردرایت کردن تنظیمات پروفایل کاربر (اگر تیک "نمایش نوار ابزار" را برداشته باشد)
            add_filter( 'get_user_option_show_admin_bar_front', '__return_true', 99999 );
        }
    }

    private function init_admin() {
        if ( is_admin() ) {
            new Settings();
            new Wizard();
        }
    }

    private function init_frontend() {
        new FrontendController();
    }

    private function init_ajax() {
        new \ReyhanPanel\Ajax\Auth();
        new \ReyhanPanel\Ajax\UserTicket();
        if ( is_admin() ) new \ReyhanPanel\Ajax\AdminTicket();

        require_once REYHAN_DIR . 'src/Ajax/Notifications.php';
        new \ReyhanPanel\Ajax\Notifications();
    }

    public static function activate() {
        add_option( 'reyhan_do_activation_redirect', true );
    }
}

function reyhan_panel() { return ReyhanPlugin::instance(); }
add_action( 'plugins_loaded', 'reyhan_panel' );
register_activation_hook( __FILE__, [ 'ReyhanPlugin', 'activate' ] );

/* =========================================
   موتور همگام‌سازی داده‌ها (Sync Engine)
   ========================================= */
add_action( 'updated_user_meta', 'rp_master_sync_user_meta', 10, 4 );
add_action( 'added_user_meta', 'rp_master_sync_user_meta', 10, 4 );

function rp_master_sync_user_meta( $meta_id, $user_id, $meta_key, $_meta_value ) {
    // جلوگیری از لوپ بی‌نهایت (Recursion)
    remove_action( 'updated_user_meta', 'rp_master_sync_user_meta', 10 );
    remove_action( 'added_user_meta', 'rp_master_sync_user_meta', 10 );

    // 1. همگام‌سازی موبایل
    if ( in_array( $meta_key, ['mobile', 'billing_phone', 'rp_verified_mobile'] ) ) {
        $clean_phone = sanitize_text_field( $_meta_value );
        if ( $meta_key !== 'mobile' ) update_user_meta( $user_id, 'mobile', $clean_phone );
        if ( $meta_key !== 'billing_phone' ) update_user_meta( $user_id, 'billing_phone', $clean_phone );
        if ( $meta_key !== 'rp_verified_mobile' ) update_user_meta( $user_id, 'rp_verified_mobile', $clean_phone );
    }

    // 2. همگام‌سازی استان
    if ( in_array( $meta_key, ['rp_state', 'billing_state'] ) ) {
        if ( $meta_key !== 'billing_state' ) update_user_meta( $user_id, 'billing_state', $_meta_value );
        if ( $meta_key !== 'rp_state' ) update_user_meta( $user_id, 'rp_state', $_meta_value );
    }

    // 3. همگام‌سازی شهر
    if ( in_array( $meta_key, ['rp_city', 'billing_city'] ) ) {
        if ( $meta_key !== 'billing_city' ) update_user_meta( $user_id, 'billing_city', $_meta_value );
        if ( $meta_key !== 'rp_city' ) update_user_meta( $user_id, 'rp_city', $_meta_value );
    }

    // فعال‌سازی مجدد هوک
    add_action( 'updated_user_meta', 'rp_master_sync_user_meta', 10, 4 );
    add_action( 'added_user_meta', 'rp_master_sync_user_meta', 10, 4 );
}

/* =======================================================
   توابع کمکی نقش/ایجنت (یک‌بار تعریف، بدون تداخل)
   ======================================================= */

function rp_user_is_content_role( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();
    $user = get_userdata( $user_id );
    if ( ! $user ) return false;

    $roles = (array) $user->roles;

    // نقش‌هایی که باید WP-Admin و بخش تولید محتوا را داشته باشند
    return (bool) array_intersect( $roles, ['administrator','editor','author','contributor'] );
}

/**
 * تشخیص ایجنت بر اساس دیتای خود افزونه (Option)
 * (همان منطقی که در MenuManager و PostTypes استفاده شده)
 */
function rp_is_support_agent( $user_id ) {
    $agents_raw = get_option('reyhan_heavy_ticket_support_agents_data');
    if ( ! $agents_raw ) {
        $opts = get_option('reyhan_options');
        $agents_raw = $opts['ticket_support_agents_data'] ?? '[]';
    }

    $agents = is_string($agents_raw) ? json_decode($agents_raw, true) : $agents_raw;
    if ( ! is_array($agents) ) return false;

    foreach ( $agents as $agent ) {
        if ( isset($agent['id']) && intval($agent['id']) === intval($user_id) ) {
            return true;
        }
    }
    return false;
}

/**
 * اگر ووکامرس دسترسی wp-admin را ببندد، اینجا نویسنده‌ها و ایجنت‌ها را آزاد می‌کنیم.
 */
add_filter('woocommerce_prevent_admin_access', function( $prevent_access ) {
    if ( ! is_user_logged_in() ) return $prevent_access;

    $uid = get_current_user_id();

    // مدیر همیشه آزاد
    if ( current_user_can('manage_options') ) return false;

    // نویسنده/ویرایشگر/کانتریبیوتر آزاد
    if ( rp_user_is_content_role( $uid ) ) return false;

    // ایجنت هم آزاد
    if ( rp_is_support_agent( $uid ) ) return false;

    return $prevent_access;
}, 999);

/* =======================================================
   سیستم مدیریت دسترسی پیشرفته (Admin Access Control)
   هدف: نویسنده غیرایجنت -> دسترسی نویسندگی داشته باشد
   ======================================================= */

// 1. گیت ورودی (امنیت و ریدایرکت)
add_action('admin_init', 'reyhan_secure_dashboard_access');

function reyhan_secure_dashboard_access() {
    if ( ( defined('DOING_AJAX') && DOING_AJAX ) || ! is_user_logged_in() ) {
        return;
    }

    global $pagenow;
    $user_id = get_current_user_id();

    // --- قانون 1: بستن پروفایل برای غیر مدیران ---
    if ( ! current_user_can( 'manage_options' ) ) {
        if ( $pagenow == 'profile.php' || $pagenow == 'user-edit.php' ) {
            wp_redirect( admin_url() );
            exit;
        }
    }

    // --- قانون 2: بررسی حق ورود به پیشخوان ---

    // مدیر -> OK
    if ( current_user_can( 'manage_options' ) ) {
        return;
    }

    // نقش تولید محتوا (author/editor/contributor) -> OK
    if ( rp_user_is_content_role( $user_id ) ) {
        return;
    }

    // ایجنت -> OK
    if ( rp_is_support_agent( $user_id ) ) {
        return;
    }

    // سایر کاربران -> پنل کاربری
    wp_redirect( home_url( '/panel' ) );
    exit;
}

// 2. مدیریت منوها (تمیزکاری ظاهری)
add_action('admin_menu', 'reyhan_manage_admin_menus', 999);

function reyhan_manage_admin_menus() {
    $user_id = get_current_user_id();

    if ( current_user_can( 'manage_options' ) ) {
        return;
    }

    // حذف منوی پروفایل برای همه
    remove_menu_page( 'profile.php' );
    remove_submenu_page( 'users.php', 'profile.php' );

    // اگر فقط ایجنت است و هیچ نقش محتوایی ندارد، منوهای وردپرس را محدود کن
    $is_agent  = rp_is_support_agent( $user_id );
    $can_write = rp_user_is_content_role( $user_id );

    if ( $is_agent && ! $can_write ) {
        remove_menu_page( 'index.php' );
        remove_menu_page( 'edit.php' );
        remove_menu_page( 'upload.php' );
        remove_menu_page( 'edit-comments.php' );
        remove_menu_page( 'themes.php' );
        remove_menu_page( 'plugins.php' );
        remove_menu_page( 'users.php' );
        remove_menu_page( 'tools.php' );
        remove_menu_page( 'options-general.php' );
    }
}

// 3. پاکسازی نوار ابزار بالا (فقط حذف آیتم‌های مزاحم، نه مخفی کردن کل نوار)
add_action('admin_bar_menu', 'reyhan_clean_admin_bar', 999);

function reyhan_clean_admin_bar($wp_admin_bar) {
    if ( current_user_can( 'manage_options' ) ) {
        return;
    }

    // حذف منوی شناسنامه از نوار بالا برای همه (چون به پروفایل دسترسی ندارند)
    $wp_admin_bar->remove_node('my-account');
    $wp_admin_bar->remove_node('edit-profile');
    $wp_admin_bar->remove_node('user-info');

    // اگر فقط ایجنت است (نقش محتوایی ندارد)، نوار ابزار خلوت شود
    $uid       = get_current_user_id();
    $is_agent  = rp_is_support_agent( $uid );
    $can_write = rp_user_is_content_role( $uid );

    if ( $is_agent && ! $can_write ) {
        $wp_admin_bar->remove_node('wp-logo');
        $wp_admin_bar->remove_node('comments');
        $wp_admin_bar->remove_node('new-content');
        $wp_admin_bar->remove_node('updates');
    }

}

register_activation_hook( __FILE__, 'reyhan_panel_security_setup' );

function reyhan_panel_security_setup() {
    // 1. مسیر پوشه آپلودهای وردپرس را بگیر
    $upload_dir = wp_upload_dir();
    
    // 2. نام پوشه‌ای که فایل‌های تیکت در آن ذخیره می‌شوند (باید با کدهای دیگر افزونه یکی باشد)
    // معمولاً نامش reyhan-uploads یا چیزی شبیه این است. ما اینجا پوشه امن می‌سازیم.
    $target_dir = $upload_dir['basedir'] . '/reyhan_secure_uploads';

    // 3. اگر پوشه نبود، آن را بساز
    if ( ! file_exists( $target_dir ) ) {
        wp_mkdir_p( $target_dir );
    }

    // 4. ساخت فایل .htaccess برای ممنوعیت اجرای کد
    $htaccess_content = "<Files *.php>\nDeny from all\n</Files>\n";
    $htaccess_path    = $target_dir . '/.htaccess';

    if ( ! file_exists( $htaccess_path ) ) {
        file_put_contents( $htaccess_path, $htaccess_content );
    }

    // 5. ساخت فایل index.php خالی برای جلوگیری از لیست شدن فایل‌ها (Directory Listing)
    $index_path = $target_dir . '/index.php';
    if ( ! file_exists( $index_path ) ) {
        file_put_contents( $index_path, '<?php // Silence is golden.' );
    }
}

function reyhan_run_plugin() {
    // ... سایر کلاس‌ها
    new \ReyhanPanel\Ajax\ExportHandler();
}
add_action( 'plugins_loaded', 'reyhan_run_plugin' );