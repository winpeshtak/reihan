/* assets/js/admin/app.js */

(function ($) {
    'use strict';

    const GardoonakAdmin = {
        selectedPageIds: new Set(),

        init: function () {
            this.handleTabs();
            this.handleSettingsForm();
            this.handleTriggers();
            this.handleColorPicker();
            this.handleMediaUpload();
            this.handlePageSelection();
            this.initUiElements();
            this.handleFloatButton();
            this.handleSecurity();
            this.handleEmail();
            this.handleSMS();
            this.handleWheelBuilder();
        },

        /**
         * مدیریت جابجایی بین تب‌ها
         */
        handleTabs: function () {
            const $tabItems = $('.gardoonak-tabs-nav li');
            const $tabPanes = $('.gardoonak-tab-pane');

            $tabItems.on('click', function () {
                const $this = $(this);
                const targetTab = $this.data('tab');

                $tabItems.removeClass('active');
                $this.addClass('active');

                $tabPanes.removeClass('active').hide();
                $('#' + targetTab).fadeIn(300).addClass('active');
            });
        },

        /**
         * مدیریت فرم و ارسال AJAX
         */
        handleSettingsForm: function () {
            const $form = $('#gardoonak-settings-form');
            const $saveBtn = $form.find('.gn-btn');
            const $btnText = $saveBtn.find('.btn-text');
            const originalText = $btnText.text();

            $form.on('submit', function (e) {
                e.preventDefault();

                $saveBtn.prop('disabled', true).addClass('loading');
                $btnText.text('در حال ذخیره‌سازی...');

                // شبیه‌سازی ارسال (در آینده با wp_ajax تکمیل می‌شود)
                setTimeout(function () {
                    if (typeof window.gn_notify === 'function') {
                        window.gn_notify('تمامی تنظیمات با موفقیت بروزرسانی شدند.', 'success');
                    }
                    $saveBtn.prop('disabled', false).removeClass('loading');
                    $btnText.text(originalText);
                }, 1000);
            });
        },

        /**
         * مدیریت نمایش شرطی المان‌ها (Triggers & Terms)
         */
        handleTriggers: function () {
            // نمایش اینپوت صفحات خاص
            $('#gn_display_location').on('change', function () {
                const isSpecific = $(this).val() === 'specific';
                $('#specific_pages_wrapper')[isSpecific ? 'slideDown' : 'slideUp'](300);
            });

            // نمایش انتخاب برگه قوانین
            $('input[name="enable_terms"]').on('change', function () {
                const isEnabled = $(this).val() === '1';
                $('#terms_page_wrapper')[isEnabled ? 'fadeIn' : 'fadeOut'](300).css('display', isEnabled ? 'flex' : 'none');
            });
        },

        /**
         * مدیریت انتخاب صفحات و تگ‌ها
         */
        handlePageSelection: function () {
            const self = this;

            $('#gn_page_dropdown').on('change', function () {
                const pageId = $(this).val();
                const pageTitle = $(this).find('option:selected').text();

                if (pageId && !self.selectedPageIds.has(pageId)) {
                    self.selectedPageIds.add(pageId);

                    const $tag = $(`
                        <div class="gn-page-tag" data-id="${pageId}">
                            <span>${pageTitle}</span>
                            <span class="remove-tag" title="حذف">&times;</span>
                        </div>
                    `);

                    $('#gn_selected_pages_list').append($tag);
                    self.updateHiddenPageInput();
                }
                $(this).val('');
            });

            $(document).on('click', '.remove-tag', function () {
                const $tag = $(this).closest('.gn-page-tag');
                const pageId = $tag.data('id').toString();

                self.selectedPageIds.delete(pageId);
                $tag.fadeOut(200, function () {
                    $(this).remove();
                    self.updateHiddenPageInput();
                });
            });
        },

        updateHiddenPageInput: function () {
            const idsArray = Array.from(this.selectedPageIds);
            $('#gn_specific_pages_ids').val(idsArray.join(','));
        },

        /**
         * کالرپیکر مدرن
         */
        handleColorPicker: function () {
            $('#float_btn_color').on('input', function () {
                const color = $(this).val();
                $('#float_color_preview').css('background', color);
                $('.gn-color-hex').text(color);
            });
        },

        /**
         * مدیریت آپلود تصاویر با وردپرس مدیا
         */
        handleMediaUpload: function () {
            // آپلودر لوگو و آیکون شناور
            $('#gn_upload_logo_btn, #gn_upload_float_icon').on('click', function (e) {
                e.preventDefault();
                const $btn = $(this);
                const isLogo = $btn.attr('id') === 'gn_upload_logo_btn';

                const frame = wp.media({
                    title: isLogo ? 'انتخاب لوگوی مرکز گردونه' : 'انتخاب آیکون شناور',
                    button: { text: 'استفاده از این فایل' },
                    multiple: false
                });

                frame.on('select', function () {
                    const attachment = frame.state().get('selection').first().toJSON();
                    if (isLogo) {
                        $('#gn_wheel_logo_input').val(attachment.url);
                        $('#gn_logo_preview').html(`<img src="${attachment.url}">`);
                    } else {
                        $('#gn_custom_float_icon').val(attachment.url);
                        $('#gn_float_icon_preview').html(`<img src="${attachment.url}">`);
                    }
                });
                frame.open();
            });
        },

        /**
         * مقداردهی اولیه UI
         */
        initUiElements: function () {
            // انیمیشن کارت‌های تنظیمات (اصلاح شده به gn-form-row)
            $('.gardoonak-tab-pane.active').find('.gn-form-row').each(function (i) {
                $(this).css({ opacity: 0, marginTop: '20px' })
                    .delay(100 * i)
                    .animate({ opacity: 1, marginTop: '0px' }, 400);
            });
        },

        handleFloatButton: function () {
            // فقط لاجیک کلیک روی پالت‌های رنگی باقی بماند
            $('.gn-color-preset').on('click', function () {
                const color = $(this).data('color');

                // تغییر کلاس اکتیو
                $('.gn-color-preset').removeClass('active');
                $(this).addClass('active');

                // ذخیره در اینپوت اصلی
                $('#float_btn_color').val(color);
            });

            // لاجیک نمایش/مخفی کردن آپلودر
            $('input[name="use_default_icon"]').on('change', function () {
                const val = $(this).val();
                if (val === '0') {
                    $('#gn_custom_icon_row').slideDown(300).css('display', 'flex');
                } else {
                    $('#gn_custom_icon_row').slideUp(300);
                }
            });

            // وضعیت اولیه
            if ($('input[name="use_default_icon"]:checked').val() === '0') {
                $('#gn_custom_icon_row').show().css('display', 'flex');
            }
        },

        handleSecurity: function () {
            // نمایش/مخفی کردن فیلدهای ریکپچا
            $('input[name="security_recaptcha"]').on('change', function () {
                const val = $(this).val();
                if (val === '1') {
                    $('#gn_recaptcha_fields').slideDown(300);
                } else {
                    $('#gn_recaptcha_fields').slideUp(300);
                }
            });

            // بررسی وضعیت اولیه ریکپچا
            if ($('input[name="security_recaptcha"]:checked').val() === '1') {
                $('#gn_recaptcha_fields').show();
            }
        },

        /**
         * مدیریت تب ایمیل
         */
        handleEmail: function () {
            // 1. نمایش/مخفی کردن تنظیمات ایمیل
            $('input[name="enable_winner_email"]').on('change', function () {
                const val = $(this).val();
                if (val === '1') {
                    $('#gn_email_settings_wrapper').slideDown(400);
                } else {
                    $('#gn_email_settings_wrapper').slideUp(400);
                }
            });

            // وضعیت اولیه
            if ($('input[name="enable_winner_email"]:checked').val() === '1') {
                $('#gn_email_settings_wrapper').show();
            }

            // 2. کپی کردن شورت‌کدها با کلیک
            $('.gn-shortcode-list .gn-tag').on('click', function () {
                const text = $(this).text();

                // کپی در کلیپ‌بورد
                navigator.clipboard.writeText(text).then(function () {
                    // نمایش نوتیفیکیشن موفقیت (با استفاده از سیستم نوتیف خودمان)
                    if (typeof window.gn_notify === 'function') {
                        window.gn_notify('کد ' + text + ' کپی شد!', 'success');
                    } else {
                        alert('کپی شد: ' + text);
                    }
                });
            });
        },

        /**
         * مدیریت تب پیامک
         */
        handleSMS: function () {
            // 1. نمایش/مخفی کردن کل تنظیمات پیامک
            $('input[name="enable_sms"]').on('change', function () {
                const val = $(this).val();
                if (val === '1') {
                    $('#gn_sms_settings_wrapper').slideDown(400);
                } else {
                    $('#gn_sms_settings_wrapper').slideUp(400);
                }
            });

            // وضعیت اولیه سوییچ اصلی
            if ($('input[name="enable_sms"]:checked').val() === '1') {
                $('#gn_sms_settings_wrapper').show();
            }

            // 2. سوییچ بین پترن و عادی
            $('input[name="sms_send_method"]').on('change', function () {
                const method = $(this).val();

                if (method === 'pattern') {
                    $('#gn_sms_normal_box').hide();
                    $('#gn_sms_pattern_box').fadeIn(300);
                } else {
                    $('#gn_sms_pattern_box').hide();
                    $('#gn_sms_normal_box').fadeIn(300);
                }
            });

            // 3. شبیه‌سازی تست اتصال (صرفاً برای نمایش UI)
            $('#gn_test_sms_connection').on('click', function (e) {
                e.preventDefault();
                const $btn = $(this);
                const originalText = $btn.html();

                $btn.html('<span class="dashicons dashicons-update" style="animation: spin 1s infinite linear;"></span> در حال بررسی...');

                // شبیه‌سازی درخواست AJAX
                setTimeout(function () {
                    $('#gn_sms_connection_status').html('<span class="dashicons dashicons-yes-alt" style="color: #2ecc71;"></span> متصل شد');
                    $('#gn_sms_balance').text('1,500,000');
                    $btn.html(originalText);
                    if (window.gn_notify) window.gn_notify('ارتباط با پنل پیامکی با موفقیت برقرار شد.', 'success');
                }, 1500);
            });
        },

        /**
         * مدیریت بیلدر گردونه (Repeater + Live Preview)
         */
        handleWheelBuilder: function () {
            const self = this;
            const $container = $('#gn_slices_container');
            const $wheel = $('#gn_live_wheel');

            // 1. تابع رسم مجدد گردونه (Live Preview)
            function updatePreview() {
                let slices = [];
                let totalSlices = 0;

                // جمع‌آوری اطلاعات از فرم
                $container.find('.gn-slice-item').each(function () {
                    const color = $(this).find('.slice-color').val();
                    const chance = parseInt($(this).find('.slice-chance').val()) || 0;
                    slices.push({ color, chance });
                    totalSlices++;
                });

                if (totalSlices === 0) {
                    $wheel.css('background', '#ccc');
                    return;
                }

                // محاسبه گرادینت
                // نکته: برای سادگی نمایش، فرض می‌کنیم همه پره‌ها اندازه مساوی دارند (مگر اینکه بخواهید بر اساس شانس سایز تغییر کند)
                // اینجا حالت "اندازه مساوی" را پیاده می‌کنیم که رایج‌تر است.
                let gradientStr = 'conic-gradient(';
                let degPerSlice = 360 / totalSlices;

                slices.forEach((slice, index) => {
                    let startDeg = index * degPerSlice;
                    let endDeg = (index + 1) * degPerSlice;
                    gradientStr += `${slice.color} ${startDeg}deg ${endDeg}deg`;
                    if (index < slices.length - 1) gradientStr += ', ';
                });
                gradientStr += ')';

                $wheel.css('background', gradientStr);
            }

            // 2. افزودن پره جدید
            $('#gn_add_slice').on('click', function () {
                const template = document.getElementById('gn_slice_template').innerHTML;
                const index = $container.children().length;
                // جایگذاری ایندکس برای نام‌های یونیک
                const html = template.replace(/{INDEX}/g, index);

                const $newItem = $(html);
                $container.append($newItem);

                // باز کردن آکاردئون آیتم جدید
                $newItem.find('.gn-slice-body').slideDown();

                // تولید رنگ تصادفی برای زیبایی
                const randomColor = '#' + Math.floor(Math.random() * 16777215).toString(16);
                $newItem.find('.slice-color').val(randomColor);

                updatePreview();
            });

            // 3. حذف پره
            $container.on('click', '.gn-slice-remove', function (e) {
                e.stopPropagation(); // جلوگیری از باز/بسته شدن آکاردئون
                if (confirm('آیا مطمئن هستید؟')) {
                    $(this).closest('.gn-slice-item').slideUp(200, function () {
                        $(this).remove();
                        updatePreview();
                    });
                }
            });

            // 4. باز/بسته شدن آکاردئون
            $container.on('click', '.gn-slice-header', function () {
                const $body = $(this).next('.gn-slice-body');
                const $icon = $(this).find('.gn-slice-toggle-icon');

                $body.slideToggle(200);
                // چرخش آیکون فلش
                if ($body.is(':visible')) {
                    $icon.css('transform', 'rotate(0deg)');
                } else {
                    $icon.css('transform', 'rotate(180deg)');
                }
            });

            // 5. آپدیت تایتل پره هنگام تایپ
            $container.on('input', '.slice-label', function () {
                const val = $(this).val();
                $(this).closest('.gn-slice-item').find('.gn-slice-title-display').text(val || 'پره بدون نام');
            });

            // 6. آپدیت پریویو با تغییر هر اینپوت
            $container.on('input change', 'input', function () {
                updatePreview();
            });

            // 7. دکمه تست چرخش
            $('#gn_test_spin').on('click', function () {
                const spinCount = $('#wheel_spin_count').val() || 8;
                const duration = $('#wheel_spin_duration').val() || 5;

                // چرخش تصادفی
                const randomDeg = Math.floor(Math.random() * 360) + (spinCount * 360);

                $wheel.css('transition', `transform ${duration}s cubic-bezier(0.25, 0.1, 0.25, 1)`);
                $wheel.css('transform', `rotate(${randomDeg}deg)`);

                // ریست کردن بعد از اتمام (برای تست مجدد)
                setTimeout(() => {
                    $wheel.css('transition', 'none');
                    const actualDeg = randomDeg % 360;
                    $wheel.css('transform', `rotate(${actualDeg}deg)`);
                }, duration * 1000);
            });

            // افزودن 3 پره پیش‌فرض در شروع کار
            if ($container.children().length === 0) {
                $('#gn_add_slice').click();
                $('#gn_add_slice').click();
                $('#gn_add_slice').click();

                // رنگ‌بندی اولیه زیبا
                setTimeout(() => {
                    $container.find('.slice-color').eq(0).val('#ff4757');
                    $container.find('.slice-color').eq(1).val('#2ecc71');
                    $container.find('.slice-color').eq(2).val('#f1c40f');
                    updatePreview();
                }, 100);
            }
        },

    };

    $(document).ready(function () {
        GardoonakAdmin.init();
    });

})(jQuery);