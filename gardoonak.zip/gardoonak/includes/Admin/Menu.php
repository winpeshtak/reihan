<?php
namespace Gardoonak\Admin;

defined( 'ABSPATH' ) || exit;

class Menu {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'register_custom_menus' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_init', [ $this, 'check_license_and_redirect' ] );
        add_filter( 'admin_body_class', [ $this, 'add_wizard_body_class' ] );
        add_action( 'wp_ajax_gardoonak_activate_license', [ $this, 'handle_license_activation' ] );

        require_once GARDOONAK_PATH . 'includes/Admin/Ajax.php';
        new \Gardoonak\Admin\Ajax();
    }

    public function add_wizard_body_class( $classes ) {
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'gardoonak-activation' ) {
            return "$classes gardoonak-wizard-mode";
        }
        return $classes;
    }

    public function check_license_and_redirect() {
        if ( $this->is_license_active() ) {
            return;
        }

        if ( isset( $_GET['page'] ) && strpos( $_GET['page'], 'gardoonak' ) !== false ) {
            if ( $_GET['page'] !== 'gardoonak-activation' ) {
                wp_redirect( admin_url( 'admin.php?page=gardoonak-activation' ) );
                exit;
            }
        }
    }

    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'gardoonak' ) === false ) {
            return;
        }
        $version = GARDOONAK_VERSION; 

        wp_enqueue_media();
        wp_enqueue_style( 'gardoonak-ui-modal', GARDOONAK_URL . 'assets/css/admin/kit/ui-modal.css', [], $version );
        wp_enqueue_style( 'gardoonak-admin-layout', GARDOONAK_URL . 'assets/css/admin/layout.css', [], $version );
        wp_enqueue_style( 'gardoonak-ui-vars', GARDOONAK_URL . 'assets/css/admin/kit/ui-vars.css', [], $version );
        wp_enqueue_style( 'gardoonak-ui-buttons', GARDOONAK_URL . 'assets/css/admin/kit/ui-buttons.css', [], $version );
        wp_enqueue_style( 'gardoonak-ui-forms', GARDOONAK_URL . 'assets/css/admin/kit/ui-forms.css', [], $version );
        wp_enqueue_style( 'gardoonak-ui-notif', GARDOONAK_URL . 'assets/css/admin/kit/ui-notif.css', [], $version );
        
        // اسکریپت نوتیفیکیشن
        wp_enqueue_script( 'gardoonak-notifications', GARDOONAK_URL . 'assets/js/admin/notifications.js', ['jquery'], $version, true );

        // بررسی صفحه ویزارد یا داشبورد
        if ( strpos( $hook, 'gardoonak-wizard' ) !== false ) {
            // استایل‌های صفحه ویزارد
            wp_enqueue_style( 'gardoonak-wizard-css', GARDOONAK_URL . 'assets/css/admin/wizard.css', [], $version );
            wp_enqueue_script( 'gardoonak-wizard-js', GARDOONAK_URL . 'assets/js/admin/wizard.js', ['jquery'], $version, true );
            
            wp_localize_script( 'gardoonak-wizard-js', 'gardoonak_wizard', [
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'gardoonak_wizard_nonce' )
            ]);

        } else {
            // استایل‌های صفحه مدیریت گردونه‌ها
            wp_enqueue_style( 'gardoonak-dashboard', GARDOONAK_URL . 'assets/css/admin/dashboard.css', [], $version );
            wp_enqueue_style( 'gardoonak-ui-layout', GARDOONAK_URL . 'assets/css/admin/kit/ui-layout.css', [], $version );
            wp_enqueue_style( 'gardoonak-ui-choices', GARDOONAK_URL . 'assets/css/admin/kit/ui-choices.css', [], $version );
            
            // پیش‌نیاز کالر پیکر
            wp_enqueue_style( 'wp-color-picker' );

            // اسکریپت اصلی (app.js)
            wp_enqueue_script( 'gardoonak-admin-js', GARDOONAK_URL . 'assets/js/admin/app.js', ['jquery', 'gardoonak-notifications', 'wp-color-picker'], $version, true );
            
            // ارسال اطلاعات به JS
            wp_localize_script( 'gardoonak-admin-js', 'gardoonak_ajax', [
                'url'   => admin_url( 'admin-ajax.php' ),
                'nonce' => wp_create_nonce( 'gardoonak_nonce' )
            ]);
        }
    }

    public function register_custom_menus() {
        $capability = 'manage_options';
        $icon_url   = GARDOONAK_URL . 'assets/images/logo.svg';

        // 1. منوی فعال‌سازی (مخفی یا اولیه)
        add_submenu_page( null, 'فعال‌سازی گردونک', 'فعال‌سازی', $capability, 'gardoonak-activation', [ $this, 'render_activation_wizard' ] );

        // 2. منوی اصلی
        add_menu_page( 'گردونک', 'گردونک', $capability, 'gardoonak', [ $this, 'render_general_settings_page' ], $icon_url, 25 );

        // 3. زیرمنوی تنظیمات عمومی
        add_submenu_page( 'gardoonak', 'تنظیمات عمومی', 'تنظیمات عمومی', $capability, 'gardoonak', [ $this, 'render_general_settings_page' ] );

        // 4. زیرمنوی مدیریت گردونه‌ها
        add_submenu_page( 'gardoonak', 'مدیریت گردونه‌ها', 'گردونه‌ها', $capability, 'gardoonak-wheels', [ $this, 'render_wheels_management_page' ] );

        // 5. زیرمنوی جدید: آمار و داده‌ها (اصلاح شد)
        add_submenu_page( 'gardoonak', 'آمار و گزارشات', 'آمار و داده‌ها', $capability, 'gardoonak-analytics', [ $this, 'render_analytics_page' ] );
    }

    public function handle_license_activation() {
        check_ajax_referer( 'gardoonak_wizard_nonce', 'security' );
        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( $_POST['license_key'] ) : '';

        if ( $license_key === '123456789' ) {
            update_option( 'gardoonak_license_key', $license_key );
            update_option( 'gardoonak_license_status', 'active' );
            wp_send_json_success( [ 'message' => 'لایسنس با موفقیت ثبت و فعال شد.' ] );
        } else {
            wp_send_json_error( [ 'message' => 'لایسنس معتبر نیست.' ] );
        }
    }

    private function is_license_active() {
        return get_option( 'gardoonak_license_status' ) === 'active' && get_option( 'gardoonak_license_key' ) === '123456789';
    }

    public function render_general_settings_page() {
        ?>
        <div class="wrap gardoonak-admin-wrapper">
            <?php $this->render_admin_header( 'تنظیمات عمومی گردونک', 'پیکربندی پیشرفته و مدیریت بخش‌های مختلف افزونه.' ); ?>

            <form id="gardoonak-settings-form">
                <div class="gardoonak-dashboard-container">
                    
                    <div class="gardoonak-sidebar">
                        <ul class="gardoonak-tabs-nav">
                            <?php
                            $tabs = [
                                'base'        => 'پیکربندی پایه',
                                'main'        => 'پیکربندی اصلی',
                                'fields'      => 'فیلدهای ورودی',
                                'style'       => 'استایل',
                                'security'    => 'محدودیت و امنیت',
                                'integration' => 'یکپارچه‌سازی',
                                'email'       => 'ایمیل',
                                'sms'         => 'پیامک',
                            ];

                            $first = true;
                            foreach ( $tabs as $slug => $label ) :
                                $active_class = $first ? 'active' : '';
                                $icon_url = GARDOONAK_URL . "assets/images/SVG/tab-{$slug}.svg";
                                ?>
                                <li class="<?php echo $active_class; ?>" data-tab="tab-<?php echo $slug; ?>">
                                    <img src="<?php echo $icon_url; ?>" class="gn-tab-icon" alt="<?php echo $label; ?>">
                                    <?php echo $label; ?>
                                </li>
                                <?php
                                $first = false;
                            endforeach;
                            ?>
                        </ul>

                        <div class="gardoonak-sidebar-actions">
                            <button type="submit" class="gn-btn gn-btn-block">
                                <span class="btn-text">ذخیره کلیه تنظیمات</span>
                                <div class="gn-btn-icon"><span class="dashicons dashicons-saved"></span></div>
                            </button>
                        </div>
                    </div>

                    <div class="gardoonak-content">
                        <div id="tab-base" class="gardoonak-tab-pane active">
                            <?php 
                            $this->render_tab_content_header( 'base', 'پیکربندی پایه', 'تنظیمات زیرساختی، محل نمایش در صفحات و مدیریت وضعیت کلی افزونه در سایت.' );
                            ?>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-location-alt"></span> محل نمایش گردونه</label>
                                <p class="gn-desc">تعیین کنید گردونه در کدام صفحات به کاربر نشان داده شود.</p>
                                
                                <select name="display_location" class="gn-input" id="gn_display_location">
                                    <option value="all">در تمامی صفحات سایت</option>
                                    <option value="specific">فقط در صفحات خاص</option>
                                </select>

                                <div id="specific_pages_wrapper" style="display:none; margin-top:20px;">
                                    <div class="gn-page-selector-container">
                                        <label style="font-size: 13px; font-weight: 700; margin-bottom: 8px; display: block;">انتخاب صفحات از لیست:</label>
                                        <select id="gn_page_dropdown" class="gn-input">
                                            <option value="">یک صفحه را انتخاب کنید...</option>
                                            <?php
                                            $pages = get_pages();
                                            foreach ( $pages as $page ) {
                                                echo '<option value="' . esc_attr( $page->ID ) . '">' . esc_html( $page->post_title ) . '</option>';
                                            }
                                            ?>
                                        </select>
                                        <div id="gn_selected_pages_list" class="gn-selected-tags"></div>
                                        <input type="hidden" name="specific_pages_ids" id="gn_specific_pages_ids" value="">
                                    </div>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-external"></span> پاپ‌آپ اختصاصی گردونک</label>
                                <p class="gn-desc">تعیین کنید که آیا سیستم پاپ‌آپ هوشمند برای این کمپین فعال باشد یا خیر.</p>
                                <div class="gn-choice-container">
                                    <?php 
                                    $this->render_icon_choice_item('radio', 'enable_popup', '1', 'فعال باشد', 'dashicons-yes-alt', true);
                                    $this->render_icon_choice_item('radio', 'enable_popup', '0', 'غیرفعال', 'dashicons-dismiss');
                                    ?>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-performance"></span> بهینه‌سازی زمان نمایش</label>
                                <div class="gn-choice-container">
                                    <?php 
                                    $this->render_icon_choice_item('radio', 'display_delay', 'fast', 'سریع‌ترین زمان', 'dashicons-clock', true);
                                    $this->render_icon_choice_item('radio', 'display_delay', 'optimized', 'نمایش بهینه', 'dashicons-dashboard');
                                    ?>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-groups"></span> هدف‌گیری مخاطبان</label>
                                <div class="gn-choice-container">
                                    <?php 
                                    $this->render_icon_choice_item('radio', 'target_audience', 'all', 'همه کاربران', 'dashicons-groups', true);
                                    $this->render_icon_choice_item('radio', 'target_audience', 'guests', 'فقط مهمانان', 'dashicons-admin-users');
                                    $this->render_icon_choice_item('radio', 'target_audience', 'logged_in', 'فقط اعضا', 'dashicons-admin-network');
                                    ?>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-smartphone"></span> نمایش در دستگاه‌ها</label>
                                <div class="gn-choice-container">
                                    <?php 
                                    $this->render_icon_choice_item('checkbox', 'device_desktop', '1', 'دسکتاپ', 'dashicons-desktop', true);
                                    $this->render_icon_choice_item('checkbox', 'device_tablet', '1', 'تبلت', 'dashicons-tablet', true);
                                    $this->render_icon_choice_item('checkbox', 'device_mobile', '1', 'موبایل', 'dashicons-smartphone', true);
                                    ?>
                                </div>
                            </div>
                        </div>

                        <div id="tab-main" class="gardoonak-tab-pane">
                            <?php $this->render_tab_content_header( 'main', 'پیکربندی اصلی', 'مدیریت زمان‌بندی و مکانیسم‌های فنی چرخش.' ); ?>
                            <div class="gn-form-row">
                                <div style="display: flex; flex-direction: column; gap: 40px;">
                                    <div style="display: flex; align-items: center; justify-content: space-between;">
                                        <div style="flex: 1;">
                                            <h4 style="margin: 0;">نمایش هنگام قصد خروج (Exit Intent)</h4>
                                        </div>
                                        <div class="gn-choice-container">
                                            <?php 
                                            $this->render_icon_choice_item('radio', 'trigger_exit', '1', 'بله', 'dashicons-yes-alt', true);
                                            $this->render_icon_choice_item('radio', 'trigger_exit', '0', 'خیر', 'dashicons-dismiss');
                                            ?>
                                        </div>
                                    </div>

                                    <div style="display: flex; align-items: center; justify-content: space-between;">
                                        <div style="flex: 1;"><h4>نمایش بعد از حضور کاربر (ثانیه)</h4></div>
                                        <div style="display: flex; align-items: center; gap: 20px;">
                                            <input type="number" name="trigger_time_value" class="gn-input" style="width: 100px;">
                                            <div class="gn-choice-container">
                                                <?php 
                                                $this->render_icon_choice_item('radio', 'trigger_time', '1', 'فعال', 'dashicons-yes-alt');
                                                $this->render_icon_choice_item('radio', 'trigger_time', '0', 'غیرفعال', 'dashicons-dismiss', true);
                                                ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div style="display: flex; align-items: center; justify-content: space-between;">
                                        <div style="flex: 1;"><h4>نمایش بر اساس میزان اسکرول (%)</h4></div>
                                        <div style="display: flex; align-items: center; gap: 20px;">
                                            <input type="number" name="trigger_scroll_value" class="gn-input" style="width: 100px;">
                                            <div class="gn-choice-container">
                                                <?php 
                                                $this->render_icon_choice_item('radio', 'trigger_scroll', '1', 'فعال', 'dashicons-yes-alt');
                                                $this->render_icon_choice_item('radio', 'trigger_scroll', '0', 'غیرفعال', 'dashicons-dismiss', true);
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px;">
                                <div class="gn-form-row">
                                    <label class="gn-label">جلوگیری از اسپم (روز)</label>
                                    <input type="number" name="cookie_expiry" class="gn-input" value="7">
                                </div>
                                <div class="gn-form-row">
                                    <label class="gn-label">افکت انفجار شادی</label>
                                    <div class="gn-choice-container">
                                        <?php 
                                        $this->render_icon_choice_item('radio', 'effect_confetti', '1', 'فعال', 'dashicons-yes-alt', true);
                                        $this->render_icon_choice_item('radio', 'effect_confetti', '0', 'غیرفعال', 'dashicons-dismiss');
                                        ?>
                                    </div>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-format-audio"></span> تنظیمات صوتی</label>
                                
                                <div style="display: flex; gap: 40px; flex-wrap: wrap;">
                                    <div style="flex: 1; min-width: 250px;">
                                        <span style="display: block; margin-bottom: 12px; font-weight: 700; font-size: 13px; color: #555;">صدای چرخش گردونه:</span>
                                        <div class="gn-choice-container">
                                            <?php 
                                            // استفاده از آیکون‌های استاندارد جدید (تیک و ضربدر)
                                            $this->render_icon_choice_item('radio', 'sound_spin', '1', 'فعال', 'dashicons-yes-alt', true); 
                                            $this->render_icon_choice_item('radio', 'sound_spin', '0', 'غیرفعال', 'dashicons-dismiss'); 
                                            ?>
                                        </div>
                                    </div>

                                    <div style="flex: 1; min-width: 250px;">
                                        <span style="display: block; margin-bottom: 12px; font-weight: 700; font-size: 13px; color: #555;">صدای اعلام برنده:</span>
                                        <div class="gn-choice-container">
                                            <?php 
                                            $this->render_icon_choice_item('radio', 'sound_result', '1', 'فعال', 'dashicons-yes-alt', true); 
                                            $this->render_icon_choice_item('radio', 'sound_result', '0', 'غیرفعال', 'dashicons-dismiss'); 
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="tab-fields" class="gardoonak-tab-pane">
                            <?php $this->render_tab_content_header( 'fields', 'فیلدهای دریافت اطلاعات', 'مدیریت داده‌های دریافتی از کاربران.' ); ?>
                            <div class="gn-form-row">
                                <label class="gn-label">زمان دریافت اطلاعات</label>
                                <div class="gn-choice-container">
                                    <?php 
                                    $this->render_icon_choice_item('radio', 'data_collection_timing', 'before', 'قبل از بازی', 'dashicons-id', true);
                                    $this->render_icon_choice_item('radio', 'data_collection_timing', 'after', 'بعد از بازی', 'dashicons-awards');
                                    ?>
                                </div>
                            </div>
                            <div class="gn-form-row">
                                <label class="gn-label">فیلدهای مورد نیاز</label>
                                <div class="gn-choice-container">
                                    <?php 
                                    $this->render_icon_choice_item('checkbox', 'field_name_enable', '1', 'نام و نشان', 'dashicons-admin-users', true);
                                    $this->render_icon_choice_item('checkbox', 'field_email_enable', '1', 'ایمیل', 'dashicons-email-alt', true);
                                    $this->render_icon_choice_item('checkbox', 'field_phone_enable', '1', 'شماره موبایل', 'dashicons-smartphone', true);
                                    ?>
                                </div>
                            </div>
                        </div>

                        <div id="tab-style" class="gardoonak-tab-pane">
                            <?php $this->render_tab_content_header( 'style', 'شخصی‌سازی بصری', 'تنظیمات گرافیکی و تم‌های آماده.', 'dashicons-art' ); ?>

                            <div class="gn-form-row" style="padding: 40px;">
                                <label class="gn-label">انتخاب پالت رنگی (تم‌های آماده)</label>
                                <div class="gn-choice-container gn-theme-grid">
                                    <?php 
                                    $this->render_image_choice_item('radio', 'wheel_theme', '1', 'تم آبی', 'themes/1.webp', true);
                                    $this->render_image_choice_item('radio', 'wheel_theme', '2', 'تم قرمز', 'themes/2.webp');
                                    $this->render_image_choice_item('radio', 'wheel_theme', '3', 'تم زرد', 'themes/3.webp');
                                    $this->render_image_choice_item('radio', 'wheel_theme', '4', 'تم بنفش', 'themes/4.webp');
                                    $this->render_image_choice_item('radio', 'wheel_theme', '5', 'تم سبز', 'themes/5.webp');
                                    ?>
                                </div>
                            </div>

                            <div class="gn-form-row" style="padding: 40px;">
                                <label class="gn-label">طرح نشانگر (Pointer)</label>
                                    <div class="gn-choice-container gn-pointer-grid">
                                        <?php 
                                        $this->render_image_choice_item('radio', 'pointer_style', 'default', 'پیش‌فرض', 'SVG/pointers/pointer-default.svg', true);
                                        $this->render_image_choice_item('radio', 'pointer_style', 'hand', 'دست نشانگر', 'SVG/pointers/pointer-hand.svg');
                                        ?>
                                    </div>
                            </div>

                            <div class="gn-form-row" style="padding: 40px;">
                                <label class="gn-label">دکمه شناور فراخوان (Call to Action)</label>
                                <p class="gn-desc">تنظیمات ظاهری دکمه‌ای که در گوشه سایت برای باز کردن گردونه نمایش داده می‌شود.</p>
                                
                                <div class="gn-float-settings-container">
                                    
                                    <div class="gn-float-row">
                                        <span class="gn-sub-title">۱. رنگ دکمه را انتخاب کنید:</span>
                                        <div class="gn-modern-palette">
                                            <div class="gn-color-preset active" data-color="#7079f0" style="background: #7079f0;"></div>
                                            <div class="gn-color-preset" data-color="#ff4757" style="background: #ff4757;"></div>
                                            <div class="gn-color-preset" data-color="#2ecc71" style="background: #2ecc71;"></div>
                                            <div class="gn-color-preset" data-color="#f1c40f" style="background: #f1c40f;"></div>
                                            <div class="gn-color-preset" data-color="#34495e" style="background: #34495e;"></div>
                                            <div class="gn-color-preset" data-color="#e84393" style="background: #e84393;"></div>
                                            
                                            <input type="hidden" name="float_btn_color" id="float_btn_color" value="#7079f0">
                                        </div>
                                    </div>

                                    <div class="gn-divider-horizontal"></div>

                                    <div class="gn-float-row">
                                        <div class="gn-default-icon-preview">
                                            <img src="<?php echo GARDOONAK_URL . 'assets/images/SVG/float-default.svg'; ?>" alt="Default">
                                            <span class="gn-preview-label">پیش‌نمایش آیکون پیش‌فرض</span>
                                        </div>
                                        
                                        <div class="gn-default-icon-actions">
                                            <span class="gn-sub-title">آیا از آیکون پیش‌فرض استفاده شود؟</span>
                                            <div class="gn-choice-container">
                                                <?php 
                                                // مقدار 1 یعنی پیش‌فرض (تیک سبز)
                                                // مقدار 0 یعنی شخصی (ضربدر قرمز)
                                                $this->render_icon_choice_item('radio', 'use_default_icon', '1', 'بله، استفاده شود', 'dashicons-yes-alt', true);
                                                $this->render_icon_choice_item('radio', 'use_default_icon', '0', 'خیر، آپلود می‌کنم', 'dashicons-dismiss');
                                                ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="gn-float-row gn-upload-row" id="gn_custom_icon_row" style="display: none;">
                                        <div class="gn-upload-box-modern">
                                            <div class="gn-upload-info">
                                                <span class="dashicons dashicons-format-image"></span>
                                                <div>
                                                    <strong>آپلود آیکون اختصاصی</strong>
                                                    <p>لطفاً تصویر خود را ترجیحاً با ابعاد <strong>80x80 پیکسل</strong> و فرمت PNG یا SVG بارگذاری کنید.</p>
                                                </div>
                                            </div>
                                            
                                            <div class="gn-upload-actions">
                                                <input type="hidden" name="custom_float_icon" id="gn_custom_float_icon">
                                                <div class="gn-icon-preview-box" id="gn_float_icon_preview"></div>
                                                <button type="button" class="gn-btn-outline" id="gn_upload_float_icon">
                                                    <span class="dashicons dashicons-upload"></span>
                                                    انتخاب فایل
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab-security" class="gardoonak-tab-pane">
                            <?php 
                            $this->render_tab_content_header( 'security', 
                                'محدودیت و امنیت', 
                                'لایه‌های حفاظتی پیشرفته برای جلوگیری از تقلب و ثبت اطلاعات فیک.',
                                'dashicons-shield' 
                            ); 
                            ?>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-networking"></span> قفل IP هوشمند</label>
                                <p class="gn-desc">با فعال‌سازی این گزینه، سیستم اجازه نمی‌دهد یک کاربر با یک اینترنت (IP) مشخص، بیش از یک بار شانس خود را امتحان کند.</p>
                                <div class="gn-choice-container">
                                    <?php
                                    $this->render_icon_choice_item('radio', 'security_ip_lock', '1', 'فعال', 'dashicons-yes-alt', true);
                                    $this->render_icon_choice_item('radio', 'security_ip_lock', '0', 'غیرفعال', 'dashicons-dismiss');
                                    ?>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-google"></span> اتصال به Google reCAPTCHA v3</label>
                                <p class="gn-desc">سرویس ضد ربات گوگل که بدون آزار کاربر، ربات‌ها را شناسایی می‌کند.</p>
                                
                                <div class="gn-choice-container" style="margin-bottom: 25px;">
                                    <?php
                                    $this->render_icon_choice_item('radio', 'security_recaptcha', '1', 'فعال', 'dashicons-yes-alt');
                                    $this->render_icon_choice_item('radio', 'security_recaptcha', '0', 'غیرفعال', 'dashicons-dismiss', true);
                                    ?>
                                </div>

                                <div id="gn_recaptcha_fields" style="background: #f8f9fa; padding: 25px; border-radius: 16px; border: 1px dashed #d1d8e0; display: none;">
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                                        <div>
                                            <label style="display:block; margin-bottom:10px; font-weight:700; color:#555;">Site Key (کلید سایت):</label>
                                            <input type="text" name="recaptcha_site_key" class="gn-input" placeholder="مثال: 6Lc_..." style="direction: ltr; text-align: left;">
                                        </div>
                                        <div>
                                            <label style="display:block; margin-bottom:10px; font-weight:700; color:#555;">Secret Key (کلید محرمانه):</label>
                                            <input type="text" name="recaptcha_secret_key" class="gn-input" placeholder="مثال: 6Lc_..." style="direction: ltr; text-align: left;">
                                        </div>
                                    </div>
                                    <p style="margin: 15px 0 0 0; font-size: 12px; color: #888;">این کلیدها را باید از پنل گوگل ریکپچا دریافت کنید.</p>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-id"></span> جلوگیری از هویت تکراری</label>
                                <p class="gn-desc">اگر کاربری بخواهد با شماره موبایل یا ایمیلی که قبلاً برنده شده مجددا تلاش کند، مسدود می‌شود.</p>
                                
                                <div style="display: flex; gap: 60px; flex-wrap: wrap;">
                                    <div>
                                        <span style="display: block; margin-bottom: 12px; font-weight: 700; font-size: 13px; color: #555;">یکتایی شماره موبایل:</span>
                                        <div class="gn-choice-container">
                                            <?php
                                            $this->render_icon_choice_item('radio', 'unique_mobile', '1', 'فعال', 'dashicons-yes-alt', true);
                                            $this->render_icon_choice_item('radio', 'unique_mobile', '0', 'غیرفعال', 'dashicons-dismiss');
                                            ?>
                                        </div>
                                    </div>
                                    <div>
                                        <span style="display: block; margin-bottom: 12px; font-weight: 700; font-size: 13px; color: #555;">یکتایی ایمیل:</span>
                                        <div class="gn-choice-container">
                                            <?php
                                            $this->render_icon_choice_item('radio', 'unique_email', '1', 'فعال', 'dashicons-yes-alt', true);
                                            $this->render_icon_choice_item('radio', 'unique_email', '0', 'غیرفعال', 'dashicons-dismiss');
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-email-alt"></span> مسدودسازی ایمیل‌های موقت</label>
                                <p class="gn-desc">تشخیص و مسدود کردن دامنه‌های سرویس‌دهنده ایمیل موقت (مثل temp-mail) برای جلوگیری از اسپم.</p>
                                <div class="gn-choice-container">
                                    <?php
                                    $this->render_icon_choice_item('radio', 'block_fake_mails', '1', 'فعال', 'dashicons-yes-alt', true);
                                    $this->render_icon_choice_item('radio', 'block_fake_mails', '0', 'غیرفعال', 'dashicons-dismiss');
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div id="tab-email" class="gardoonak-tab-pane">
                            <?php 
                            $this->render_tab_content_header( 'email', 
                                'تنظیمات ارسال ایمیل', 
                                'مدیریت ایمیل‌هایی که پس از برنده شدن کاربر برای او ارسال می‌شود.',
                                'dashicons-email-alt' 
                            ); 
                            ?>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-paperplane"></span> ارسال ایمیل به برنده</label>
                                <p class="gn-desc">آیا می‌خواهید پس از اینکه کاربر جایزه‌ای برد، جزئیات آن برایش ایمیل شود؟</p>
                                
                                <div class="gn-choice-container">
                                    <?php
                                    $this->render_icon_choice_item('radio', 'enable_winner_email', '1', 'بله، ارسال شود', 'dashicons-yes-alt');
                                    $this->render_icon_choice_item('radio', 'enable_winner_email', '0', 'خیر', 'dashicons-dismiss', true);
                                    ?>
                                </div>
                            </div>

                            <div id="gn_email_settings_wrapper" style="display: none;">
                                
                                <div class="gn-form-row">
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                                        
                                        <div>
                                            <label class="gn-label">نام فرستنده ایمیل</label>
                                            <input type="text" name="email_sender_name" class="gn-input" placeholder="مثال: تیم پشتیبانی گردونک" value="<?php echo esc_attr( get_option('blogname') ); ?>">
                                        </div>

                                        <div>
                                            <label class="gn-label">ایمیل فرستنده</label>
                                            <input type="email" name="email_sender_address" class="gn-input" placeholder="noreply@yoursite.com" style="direction: ltr; text-align: left;">
                                        </div>
                                    </div>

                                    <div class="gn-notice-box gn-notice-warning" style="margin-top: 20px; display: flex; align-items: center; gap: 15px; background: #fffdf5; border: 1px solid #f1c40f; padding: 15px; border-radius: 12px;">
                                        <span class="dashicons dashicons-warning" style="color: #f1c40f; font-size: 24px;"></span>
                                        <p style="margin: 0; font-size: 13px; color: #555;">
                                            <strong>نکته مهم:</strong> برای جلوگیری از اسپم شدن ایمیل‌ها، حتماً از ایمیلی استفاده کنید که متعلق به دامین همین سایت باشد (مثلاً info@<?php echo $_SERVER['SERVER_NAME']; ?>). استفاده از Gmail یا Yahoo باعث مسدود شدن ایمیل‌ها می‌شود.
                                        </p>
                                    </div>
                                </div>

                                <div class="gn-form-row">
                                    <label class="gn-label">3. موضوع ایمیل</label>
                                    <input type="text" name="email_subject" class="gn-input" placeholder="مثال: تبریک! شما برنده شدید..." style="margin-bottom: 25px;">

                                    <label class="gn-label">4. متن و محتوای ایمیل</label>
                                    <div class="gn-editor-wrapper" style="border: 2px solid #e1e1e1; border-radius: 12px; overflow: hidden;">
                                        <?php 
                                        // فراخوانی ادیتور استاندارد وردپرس
                                        $content = 'سلام {user_name} عزیز،<br>تبریک! شما در گردونه شانس برنده جایزه <strong>{prize_name}</strong> شدید.<br>کد تخفیف شما: {coupon_code}';
                                        wp_editor( $content, 'gardoonak_email_body', [
                                            'textarea_name' => 'email_body',
                                            'media_buttons' => true, // اجازه آپلود عکس
                                            'textarea_rows' => 10,
                                            'teeny'         => false,
                                            'quicktags'     => true
                                        ] ); 
                                        ?>
                                    </div>

                                    <div style="margin-top: 20px; background: #f8f9fa; padding: 20px; border-radius: 12px; border: 1px dashed #d1d8e0;">
                                        <label style="font-weight: 700; display: block; margin-bottom: 10px; color: #555;">پارامترهای قابل استفاده (برای شخصی‌سازی روی آن‌ها کلیک کنید تا کپی شوند):</label>
                                        <div class="gn-shortcode-list" style="display: flex; gap: 10px; flex-wrap: wrap;">
                                            <code class="gn-tag" style="cursor: pointer;" title="کپی شد!">{user_name}</code> <span style="font-size: 12px; color: #888;">(نام کاربر)</span>
                                            <code class="gn-tag" style="cursor: pointer;" title="کپی شد!">{prize_name}</code> <span style="font-size: 12px; color: #888;">(نام جایزه)</span>
                                            <code class="gn-tag" style="cursor: pointer;" title="کپی شد!">{coupon_code}</code> <span style="font-size: 12px; color: #888;">(کد تخفیف)</span>
                                            <code class="gn-tag" style="cursor: pointer;" title="کپی شد!">{site_name}</code> <span style="font-size: 12px; color: #888;">(نام سایت)</span>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div id="tab-sms" class="gardoonak-tab-pane">
                            <?php 
                            $this->render_tab_content_header( 'sms', 
                                'تنظیمات پیامک (SMS)', 
                                'اتصال به پنل‌های پیامکی جهت ارسال کد برنده به موبایل کاربر.',
                                'dashicons-smartphone' 
                            ); 
                            ?>

                            <div class="gn-form-row">
                                <label class="gn-label"><span class="dashicons dashicons-email-alt"></span> ارسال پیامک به برنده</label>
                                <p class="gn-desc">آیا می‌خواهید پس از برنده شدن، کد تخفیف یا جایزه برای کاربر پیامک شود؟</p>
                                
                                <div class="gn-choice-container">
                                    <?php
                                    $this->render_icon_choice_item('radio', 'enable_sms', '1', 'بله، ارسال شود', 'dashicons-yes-alt');
                                    $this->render_icon_choice_item('radio', 'enable_sms', '0', 'خیر', 'dashicons-dismiss', true);
                                    ?>
                                </div>
                            </div>

                            <div id="gn_sms_settings_wrapper" style="display: none;">
                                
                                <div class="gn-form-row">
                                    <label class="gn-label">اطلاعات اتصال به پنل</label>
                                    
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px; margin-bottom: 20px;">
                                        <div style="grid-column: span 2;">
                                            <label class="gn-sub-label">سرویس دهنده پیامک:</label>
                                            <select name="sms_provider" class="gn-input">
                                                <option value="ippanel">IPPanel (فراز اس‌ام‌اس، مکث و...)</option>
                                                <option value="melipayamak">ملی پیامک (MeliPayamak)</option>
                                                <option value="kavehnegar">کاوه نگار (KavehNegar)</option>
                                                <option value="smsir">SMS.ir (جدید)</option>
                                                <option value="farazsms">فراز اس‌ام‌اس (FarazSMS)</option>
                                            </select>
                                        </div>

                                        <div>
                                            <label class="gn-sub-label">نام کاربری (Username):</label>
                                            <input type="text" name="sms_username" class="gn-input" style="direction: ltr; text-align: left;">
                                        </div>

                                        <div>
                                            <label class="gn-sub-label">رمز عبور / API Key:</label>
                                            <input type="password" name="sms_password" class="gn-input" style="direction: ltr; text-align: left;">
                                        </div>

                                        <div style="grid-column: span 2;">
                                            <label class="gn-sub-label">شماره فرستنده (Sender Number):</label>
                                            <input type="text" name="sms_sender" class="gn-input" placeholder="مثال: 3000505..." style="direction: ltr; text-align: left;">
                                            <p style="font-size: 11px; color: #999; margin-top: 5px;">برای ارسال پترن در برخی پنل‌ها این فیلد اختیاری است.</p>
                                        </div>
                                    </div>

                                    <div class="gn-sms-status-card" style="background: #eef2f7; border-radius: 12px; padding: 20px; display: flex; align-items: center; justify-content: space-between; border: 1px solid #dce4ec;">
                                        <div style="display: flex; gap: 20px; align-items: center;">
                                            <div style="width: 50px; height: 50px; background: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
                                                <span class="dashicons dashicons-cloud" style="font-size: 24px; color: #7079f0;"></span>
                                            </div>
                                            <div>
                                                <div style="font-weight: 800; color: #333; font-size: 15px;">وضعیت پنل پیامک</div>
                                                <div style="font-size: 13px; color: #666; display: flex; gap: 15px; margin-top: 5px;">
                                                    <span id="gn_sms_connection_status"><span class="dashicons dashicons-no-alt" style="color: #e74c3c; font-size: 16px; vertical-align: middle;"></span> عدم اتصال</span>
                                                    <span style="color: #ddd;">|</span>
                                                    <span>موجودی: <strong id="gn_sms_balance">0</strong> ریال</span>
                                                </div>
                                            </div>
                                        </div>
                                        <button type="button" class="gn-btn-outline" id="gn_test_sms_connection">
                                            <span class="dashicons dashicons-update"></span>
                                            بررسی اتصال
                                        </button>
                                    </div>
                                </div>

                                <div class="gn-form-row">
                                    <label class="gn-label"><span class="dashicons dashicons-edit"></span> شیوه و متن ارسال</label>
                                    <p class="gn-desc">پترن (الگو) سرعت بالایی دارد و حتی به لیست سیاه ارسال می‌شود. پیام عادی ممکن است دیرتر برسد.</p>
                                    
                                    <div class="gn-choice-container" style="margin-bottom: 25px;">
                                        <?php
                                        // مقدار pattern یعنی ارسال پترن
                                        // مقدار normal یعنی ارسال معمولی
                                        $this->render_icon_choice_item('radio', 'sms_send_method', 'pattern', 'ارسال با پترن (پیشنهادی)', 'dashicons-grid-view', true);
                                        $this->render_icon_choice_item('radio', 'sms_send_method', 'normal', 'ارسال پیامک عادی', 'dashicons-text');
                                        ?>
                                    </div>

                                    <div id="gn_sms_pattern_box">
                                        <label class="gn-sub-label">کد پترن (Pattern Code):</label>
                                        <input type="text" name="sms_pattern_code" class="gn-input" placeholder="مثال: 34589" style="width: 200px; text-align: center; direction: ltr; margin-bottom: 15px;">
                                        
                                        <div class="gn-notice-box gn-notice-warning" style="background: #fffdf5; border: 1px solid #f1c40f; padding: 15px; border-radius: 12px;">
                                            <span style="font-weight: 700; color: #d35400; display: block; margin-bottom: 8px;">راهنمای متغیرهای پترن:</span>
                                            <p style="margin: 0; font-size: 13px; color: #555; line-height: 1.8;">
                                                در پنل پیامکی خود، متغیرها را با نام‌های زیر تنظیم کنید تا مقادیر به درستی جایگذاری شوند:<br>
                                                <code class="gn-tag">{code}</code> : برای کد تخفیف<br>
                                                <code class="gn-tag">{name}</code> : برای نام کاربر<br>
                                                <code class="gn-tag">{prize}</code> : برای نام جایزه
                                            </p>
                                        </div>
                                    </div>

                                    <div id="gn_sms_normal_box" style="display: none;">
                                        <label class="gn-sub-label">متن پیامک:</label>
                                        <textarea name="sms_body_normal" class="gn-input" rows="4" placeholder="متن پیامک خود را اینجا بنویسید..." style="margin-bottom: 15px;"></textarea>
                                        
                                        <div class="gn-notice-box gn-notice-warning" style="background: #fffdf5; border: 1px solid #f1c40f; padding: 15px; border-radius: 12px;">
                                            <span style="font-weight: 700; color: #d35400; display: block; margin-bottom: 8px;">شورت‌کدهای هوشمند:</span>
                                            <p style="margin: 0; font-size: 13px; color: #555; line-height: 1.8;">
                                                برای شخصی‌سازی پیامک، روی کدهای زیر کلیک کنید تا کپی شوند:<br>
                                                <code class="gn-tag" style="cursor: pointer;">{user_name}</code> : نام کاربر<br>
                                                <code class="gn-tag" style="cursor: pointer;">{prize_name}</code> : نام جایزه<br>
                                                <code class="gn-tag" style="cursor: pointer;">{coupon_code}</code> : کد تخفیف اختصاصی
                                            </p>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <?php
    }

    /**
     * رندر کردن آیتم‌های انتخابی که فقط آیکون دارند (Small Tiles)
     */
    private function render_icon_choice_item( $type, $name, $value, $label, $icon_class, $checked = false ) {
        $is_checked = $checked ? 'checked' : '';
        
        // تشخیص نوع دکمه برای رنگ‌بندی (سبز/قرمز)
        $color_class = '';
        if ( in_array( $icon_class, ['dashicons-yes', 'dashicons-yes-alt', 'dashicons-saved'] ) ) {
            $color_class = 'gn-choice-positive';
        } elseif ( in_array( $icon_class, ['dashicons-no', 'dashicons-no-alt', 'dashicons-dismiss'] ) ) {
            $color_class = 'gn-choice-negative';
        }

        ?>
        <label class="gn-choice-item">
            <input type="<?php echo esc_attr( $type ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" class="gn-choice-input" <?php echo $is_checked; ?>>
            <div class="gn-choice-tile-small <?php echo esc_attr( $color_class ); ?>">
                <div class="gn-choice-icon">
                    <span class="dashicons <?php echo esc_attr( $icon_class ); ?>"></span>
                </div>
                <span class="gn-choice-label"><?php echo esc_html( $label ); ?></span>
            </div>
        </label>
        <?php
    }

    /**
     * رندر کردن کارت‌های تصویری (Hero Cards)
     */
    private function render_image_choice_item( $type, $name, $value, $label, $image_path, $checked = false ) {
        $is_checked = $checked ? 'checked' : '';
        $image_url = GARDOONAK_URL . 'assets/images/' . $image_path;
        ?>
        <label class="gn-image-card">
            <input type="<?php echo esc_attr( $type ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" class="gn-choice-input" <?php echo $is_checked; ?>>
            <div class="gn-choice-tile">
                <div class="gn-check-badge"><span class="dashicons dashicons-yes"></span></div>
                <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $label ); ?>" class="gn-choice-img">
                <div class="gn-choice-content">
                    <span class="gn-choice-label"><?php echo esc_html( $label ); ?></span>
                </div>
            </div>
        </label>
        <?php
    }

    /** ------------------- **/
    /** زیرمنوی گردونه ها **/
    /** ------------------ **/

    public function render_wheels_management_page() {
        ?>
        <div class="wrap gardoonak-admin-wrapper">
            
            <?php 
            $header_actions = '
                <input type="hidden" id="gn_wheel_id_input" value="1">
                <input type="hidden" id="gn_wheel_title_input" value="گردونه شانس اصلی">';

            $this->render_admin_header( 
                'مدیریت و پیکربندی گردونه', 
                'در این بخش می‌توانید تنها گردونه سیستم را مدیریت کنید. تغییرات وضعیت بلافاصله در سایت اعمال می‌شود.',
                'dashicons-admin-generic', 
                $header_actions 
            ); 
            ?>

            <div class="gn-action-toolbar">
                <div class="gn-toolbar-actions">
                    <button type="button" id="gn_save_wheel_btn" class="gn-btn gn-btn-primary">
                        <span class="dashicons dashicons-saved"></span> ذخیره تغییرات
                    </button>
                </div>
                
                <div class="gn-toolbar-status">
                    <span class="gn-status-text">وضعیت نمایش گردونه در سایت:</span>
                    <div class="gn-status-toggle">
                        <button type="button" class="gn-status-btn active" data-status="active">فعال</button>
                        <button type="button" class="gn-status-btn" data-status="inactive">غیرفعال</button>
                    </div>
                    <input type="hidden" id="gn_wheel_status_input" value="active">
                </div>
            </div>

            <div class="gn-builder-container" id="gn_builder_main_area">
                
                <div class="gn-builder-sidebar">
                    <div class="gn-form-row">
                        <div class="gn-label">
                            <span class="dashicons dashicons-admin-settings"></span> تنظیمات پایه کمپین
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-top: 20px;">
                            <div>
                                <label class="gn-label-xs">نام کمپین</label>
                                <input type="text" id="gn_campaign_name" class="gn-input" placeholder="نام کمپین">
                            </div>
                            <div>
                                <label class="gn-label-xs">تعداد دورهای چرخش</label>
                                <input type="number" id="wheel_spin_count" class="gn-input" value="8">
                            </div>
                            <div>
                                <label class="gn-label-xs">مدت زمان چرخش (ثانیه)</label>
                                <input type="number" id="wheel_spin_duration" class="gn-input" value="5">
                            </div>
                        </div>
                    </div>

                    <div class="gn-builder-section">
                        <div class="gn-form-row gn-section-header">
                            <h3 class="gn-label gn-section-title"><span class="dashicons dashicons-chart-pie"></span> پیکربندی پره‌ها</h3>
                            <button type="button" class="gn-btn gn-btn-outline gn-btn-xs" id="gn_add_slice_btn">
                                <span class="dashicons dashicons-plus"></span> افزودن شانس جدید
                            </button>
                        </div>
                        <div id="gn_slices_container"></div>
                    </div>
                </div>

                <div class="gn-builder-preview-area">
                    <div class="gn-preview-stage">
                        
                        <div class="gn-wheel-clip">
                            <div id="gn_live_wheel" class="gn-live-wheel"></div>
                        </div>

                        <div class="gn-wheel-pointer"></div>

                        <button type="button" class="gn-btn gn-btn-spin-test" id="gn_test_spin">
                            تست فیزیک چرخش
                        </button>

                    </div>
                </div>

            </div>
        </div>
        <template id="gn_slice_template">
        <div class="gn-slice-item">
            <div class="gn-slice-header modern-minimal">
                <div class="gn-header-right">
                    <span class="gn-slice-toggle-icon dashicons dashicons-arrow-down-alt2"></span>
                </div>

                <div class="gn-header-center">
                    <span class="gn-slice-title-display">آیتم جدید</span>
                </div>

                <div class="gn-header-left">
                    <span class="gn-slice-remove dashicons dashicons-trash" title="حذف اسلایس"></span>
                </div>
            </div>

            <div class="gn-slice-body">
                
                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-bottom: 20px;">
                    <div>
                        <label class="gn-label-xs">عنوان آیتم (نمایش روی گردونه)</label>
                        <input type="text" class="gn-input slice-label" placeholder="مثلاً: ۲۰٪ تخفیف">
                    </div>
                    <div>
                        <label class="gn-label-xs">شانس برد (٪)</label>
                        <input type="number" class="gn-input slice-chance" value="10" min="0" max="100">
                    </div>
                </div>

                <div style="margin-bottom: 20px;">
                    <label class="gn-label-xs">ظاهر پره روی گردونه</label>
                    <div class="gn-choice-container">
                        <label class="gn-choice-item">
                            <input type="radio" name="slice_visual_{INDEX}" value="color" class="gn-choice-input slice-visual-type" checked="">
                            <div class="gn-choice-tile-small">پالت رنگ</div>
                        </label>
                        <label class="gn-choice-item">
                            <input type="radio" name="slice_visual_{INDEX}" value="image" class="gn-choice-input slice-visual-type">
                            <div class="gn-choice-tile-small">تصویر/آیکون</div>
                        </label>
                    </div>
                </div>

                <div class="gn-visual-color-area" style="margin-bottom: 20px;">
                    <label class="gn-label-xs">انتخاب رنگ سریع</label>
                    <div class="gn-color-selector-box" style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <div class="gn-color-circle" data-color="#ff4757" style="background:#ff4757;"></div>
                        <div class="gn-color-circle" data-color="#2ecc71" style="background:#2ecc71;"></div>
                        <div class="gn-color-circle" data-color="#3498db" style="background:#3498db;"></div>
                        <div class="gn-color-circle" data-color="#f1c40f" style="background:#f1c40f;"></div>
                        <div class="gn-color-circle" data-color="#9b59b6" style="background:#9b59b6;"></div>
                        <input type="hidden" class="slice-color" value="#ff4757">
                    </div>
                </div>

                <div class="gn-visual-image-area" style="display:none; margin-bottom: 20px;">
                    <label class="gn-label-xs">آپلود تصویر اختصاصی</label>
                    <div class="gn-upload-wrapper" style="display: flex; align-items: center; gap: 15px; background: #f8fafc; padding: 10px; border-radius: 12px; border: 1px dashed #cbd5e1;">
                        <div class="slice-img-preview" style="width:50px; height:50px; border-radius:8px; background-color:#fff; border:1px solid #e2e8f0; background-size:contain; background-repeat:no-repeat; background-position:center; display:flex; align-items:center; justify-content:center;">
                            <span class="dashicons dashicons-format-image" style="color:#cbd5e1;"></span>
                        </div>
                        <div style="flex:1;">
                            <input type="hidden" class="slice-img-url">
                            <button type="button" class="gn-btn gn-btn-outline gn-btn-xs gn-upload-btn">انتخاب از رسانه</button>
                        </div>
                    </div>
                </div>

                <div style="margin-bottom: 20px;">
                    <label class="gn-label-xs">نتیجه قرعه‌کشی این آیتم</label>
                    <div class="gn-choice-container">
                        <label class="gn-choice-item">
                            <input type="radio" name="slice_type_{INDEX}" value="win" class="gn-choice-input slice-type" checked>
                            <div class="gn-choice-tile-small gn-choice-positive">برنده</div>
                        </label>
                        <label class="gn-choice-item">
                            <input type="radio" name="slice_type_{INDEX}" value="loss" class="gn-choice-input slice-type">
                            <div class="gn-choice-tile-small gn-choice-negative">بازنده (پوچ)</div>
                        </label>
                    </div>
                </div>

                <div class="gn-win-options-area" style="background:#f0f9ff; padding:20px; border-radius:15px; border:1px solid #bae6fd;">
                    <div style="margin-bottom: 15px;">
                        <label class="gn-label-xs">نوع جایزه</label>
                        <select class="gn-input slice-action-type">
                            <option value="coupon">ارائه کد تخفیف</option>
                            <option value="link">هدایت به لینک (URL)</option>
                        </select>
                    </div>
                    
                    <div class="gn-action-coupon-box">
                        <label class="gn-label-xs">کد تخفیف</label>
                        <input type="text" class="gn-input slice-coupon-val" placeholder="مثلاً: OFF2024">
                    </div>

                    <div class="gn-action-link-box" style="display:none;">
                        <label class="gn-label-xs">لینک مقصد</label>
                        <input type="url" class="gn-input slice-link-val" placeholder="https://site.com/prize" style="direction:ltr;">
                    </div>
                </div>

                <div class="gn-loss-options-area" style="display:none; background:#fff1f2; padding:15px; border-radius:12px; border:1px solid #fecdd3; text-align:center;">
                    <p style="color:#e11d48; font-size:12px; margin:0;">پیام تاسف: متأسفانه در این دور برنده نشدید!</p>
                </div>

            </div>
        </div>
    </template>
        <?php
    }

    /**
     * نمایش صفحه زیرمنوی آمار و داده‌ها
     */
    public function render_analytics_page() {
        ?>
        <div class="wrap gardoonak-admin-wrapper">
            
            <?php 
            // فراخوانی هدر استاندارد بدون بخش اکشن (دکمه)
            $this->render_admin_header( 
                'آمار و گزارشات', 
                'مشاهده لحظه‌ای وضعیت گردونه، آمار برندگان و مدیریت داده‌های ثبت شده.',
                'dashicons-chart-bar' // استفاده از آیکون مرتبط با نمودار و آمار
            ); 
            ?>

            <div class="gn-stats-grid">
                <div class="gn-stat-card">
                    <div class="gn-stat-icon" style="background: rgba(112, 121, 240, 0.1); color: #7079f0;">
                        <span class="dashicons dashicons-update"></span>
                    </div>
                    <div class="gn-stat-info">
                        <span class="gn-stat-value">1,254</span>
                        <span class="gn-stat-label">تعداد کل چرخش‌ها</span>
                    </div>
                </div>

                <div class="gn-stat-card">
                    <div class="gn-stat-icon" style="background: rgba(46, 204, 113, 0.1); color: #2ecc71;">
                        <span class="dashicons dashicons-awards"></span>
                    </div>
                    <div class="gn-stat-info">
                        <span class="gn-stat-value">320</span>
                        <span class="gn-stat-label">جوایز اهدا شده</span>
                    </div>
                </div>

                <div class="gn-stat-card">
                    <div class="gn-stat-icon" style="background: rgba(241, 196, 15, 0.1); color: #f1c40f;">
                        <span class="dashicons dashicons-tickets-alt"></span>
                    </div>
                    <div class="gn-stat-info">
                        <span class="gn-stat-value">85</span>
                        <span class="gn-stat-label">کدهای استفاده شده</span>
                    </div>
                </div>

                <div class="gn-stat-card">
                    <div class="gn-stat-icon" style="background: rgba(231, 76, 60, 0.1); color: #e74c3c;">
                        <span class="dashicons dashicons-chart-pie"></span>
                    </div>
                    <div class="gn-stat-info">
                        <span class="gn-stat-value">12%</span>
                        <span class="gn-stat-label">نرخ تبدیل (Conversion)</span>
                    </div>
                </div>
            </div>

            <div class="gn-action-bar">
                <div class="gn-search-wrapper">
                    <span class="dashicons dashicons-search"></span>
                    <input type="text" placeholder="جستجو در نام، موبایل یا کد..." class="gn-search-input">
                </div>

                <div class="gn-export-actions">
                    <button type="button" class="gn-btn-export excel">
                        <span class="dashicons dashicons-media-spreadsheet"></span> خروجی Excel
                    </button>
                    <button type="button" class="gn-btn-export pdf">
                        <span class="dashicons dashicons-pdf"></span> خروجی PDF
                    </button>
                </div>
            </div>

            <div class="gn-data-list-container">
                
                <div class="gn-data-header">
                    <div class="col-user">کاربر / شرکت کننده</div>
                    <div class="col-prize">جایزه دریافتی</div>
                    <div class="col-code">کد شانس / تخفیف</div>
                    <div class="col-status">وضعیت</div>
                    <div class="col-date">تاریخ</div>
                </div>

                <div class="gn-data-row">
                    <div class="col-user">
                        <span class="user-name">علی محمدی</span>
                        <span class="user-phone">09123456789</span>
                    </div>
                    <div class="col-prize">
                        <span class="gn-prize-badge">20% تخفیف طلایی</span>
                    </div>
                    <div class="col-code">
                        <code class="gn-code-box">GOLD-2026</code>
                    </div>
                    <div class="col-status">
                        <span class="gn-status-pill success"><span class="dashicons dashicons-yes"></span> برنده</span>
                    </div>
                    <div class="col-date">2 دقیقه پیش</div>
                </div>

                <div class="gn-data-row">
                    <div class="col-user">
                        <span class="user-name">کاربر مهمان</span>
                        <span class="user-phone">09350001122</span>
                    </div>
                    <div class="col-prize">
                        <span class="gn-prize-badge empty">پوچ</span>
                    </div>
                    <div class="col-code">---</div>
                    <div class="col-status">
                        <span class="gn-status-pill failed"><span class="dashicons dashicons-no"></span> ناموفق</span>
                    </div>
                    <div class="col-date">15 دقیقه پیش</div>
                </div>

                <div class="gn-data-row">
                    <div class="col-user">
                        <span class="user-name">سارا امیری</span>
                        <span class="user-phone">09181234567</span>
                    </div>
                    <div class="col-prize">
                        <span class="gn-prize-badge">هدفون بی‌سیم</span>
                    </div>
                    <div class="col-code">
                        <code class="gn-code-box">HEAD-55</code>
                    </div>
                    <div class="col-status">
                        <span class="gn-status-pill success"><span class="dashicons dashicons-yes"></span> برنده</span>
                    </div>
                    <div class="col-date">1 ساعت پیش</div>
                </div>

            </div>
            
            <div class="gn-pagination">
                <span class="page-numbers current">1</span>
                <a class="page-numbers" href="#">2</a>
                <a class="page-numbers" href="#">3</a>
                <span class="page-numbers dots">…</span>
                <a class="page-numbers" href="#">12</a>
            </div>

        </div>
        <?php
    }

    public function render_activation_wizard() {
        ?>
        <div class="gardoonak-wizard-wrapper">
            <div class="gardoonak-wizard-card">
                <div class="wizard-icon-container" id="wizard-icon-box">
                    <img src="<?php echo GARDOONAK_URL . 'assets/images/SVG/wizard-key.svg'; ?>" alt="License Key">
                </div>
                <h1 class="wizard-title">لایسنس گردونک رو وارد کن</h1>
                <p class="wizard-desc">برای استفاده کامل از افزونه لازمه که لایسنس قانونی رو در باکس زیر وارد کنی.</p>
                <div class="wizard-form">
                    <input type="text" id="license_key_input" class="gn-input" autocomplete="off">
                    <button id="btn-activate-wizard" class="gn-btn">
                        <span>بررسی کد</span>
                        <div class="gn-btn-icon"><span class="dashicons dashicons-arrow-left-alt"></span></div>
                    </button>
                </div>
                <div id="wizard-message" class="wizard-alert"></div>
                <div class="wizard-footer">
                    <a href="https://zhaket.com" target="_blank">خرید لایسنس اورجینال</a> | <a href="<?php echo admin_url(); ?>">بازگشت به پیشخوان</a>
                </div>
            </div>
        </div>
        <?php
    }

    private function render_admin_header( $title, $description, $icon = 'dashicons-superhero', $actions_html = '' ) {
    ?>
    <div class="gardoonak-header-card">
        <div class="gardoonak-header-icon-box">
            <span class="dashicons <?php echo esc_attr( $icon ); ?>"></span>
        </div>
        <div class="gardoonak-header-text">
            <h1><?php echo esc_html( $title ); ?></h1>
            <p><?php echo esc_html( $description ); ?></p>
        </div>
        <?php if ( ! empty( $actions_html ) ) : ?>
            <div class="gardoonak-header-actions">
                <?php echo $actions_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

    private function render_tab_content_header( $slug, $title, $description ) {
        $icon_url = GARDOONAK_URL . "assets/images/SVG/tab-{$slug}.svg"; 
        ?>
        <div class="gn-content-header">
            <div class="gn-content-header-icon">
                <img src="<?php echo esc_url( $icon_url ); ?>" alt="<?php echo esc_attr( $title ); ?>" style="width: 32px; height: 32px;">
            </div>
            <div class="gn-content-header-info">
                <h2><?php echo esc_html( $title ); ?></h2>
                <p><?php echo esc_html( $description ); ?></p>
            </div>
        </div>
        <?php
    }

    private function render_notice( $type = 'warning', $title = '', $message = '' ) {
        $icon = ( $type === 'critical' ) ? 'dashicons-info' : 'dashicons-warning';
        $class = ( $type === 'critical' ) ? 'gn-notice-critical' : 'gn-notice-warning';
        ?>
        <div class="gn-notice-box <?php echo esc_attr( $class ); ?>">
            <div class="gn-notice-icon"><span class="dashicons <?php echo esc_attr( $icon ); ?>"></span></div>
            <div class="gn-notice-content">
                <strong class="gn-notice-title"><?php echo esc_html( $title ); ?></strong>
                <p class="gn-notice-desc"><?php echo wp_kses( $message, ['code' => [], 'strong' => [], 'b' => []] ); ?></p>
            </div>
        </div>
        <?php
    }

    /**
     * صفحه مدیریت و ساخت گردونه (Builder)
     */
    
}