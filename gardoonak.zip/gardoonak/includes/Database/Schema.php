<?php
namespace Gardoonak\Database;

defined( 'ABSPATH' ) || exit;

class Schema {

    /**
     * اجرای عملیات ساخت جداول
     */
    public static function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        // 1. جدول کمپین‌ها (تنظیمات هر گردونه)
        // در ستون config تمام تنظیمات ظاهری (رنگ‌ها، اسلایس‌ها، احتمالات) به صورت JSON ذخیره می‌شود.
        // این کار باعث می‌شود اگر فردا فیلد جدیدی اضافه کردیم، نیاز به تغییر ساختار دیتابیس نباشد.
        $table_campaigns = $wpdb->prefix . 'gardoonak_campaigns';
        $sql_campaigns = "CREATE TABLE $table_campaigns (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            status varchar(20) DEFAULT 'draft',
            config longtext NOT NULL, 
            triggers longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // 2. جدول لاگ‌ها (تاریخچه چرخش و برندگان)
        // ما روی user_identifier و ip_address ایندکس می‌گذاریم تا جستجو برای تقلب سریع باشد.
        $table_logs = $wpdb->prefix . 'gardoonak_logs';
        $sql_logs = "CREATE TABLE $table_logs (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            campaign_id bigint(20) NOT NULL,
            user_id bigint(20) DEFAULT 0,
            user_identifier varchar(100) NOT NULL, 
            prize_index int(5) NOT NULL,
            prize_code varchar(255) DEFAULT NULL,
            ip_address varchar(100) NOT NULL,
            user_agent text NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY campaign_id (campaign_id),
            KEY user_identifier (user_identifier),
            KEY ip_address (ip_address)
        ) $charset_collate;";

        // استفاده از تابع dbDelta وردپرس برای ساخت امن و استاندارد جداول
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql_campaigns );
        dbDelta( $sql_logs );
        
        // ذخیره نسخه دیتابیس برای آپدیت‌های بعدی
        update_option( 'gardoonak_db_version', '1.0.0' );
    }
}