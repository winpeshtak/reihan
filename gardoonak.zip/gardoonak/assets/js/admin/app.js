/* assets/js/admin/app.js */

(function ($) {
    'use strict';

    const GardoonakAdmin = {
        selectedPageIds: new Set(),

        init: function () {
            this.handleTabs();
            this.handleSettingsForm();
            this.handleTriggers();
            this.handleColorPicker();
            this.handleMediaUpload();
            this.handlePageSelection();
            this.initUiElements();
        },

        /**
         * مدیریت جابجایی بین تب‌ها
         */
        handleTabs: function () {
            const $tabItems = $('.gardoonak-tabs-nav li');
            const $tabPanes = $('.gardoonak-tab-pane');

            $tabItems.on('click', function () {
                const $this = $(this);
                const targetTab = $this.data('tab');

                $tabItems.removeClass('active');
                $this.addClass('active');

                $tabPanes.removeClass('active').hide();
                $('#' + targetTab).fadeIn(300).addClass('active');
            });
        },

        /**
         * مدیریت فرم و ارسال AJAX
         */
        handleSettingsForm: function () {
            const $form = $('#gardoonak-settings-form');
            const $saveBtn = $form.find('.gn-btn');
            const $btnText = $saveBtn.find('.btn-text');
            const originalText = $btnText.text();

            $form.on('submit', function (e) {
                e.preventDefault();

                $saveBtn.prop('disabled', true).addClass('loading');
                $btnText.text('در حال ذخیره‌سازی...');

                // شبیه‌سازی ارسال (در آینده با wp_ajax تکمیل می‌شود)
                setTimeout(function () {
                    if (typeof window.gn_notify === 'function') {
                        window.gn_notify('تمامی تنظیمات با موفقیت بروزرسانی شدند.', 'success');
                    }
                    $saveBtn.prop('disabled', false).removeClass('loading');
                    $btnText.text(originalText);
                }, 1000);
            });
        },

        /**
         * مدیریت نمایش شرطی المان‌ها (Triggers & Terms)
         */
        handleTriggers: function () {
            // نمایش اینپوت صفحات خاص
            $('#gn_display_location').on('change', function () {
                const isSpecific = $(this).val() === 'specific';
                $('#specific_pages_wrapper')[isSpecific ? 'slideDown' : 'slideUp'](300);
            });

            // نمایش انتخاب برگه قوانین
            $('input[name="enable_terms"]').on('change', function () {
                const isEnabled = $(this).val() === '1';
                $('#terms_page_wrapper')[isEnabled ? 'fadeIn' : 'fadeOut'](300).css('display', isEnabled ? 'flex' : 'none');
            });
        },

        /**
         * مدیریت انتخاب صفحات و تگ‌ها
         */
        handlePageSelection: function () {
            const self = this;

            $('#gn_page_dropdown').on('change', function () {
                const pageId = $(this).val();
                const pageTitle = $(this).find('option:selected').text();

                if (pageId && !self.selectedPageIds.has(pageId)) {
                    self.selectedPageIds.add(pageId);

                    const $tag = $(`
                        <div class="gn-page-tag" data-id="${pageId}">
                            <span>${pageTitle}</span>
                            <span class="remove-tag" title="حذف">&times;</span>
                        </div>
                    `);

                    $('#gn_selected_pages_list').append($tag);
                    self.updateHiddenPageInput();
                }
                $(this).val('');
            });

            $(document).on('click', '.remove-tag', function () {
                const $tag = $(this).closest('.gn-page-tag');
                const pageId = $tag.data('id').toString();

                self.selectedPageIds.delete(pageId);
                $tag.fadeOut(200, function () {
                    $(this).remove();
                    self.updateHiddenPageInput();
                });
            });
        },

        updateHiddenPageInput: function () {
            const idsArray = Array.from(this.selectedPageIds);
            $('#gn_specific_pages_ids').val(idsArray.join(','));
        },

        /**
         * کالرپیکر مدرن
         */
        handleColorPicker: function () {
            $('#float_btn_color').on('input', function () {
                const color = $(this).val();
                $('#float_color_preview').css('background', color);
                $('.gn-color-hex').text(color);
            });
        },

        /**
         * مدیریت آپلود تصاویر با وردپرس مدیا
         */
        handleMediaUpload: function () {
            // آپلودر لوگو و آیکون شناور
            $('#gn_upload_logo_btn, #gn_upload_float_icon').on('click', function (e) {
                e.preventDefault();
                const $btn = $(this);
                const isLogo = $btn.attr('id') === 'gn_upload_logo_btn';

                const frame = wp.media({
                    title: isLogo ? 'انتخاب لوگوی مرکز گردونه' : 'انتخاب آیکون شناور',
                    button: { text: 'استفاده از این فایل' },
                    multiple: false
                });

                frame.on('select', function () {
                    const attachment = frame.state().get('selection').first().toJSON();
                    if (isLogo) {
                        $('#gn_wheel_logo_input').val(attachment.url);
                        $('#gn_logo_preview').html(`<img src="${attachment.url}">`);
                    } else {
                        $('#gn_custom_float_icon').val(attachment.url);
                        $('#gn_float_icon_preview').html(`<img src="${attachment.url}">`);
                    }
                });
                frame.open();
            });
        },

        /**
         * مقداردهی اولیه UI
         */
        initUiElements: function () {
            // انیمیشن کارت‌های تنظیمات (اصلاح شده به gn-form-row)
            $('.gardoonak-tab-pane.active').find('.gn-form-row').each(function (i) {
                $(this).css({ opacity: 0, marginTop: '20px' })
                    .delay(100 * i)
                    .animate({ opacity: 1, marginTop: '0px' }, 400);
            });
        }
    };

    $(document).ready(function () {
        GardoonakAdmin.init();
    });

})(jQuery);