class GardoonakWheel {
    constructor(canvasId, slices) {
        this.canvas = document.getElementById(canvasId);
        if (!this.canvas) return;
        this.ctx = this.canvas.getContext('2d');
        this.slices = slices;
        this.sliceCount = slices.length;
        this.angle = 0;
        this.isSpinning = false;

        // پیش‌بارگذاری تصاویر در صورت وجود
        this.loadImages().then(() => this.draw());
    }

    async loadImages() {
        const promises = this.slices.map(slice => {
            if (slice.prize_value) {
                try {
                    const data = JSON.parse(slice.prize_value);
                    if (data.img) {
                        return new Promise(resolve => {
                            const img = new Image();
                            img.src = data.img;
                            img.onload = () => { slice.imgObj = img; resolve(); };
                            img.onerror = resolve;
                        });
                    }
                } catch (e) { }
            }
            return Promise.resolve();
        });
        await Promise.all(promises);
    }

    draw() {
        const { ctx, canvas, slices, sliceCount } = this;
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const radius = centerX - 10;
        const sliceAngle = (2 * Math.PI) / sliceCount;

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        slices.forEach((slice, i) => {
            const startAngle = this.angle + i * sliceAngle;
            const endAngle = startAngle + sliceAngle;

            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.arc(centerX, centerY, radius, startAngle, endAngle);
            ctx.fillStyle = slice.slice_color || slice.color;
            ctx.fill();
            ctx.strokeStyle = 'rgba(255,255,255,0.2)';
            ctx.lineWidth = 1;
            ctx.stroke();

            // رسم متن و تصویر
            ctx.save();
            ctx.translate(centerX, centerY);
            ctx.rotate(startAngle + sliceAngle / 2);
            ctx.textAlign = "right";
            ctx.fillStyle = "#fff";
            ctx.font = "bold 14px IRANSans, Tahoma";
            ctx.shadowColor = "rgba(0,0,0,0.5)";
            ctx.shadowBlur = 4;

            // نمایش متن (label)
            ctx.fillText(slice.label || slice.title, radius - 40, 5);

            // نمایش تصویر اگر موجود باشد
            if (slice.imgObj) {
                ctx.drawImage(slice.imgObj, radius - 35, -15, 30, 30);
            }
            ctx.restore();
        });
    }

    spinTo(winnerIndex, callback) {
        if (this.isSpinning) return;
        this.isSpinning = true;

        const totalRotation = (360 * 10); // ۱۰ دور کامل برای هیجان بیشتر
        const sliceAngle = 360 / this.sliceCount;
        const stopAngle = 360 - (winnerIndex * sliceAngle) - (sliceAngle / 2);
        const finalRotation = totalRotation + stopAngle;

        const duration = 6000; // ۶ ثانیه
        const start = performance.now();

        const animate = (time) => {
            let t = Math.min((time - start) / duration, 1);
            let easeOut = 1 - Math.pow(1 - t, 4); // توقف بسیار نرم

            this.angle = (easeOut * finalRotation * Math.PI) / 180;
            this.draw();

            if (t < 1) requestAnimationFrame(animate);
            else {
                this.isSpinning = false;
                if (callback) callback();
            }
        };
        requestAnimationFrame(animate);
    }
}