<?php
/**
 * Plugin Name: Gardoonak
 * Description: افزونه پیشرفته گردونه شانس و گیمیفیکیشن
 * Version: 1.0.0
 * Author: Team Professional
 * Text Domain: gardoonak
 */

defined( 'ABSPATH' ) || exit;

// تعریف ثابت‌های مسیر
define( 'GARDOONAK_PATH', plugin_dir_path( __FILE__ ) );
define( 'GARDOONAK_URL', plugin_dir_url( __FILE__ ) );
define( 'GARDOONAK_VERSION', '1.0.0' );

// ۱. فراخوانی لودر برای شناسایی کلاس‌ها
require_once GARDOONAK_PATH . 'includes/Core/Loader.php';

// ۲. هوک فعال‌سازی برای ساخت دیتابیس
register_activation_hook( __FILE__, 'gardoonak_activate_plugin' );

function gardoonak_activate_plugin() {
    require_once GARDOONAK_PATH . 'includes/Database/Schema.php';
    \Gardoonak\Database\Schema::create_tables();
}

// ۳. اجرای افزونه
add_action( 'plugins_loaded', function() {
    \Gardoonak\Core\Plugin::instance();
});