jQuery(document).ready(function ($) {
    "use strict";

    // ساخت برگه لاگین
    $('#rp-create-page-ajax-btn').on('click', function (e) {
        e.preventDefault();
        var $btn = $(this);
        var $spinner = $('#rp-create-page-spinner');
        $btn.prop('disabled', true).addClass('disabled'); 
        $spinner.addClass('is-active');

        $.post(LocalData.ajax_url, {
            action: 'reyhan_create_login_page_ajax', 
            security: LocalData.nonce
        }, function (res) {
            $spinner.removeClass('is-active');
            if (res.success) {
                $btn.hide();
                // نمایش پیام موفقیت inline (حفظ حالت قبلی)
                $('#rp-create-page-success').text(res.data.msg || 'ساخته شد!').show().delay(3000).fadeOut();
                
                // آپدیت دراپ‌داون اگر وجود داشت
                var $dropdown = $('#rp_login_page_dropdown');
                if ($dropdown.length) {
                    if ($dropdown.find('option[value="' + res.data.id + '"]').length === 0) {
                        $dropdown.append(new Option(res.data.title, res.data.id));
                    }
                    $dropdown.val(res.data.id);
                }

                // نمایش نوتیفیکیشن سراسری
                window.rpShowToast('برگه لاگین با موفقیت ساخته شد.', 'success');

            } else {
                // جایگزینی آلرت خطا با تست
                window.rpShowToast(res.data, 'error');
                $btn.prop('disabled', false).removeClass('disabled');
            }
        });
    });

    // اجرای ابزارها (Factory Reset, etc)
    $('.rp-run-tool').click(function () {
        var btn = $(this);
        var action = btn.data('action');
        
        if (['factory_reset', 'nuke_tickets', 'nuke_users'].includes(action) && !confirm('این عملیات غیرقابل بازگشت است. ادامه می‌دهید؟')) return;

        btn.prop('disabled', true).text('در حال پردازش...');
        
        var data = { action: 'reyhan_tool_action', security: LocalData.nonce, tool_action: action };
        if (action === 'test_sms') data.mobile = $('#test_mobile_input').val();
        if (action === 'test_email') data.email = $('#test_email_input').val();

        $.post(LocalData.ajax_url, data, function (res) {
            btn.prop('disabled', false).text('اجرا');
            if (res.success) {
                // جایگزینی آلرت موفقیت با تست
                window.rpShowToast(res.data, 'success');
                
                if (action === 'factory_reset') {
                    setTimeout(function() { location.reload(); }, 1500);
                }
            } else {
                // جایگزینی آلرت خطا با تست
                window.rpShowToast(res.data, 'error');
            }
        });
    });

    // تست اتصال پیامک
    $('#btn-check-sms-connection').click(function (e) {
        e.preventDefault();
        var $btn = $(this);
        var $display = $('#rp-sms-balance-display');
        var $icon = $btn.find('.dashicons');

        $btn.prop('disabled', true).css('opacity', '0.7');
        $icon.addClass('spin');
        $display.html('<span style="color:#0277bd;">درحال برقراری ارتباط با سرور پیامک...</span>');

        $.post(LocalData.ajax_url, {
            action: 'reyhan_check_sms_credit', security: LocalData.nonce
        }, function (res) {
            $btn.prop('disabled', false).css('opacity', '1');
            $icon.removeClass('spin');
            if (res.success) {
                $display.html(`<div style="display:flex; align-items:center; gap:8px; margin-top:5px;"><span class="dashicons dashicons-yes-alt" style="color:#4CAF50; font-size:24px;"></span><div><strong style="color:#333; display:block;">اتصال برقرار است</strong><span style="color:#4CAF50; font-size:14px;">${res.data.msg}</span></div></div>`);
                $('.rp-sms-status-widget').css({ 'background': '#e8f5e9', 'border-color': '#a5d6a7' });
                
                // اختیاری: نمایش تست موفقیت
                window.rpShowToast('ارتباط با پنل پیامک برقرار است.', 'success');
            } else {
                $display.html(`<div style="display:flex; align-items:center; gap:8px; margin-top:5px;"><span class="dashicons dashicons-warning" style="color:#f44336; font-size:24px;"></span><div><strong style="color:#c62828; display:block;">خطا در اتصال</strong><span style="color:#d32f2f;">${res.data}</span></div></div>`);
                $('.rp-sms-status-widget').css({ 'background': '#ffebee', 'border-color': '#ffcdd2' });
                
                // اختیاری: نمایش تست خطا
                window.rpShowToast('خطا در برقراری ارتباط با پنل پیامک.', 'error');
            }
        });
    });
});