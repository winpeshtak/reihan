/* assets/js/admin/app.js */

(function ($) {
    'use strict';

    const GardoonakAdmin = {
        init: function () {
            this.handleGeneralSettings();
            this.initCustomSelects(); // اجرای اولیه برای تمام Selectها
            this.handleWheelBuilder();
            this.initMediaUploader();

            // یک ترفند مهندسی: اگر بخشی مثل "صفحات خاص" باز شد، مجدد چک کن
            $(document).on('click', '.gardoonak-tabs-nav li', () => {
                this.initCustomSelects();
            });
        },

        /* تبدیل خودکار Selectهای معمولی به نسخه مدرن تجاری */
        initCustomSelects: function () {
            const self = this;

            // هدف قرار دادن تمام سلکت‌هایی که کلاس gn-input دارند
            $('select.gn-input').each(function () {
                const $this = $(this);

                // اگر قبلاً تبدیل شده بود، نادیده‌اش بگیر
                if ($this.parent().hasClass('gn-custom-select-wrapper')) return;

                // ایجاد کانتینر محافظ
                const $wrapper = $('<div class="gn-custom-select-wrapper"></div>');
                $this.wrap($wrapper);

                // دریافت متن گزینه انتخاب شده فعلی
                const selectedText = $this.find('option:selected').text() || 'انتخاب کنید...';

                // اضافه کردن تریگر مدرن
                $this.after(`<div class="gn-select-trigger"><span>${selectedText}</span></div>`);

                // ساخت لیست گزینه‌ها
                const $optionsContainer = $('<div class="gn-select-options"></div>');
                $this.find('option').each(function () {
                    const isSelected = $(this).is(':selected') ? 'selected' : '';
                    $optionsContainer.append(`<div class="gn-select-option ${isSelected}" data-value="${$(this).val()}">${$(this).text()}</div>`);
                });

                $this.parent().append($optionsContainer);
            });
        },

        /* مدیریت تب‌ها و رویدادهای تنظیمات عمومی */
        handleGeneralSettings: function () {
            const self = this;

            // ۱. منطق تعویض تب‌ها
            $('.gardoonak-tabs-nav li').on('click', function () {
                const tabId = $(this).data('tab');

                // تغییر کلاس اکتیو در منوی کناری
                $('.gardoonak-tabs-nav li').removeClass('active');
                $(this).addClass('active');

                // مخفی سازی تمام پنل‌ها و نمایش پنل انتخاب شده با افکت نرم
                $('.gardoonak-tab-pane').removeClass('active').hide();
                $('#' + tabId).addClass('active').fadeIn(300);
            });

            // ۲. مدیریت نمایش شرطی فیلد "صفحات خاص" در تب پیکربندی پایه
            $('#gn_display_location').on('change', function () {
                if ($(this).val() === 'specific') {
                    $('#specific_pages_wrapper').slideDown(300);
                } else {
                    $('#specific_pages_wrapper').slideUp(300);
                }
            });
        },

        // مدیریت آپلودر رسانه برای تصاویر آیتم‌ها
        initMediaUploader: function () {
            $(document).on('click', '.gn-upload-btn', function (e) {
                e.preventDefault();
                const $btn = $(this);
                const $wrapper = $btn.closest('.gn-visual-image-area');
                const $input = $wrapper.find('.slice-img-url');
                const $preview = $wrapper.find('.slice-img-preview');

                const frame = wp.media({
                    title: 'انتخاب تصویر جایزه (فقط یک فایل)',
                    button: { text: 'تایید انتخاب' },
                    multiple: false // مهندس جان، محدودیت انتخاب فقط یک تصویر اینجا اعمال شده
                });

                frame.on('select', function () {
                    const attachment = frame.state().get('selection').first().toJSON();
                    $input.val(attachment.url);
                    $preview.css({
                        'background-image': 'url(' + attachment.url + ')',
                        'background-size': 'contain',
                        'background-repeat': 'no-repeat',
                        'background-position': 'center'
                    }).html('');
                    GardoonakAdmin.updateWheelVisuals();
                });

                frame.open();
            });
        },

        handleWheelBuilder: function () {
            const self = this;
            const $container = $('#gn_slices_container');

            // ۱. لود اطلاعات گردونه
            this.loadSingleWheel = function () {
                $.ajax({
                    url: gardoonak_ajax.url,
                    type: 'POST',
                    data: {
                        action: 'gardoonak_get_wheel_data',
                        security: gardoonak_ajax.nonce,
                        id: 1
                    },
                    success: function (res) {
                        if (res.success && res.data) {
                            self.populateBuilder(res.data);
                        } else {
                            // مقادیر پیش‌فرض در صورت خالی بودن دیتابیس
                            self.createSliceDOM(0, { label: 'جایزه اول', color: '#ff4757' });
                            self.createSliceDOM(1, { label: 'پوچ', color: '#2ecc71', type: 'loss' });
                            self.updateWheelVisuals();
                        }
                    }
                });
            };

            // ۲. پر کردن فرم بیلدر
            this.populateBuilder = function (data) {
                const w = data.wheel;
                const slices = data.slices;

                $('#gn_wheel_id_input').val(1);

                try {
                    const sets = typeof w.settings === 'string' ? JSON.parse(w.settings) : w.settings;
                    if (sets) {
                        $('#gn_campaign_name').val(sets.campaign_name || '');
                        $('#wheel_spin_count').val(sets.spin || 8);
                        $('#wheel_spin_duration').val(sets.duration || 5);
                    }
                } catch (e) { }

                $container.empty();
                if (slices && slices.length > 0) {
                    slices.forEach((s, i) => {
                        let actionData = {};
                        try { actionData = JSON.parse(s.prize_value); } catch (e) { actionData = {}; }

                        self.createSliceDOM(i, {
                            label: s.label,
                            color: s.slice_color,
                            type: s.prize_type,
                            visualType: actionData.img ? 'image' : 'color', // تشخیص هوشمند نوع بصری
                            chance: s.probability,
                            img: actionData.img || '',
                            actionType: actionData.action_type || 'coupon',
                            val: actionData.val || '',
                        });
                    });
                }
                self.updateWheelVisuals();
            };

            // ۳. ساخت DOM هر پره (Slice)
            this.createSliceDOM = function (index, data = {}) {
                const defaults = {
                    label: 'آیتم جدید',
                    color: '#ff4757', // رنگ پیش‌فرض از پالت
                    type: 'win',
                    visualType: 'color',
                    chance: 10,
                    img: '',
                    actionType: 'coupon',
                    val: ''
                };
                const config = { ...defaults, ...data };

                const $templateSource = $('#gn_slice_template');
                if ($templateSource.length === 0) return;

                let template = $templateSource.html();
                template = template.replace(/{INDEX}/g, index);

                const $el = $(template);

                $el.find('.gn-slice-body').hide();
                $el.removeClass('is-open');
                $container.append($el);

                // پر کردن مقادیر فیلدها
                $el.find('.slice-label').val(config.label);
                $el.find('.slice-color').val(config.color);
                $el.find('.slice-chance').val(config.chance);
                $el.find('.slice-img-url').val(config.img);

                // فعال کردن دایره رنگی مربوطه
                $el.find(`.gn-color-circle[data-color="${config.color}"]`).addClass('active');

                if (config.img) {
                    $el.find('.slice-img-preview').css('background-image', `url(${config.img})`).html('');
                }

                $el.find(`input[name="slice_type_${index}"][value="${config.type}"]`).prop('checked', true);
                $el.find(`input[name="slice_visual_${index}"][value="${config.visualType}"]`).prop('checked', true);
                $el.find('.slice-action-type').val(config.actionType);

                if (config.actionType === 'link') $el.find('.slice-link-val').val(config.val);
                else $el.find('.slice-coupon-val').val(config.val);

                self.updateSliceLogic($el);
            };

            // --- رویدادهای تعاملی ---

            // کلیک روی دایره‌های رنگی آماده (جایگزین کالرپیکر)
            $container.on('click', '.gn-color-circle', function () {
                const $circle = $(this);
                const color = $circle.data('color');
                const $parent = $circle.closest('.gn-slice-item');

                $parent.find('.gn-color-circle').removeClass('active');
                $circle.addClass('active');
                $parent.find('.slice-color').val(color);

                self.updateWheelVisuals();
            });

            // تغییر نوع بصری (رنگ یا تصویر)
            $container.on('change', '.slice-visual-type', function () {
                const $row = $(this).closest('.gn-slice-item');
                self.updateSliceLogic($row);
                self.updateWheelVisuals();
            });

            // تغییر برنده/بازنده یا اکشن‌ها
            $container.on('change input', '.slice-type, .slice-action-type, .slice-label, .slice-chance', function () {
                const $row = $(this).closest('.gn-slice-item');
                self.updateSliceLogic($row);
                self.updateWheelVisuals();
            });

            // حذف آیتم
            $container.on('click', '.gn-slice-remove', function () {
                if (confirm('مهندس جان، این آیتم حذف شود؟')) {
                    $(this).closest('.gn-slice-item').remove();
                    self.updateWheelVisuals();
                }
            });

            $container.on('click', '.gn-slice-header', function (e) {
                // اگر روی دکمه حذف کلیک شد، عملیات باز و بسته شدن اجرا نشود
                if ($(e.target).hasClass('gn-slice-remove')) return;

                const $item = $(this).closest('.gn-slice-item');
                const $body = $(this).next('.gn-slice-body');

                // جابجایی وضعیت باز و بسته بودن
                $body.slideToggle(250);
                $item.toggleClass('is-open');

                // تغییر جهت آیکون (اختیاری اگر استایلش را داری)
                const $icon = $(this).find('.gn-slice-toggle-icon');
                $icon.toggleClass('dashicons-arrow-down-alt2 dashicons-arrow-up-alt2');
            });
            // دکمه افزودن شانس جدید
            $(document).off('click', '#gn_add_slice_btn').on('click', '#gn_add_slice_btn', function (e) {
                e.preventDefault();
                self.createSliceDOM($container.children().length);
                self.updateWheelVisuals();
            });

            // مدیریت وضعیت فعال/غیرفعال
            $('.gn-status-btn').on('click', function () {
                $('.gn-status-btn').removeClass('active');
                $(this).addClass('active');
                const status = $(this).data('status');
                $('#gn_wheel_status_input').val(status);
                if (status === 'inactive') $('#gn_builder_main_area').addClass('is-locked');
                else $('#gn_builder_main_area').removeClass('is-locked');
            });

            // دکمه ذخیره نهایی
            $('#gn_save_wheel_btn').on('click', function (e) {
                e.preventDefault();
                const $btn = $(this);
                let slices = [];

                $container.find('.gn-slice-item').each(function () {
                    const $row = $(this);
                    const actionType = $row.find('.slice-action-type').val();
                    const val = (actionType === 'link') ? $row.find('.slice-link-val').val() : $row.find('.slice-coupon-val').val();

                    slices.push({
                        label: $row.find('.slice-label').val(),
                        color: $row.find('.slice-color').val(),
                        type: $row.find('.slice-type:checked').val(),
                        probability: $row.find('.slice-chance').val(),
                        prize_value: JSON.stringify({
                            img: $row.find('.slice-visual-type:checked').val() === 'image' ? $row.find('.slice-img-url').val() : '',
                            action_type: actionType,
                            val: val
                        })
                    });
                });

                $btn.prop('disabled', true).text('در حال ذخیره...');

                $.ajax({
                    url: gardoonak_ajax.url,
                    type: 'POST',
                    data: {
                        action: 'gardoonak_save_wheel',
                        security: gardoonak_ajax.nonce,
                        wheel_id: 1,
                        wheel_config: {
                            campaign_name: $('#gn_campaign_name').val(),
                            spin: $('#wheel_spin_count').val(),
                            duration: $('#wheel_spin_duration').val()
                        },
                        slices: slices
                    },
                    success: function (res) {
                        alert(res.success ? 'تغییرات با موفقیت ذخیره شد مهندس جان!' : 'خطا در ذخیره اطلاعات!');
                    },
                    complete: function () { $btn.prop('disabled', false).text('ذخیره تغییرات نهایی'); }
                });
            });

            /* بخش چرخش آزمایشی - داخل handleWheelBuilder */

            // متغیری برای ذخیره زاویه فعلی که چرخش‌ها روی هم جمع شوند
            let currentRotation = 0;

            $(document).on('click', '#gn_test_spin', function (e) {
                e.preventDefault();
                const $wheel = $('#gn_live_wheel');
                const $btn = $(this);

                // ۱. جلوگیری از کلیک مجدد در حین چرخش
                $btn.prop('disabled', true).css('opacity', '0.5');

                // ۲. محاسبات فیزیک چرخش
                // ۵ دور کامل (۱۸۰۰ درجه) + یک زاویه رندوم برای واقعی شدن
                const extraDegrees = Math.floor(Math.random() * 360) + 1800;
                currentRotation += extraDegrees;

                // ۳. اعمال استایل چرخشی با CSS3
                $wheel.css({
                    'transition': 'transform 4s cubic-bezier(0.15, 0, 0.15, 1)', // شتاب ملایم در انتها
                    'transform': 'rotate(' + currentRotation + 'deg)'
                });

                // ۴. آزاد کردن دکمه بعد از اتمام انیمیشن (۴ ثانیه)
                setTimeout(function () {
                    $btn.prop('disabled', false).css('opacity', '1');

                    // مهندس جان، اینجا می‌توانیم برنده‌ی تست را هم تشخیص بدهیم (اختیاری)
                    console.log("تست چرخش با موفقیت انجام شد.");
                }, 4000);
            });

            this.updateWheelVisuals = function () {
                const $preview = $('#gn_live_wheel');
                const $container = $('#gn_slices_container');
                if (!$preview.length) return;
                $preview.empty();

                let slices = [];
                $container.find('.gn-slice-item').each(function () {
                    const visualType = $(this).find('.slice-visual-type:checked').val();
                    slices.push({
                        label: $(this).find('.slice-label').val() || 'جایزه',
                        color: $(this).find('.slice-color').val() || '#ddd',
                        img: visualType === 'image' ? $(this).find('.slice-img-url').val() : ''
                    });
                });

                if (slices.length === 0) return;

                const totalSlices = slices.length;
                const deg = 360 / totalSlices;

                // ۱. رسم گرادینت گردونه
                let gradientParts = slices.map((s, i) => `${s.color} ${i * deg}deg ${(i + 1) * deg}deg`);
                $preview.css('background', `conic-gradient(${gradientParts.join(', ')})`);

                // ۲. جاگذاری متون با محاسبات برداری
                slices.forEach((s, i) => {
                    // زاویه مرکز هر پره (بدون کسر ۹۰ درجه در این متد جدید)
                    const centerAngle = (i * deg) + (deg / 2);

                    const itemHtml = `
            <div class="gn-slice-content" style="
                position: absolute;
                top: 50%;
                left: 50%;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                width: 80px; /* عرض محدود برای تمرکز در لبه */
                text-align: center;
                pointer-events: none;
                z-index: 10;
                /* جادوی اصلی اینجاست: اول چرخش به سمت پره، بعد پرتاب به لبه (115px)، بعد چرخش متن */
                transform: translate(-50%, -50%) rotate(${centerAngle}deg) translateY(-110px) rotate(0deg);
            ">
                ${s.img ? `<img src="${s.img}" style="width:26px; height:26px; object-fit:contain; margin-bottom:5px;">` : ''}
                <span style="
                    color: #fff; 
                    font-size: 10px; 
                    font-weight: bold; 
                    text-shadow: 0 1px 3px rgba(0,0,0,0.9);
                    white-space: nowrap;
                    max-width: 75px;
                    display: block;
                ">${s.label}</span>
            </div>`;
                    $preview.append(itemHtml);
                });
            };

            this.loadSingleWheel();
        },

        // مدیریت نمایش شرطی فیلدها
        updateSliceLogic: function ($el) {
            // ۱. برنده یا بازنده
            const type = $el.find('.slice-type:checked').val();
            if (type === 'loss') {
                $el.find('.gn-win-options-area').hide();
                $el.find('.gn-loss-options-area').show();
            } else {
                $el.find('.gn-loss-options-area').hide();
                $el.find('.gn-win-options-area').show();

                // نوع جایزه (لینک یا کوپن)
                const actionType = $el.find('.slice-action-type').val();
                if (actionType === 'link') {
                    $el.find('.gn-action-coupon-box').hide();
                    $el.find('.gn-action-link-box').show();
                } else {
                    $el.find('.gn-action-coupon-box').show();
                    $el.find('.gn-action-link-box').hide();
                }
            }

            // ۲. رنگ یا تصویر
            const visualType = $el.find('.slice-visual-type:checked').val();
            if (visualType === 'image') {
                $el.find('.gn-visual-color-area').hide();
                $el.find('.gn-visual-image-area').show();
            } else {
                $el.find('.gn-visual-image-area').hide();
                $el.find('.gn-visual-color-area').show();
            }
        },

        // آپدیت گرافیکی گردونه زنده
        updateWheelVisuals: function () {
            const $preview = $('#gn_live_wheel');
            const $container = $('#gn_slices_container');
            if (!$preview.length) return;
            $preview.empty();

            let slices = [];
            $container.find('.gn-slice-item').each(function () {
                const visualType = $(this).find('.slice-visual-type:checked').val();
                slices.push({
                    label: $(this).find('.slice-label').val() || 'جایزه',
                    color: $(this).find('.slice-color').val() || '#ddd',
                    img: visualType === 'image' ? $(this).find('.slice-img-url').val() : ''
                });
            });

            if (slices.length === 0) return;

            const deg = 360 / slices.length;
            let gradientParts = slices.map((s, i) => `${s.color} ${i * deg}deg ${(i + 1) * deg}deg`);
            $preview.css('background', `conic-gradient(${gradientParts.join(', ')})`);

            slices.forEach((s, i) => {
                const rotation = (i * deg) + (deg / 2);
                $preview.append(`
                    <div class="gn-wheel-element" style="transform:translate(-50%, -50%) rotate(${rotation}deg);">
                        <div style="text-align:center;">
                            ${s.img ? `<img src="${s.img}" style="width:25px; height:25px; display:block; margin:0 auto 5px;">` : ''}
                            <span style="color:#fff; font-size:10px; font-weight:bold; text-shadow:0 1px 2px rgba(0,0,0,0.5);">${s.label}</span>
                        </div>
                    </div>`);
            });
        },

        getRandomColor: function () {
            const colors = ['#ff4757', '#2ecc71', '#3498db', '#f1c40f', '#9b59b6'];
            return colors[Math.floor(Math.random() * colors.length)];
        }
    };

    $(document).ready(function () { GardoonakAdmin.init(); });

})(jQuery);