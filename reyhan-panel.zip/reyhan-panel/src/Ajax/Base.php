<?php
namespace ReyhanPanel\Ajax;
if ( ! defined( 'ABSPATH' ) ) { exit; }

abstract class Base {

    protected $prefix = 'reyhan_';

    public function __construct() {
        $this->register_actions();
    }

    abstract protected function register_actions();

    protected function add_ajax_action( $tag, $method, $nopriv = false ) {
        $action_name = $this->prefix . $tag;
        add_action( 'wp_ajax_' . $action_name, [ $this, $method ] );
        if ( $nopriv ) {
            add_action( 'wp_ajax_nopriv_' . $action_name, [ $this, $method ] );
        }
    }

    protected function check_nonce( $action_name = 'reyhan_auth_nonce', $query_arg = 'security' ) {
        if ( ! check_ajax_referer( $action_name, $query_arg, false ) ) {
            $this->send_error( __('خطای امنیتی: درخواست نامعتبر است.', 'reyhan-panel'), 403 );
        }
    }

    protected function send_success( $data = null ) {
        wp_send_json_success( $data );
    }

    protected function send_error( $message, $code = 400 ) {
        wp_send_json_error( $message, $code );
    }

    protected function handle_upload( $file_key ) {
        if ( empty( $_FILES[ $file_key ]['name'] ) ) return false;

        $file = $_FILES[ $file_key ];
        $opts = get_option( 'reyhan_options' );

        // 1. بررسی حجم
        $max_size_mb = ! empty( $opts['file_max_size'] ) ? floatval( $opts['file_max_size'] ) : 2;
        if ( $file['size'] > $max_size_mb * 1024 * 1024 ) {
            $this->send_error( sprintf(__('حجم فایل نباید بیشتر از %s مگابایت باشد.', 'reyhan-panel'), $max_size_mb) );
        }

        // 2. بررسی اکستنشن و نوع فایل
        $file_check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
        if ( ! $file_check['ext'] || ! $file_check['type'] ) {
             $this->send_error( __('این نوع فایل مجاز نیست (فرمت یا محتوای غیرمجاز).', 'reyhan-panel') );
        }

        // 3. لیست سیاه امنیتی (یکپارچه با سمت کاربر)
        $blocked_exts = [ 
            'php', 'php3', 'php4', 'php5', 'php7', 'phtml', 'phar', // PHP variants
            'js', 'jsx', 'ts', 'tsx', 'vbs', 'vb', 'wsf',           // Scripts
            'exe', 'sh', 'bat', 'cmd', 'com', 'cpl', 'scr', 'msi', 'bin', // Executables
            'jar', 'htaccess', 'htpasswd', 'ini', 'config',         // Configs
            'svg', 'svgz'                                           // XSS vectors
        ];
        
        $ext_lower = strtolower( (string) $file_check['ext'] );
        if ( in_array( $ext_lower, $blocked_exts, true ) ) {
            $this->send_error( __('فرمت فایل توسط مدیر مسدود شده است (امنیتی).', 'reyhan-panel') );
        }

        // 4. لیست مجاز مدیر (Whitelist)
        $allowed_exts_str = ! empty( $opts['file_allowed_extensions'] ) ? $opts['file_allowed_extensions'] : 'jpg,png,pdf';
        $allowed_array = array_map( 'trim', explode( ',', strtolower( $allowed_exts_str ) ) );
        
        if ( ! in_array( $ext_lower, $allowed_array, true ) ) {
            $this->send_error( __('فرمت فایل مجاز نیست.', 'reyhan-panel') );
        }

        // 5. آپلود استاندارد در Media Library (برای دریافت ID)
        if ( ! function_exists( 'media_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/image.php' );
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
            require_once( ABSPATH . 'wp-admin/includes/media.php' );
        }

        $att_id = media_handle_upload( $file_key, 0 );

        if ( is_wp_error( $att_id ) ) {
            $this->send_error( $att_id->get_error_message() );
        }

        return $att_id; // اکنون ID برمی‌گرداند نه URL
    }
}