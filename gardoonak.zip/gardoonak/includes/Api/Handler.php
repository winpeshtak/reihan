<?php
namespace Gardoonak\Api;

defined( 'ABSPATH' ) || exit;

class Handler {

    public function __construct() {
        // ایجاد اندپوینت اختصاصی در وردپرس
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    /**
     * ثبت آدرس API اختصاصی گردونک
     * آدرس نهایی: yoursite.com/wp-json/gardoonak/v1/spin
     */
    public function register_routes() {
        register_rest_route( 'gardoonak/v1', '/spin', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'handle_spin_request' ],
            'permission_callback' => '__return_true', // در مراحل بعد امنیت (Nonce) اضافه می‌شود
        ] );
    }

    /**
     * پردازش درخواست چرخش
     */
    public function handle_spin_request( $request ) {
        // ۱. دریافت داده‌های ارسالی از سمت کاربر
        $params = $request->get_params();
        $campaign_id = isset( $params['campaign_id'] ) ? intval( $params['campaign_id'] ) : 0;
        $mobile      = isset( $params['mobile'] ) ? sanitize_text_field( $params['mobile'] ) : '';

        // ۲. اعتبارسنجی اولیه (ورودی‌ها خالی نباشند)
        if ( empty( $campaign_id ) || empty( $mobile ) ) {
            return new \WP_REST_Response( [
                'success' => false,
                'message' => 'اطلاعات ارسالی ناقص است.'
            ], 400 );
        }

        // ۳. فراخوانی موتور اصلی بازی (Engine) که در مرحله قبل ساختیم
        $engine = new \Gardoonak\Game\Engine();
        $user_data = [ 'mobile' => $mobile ];
        
        $result = $engine->spin( $campaign_id, $user_data );

        // ۴. ارسال پاسخ نهایی به فرانت‌اند
        if ( isset( $result['error'] ) ) {
            return new \WP_REST_Response( $result, 403 );
        }

        return new \WP_REST_Response( $result, 200 );
    }
}