<?php
namespace Gardoonak\Game;

defined( 'ABSPATH' ) || exit;

class Engine {

    /**
     * اجرای اصلی چرخش
     * این تابع توسط API صدا زده می‌شود.
     */
    public function spin( $campaign_id, $user_data ) {
        // ۱. دریافت تنظیمات کمپین از دیتابیس
        $campaign = $this->get_campaign_config( $campaign_id );
        
        if ( ! $campaign ) {
            return [ 'error' => 'کمپین یافت نشد.' ];
        }

        // ۲. اعتبارسنجی کاربر (آیا قبلاً شرکت کرده؟)
        // اینجا بعداً متد Check_Limits اضافه می‌شود.

        // ۳. انتخاب برنده بر اساس احتمالات ریاضی
        $winning_slice = $this->calculate_winner( $campaign['slices'] );

        // ۴. ثبت در دیتابیس (لاگ)
        $this->log_result( $campaign_id, $user_data, $winning_slice );

        return [
            'success'       => true,
            'slice_index'   => $winning_slice['index'], // ایندکس برای چرخیدن گردونه در فرانت
            'prize_title'   => $winning_slice['title'],
            'prize_type'    => $winning_slice['type'],
            'prize_value'   => $winning_slice['value'], // مثلا کد تخفیف
            'message'       => $winning_slice['win_message']
        ];
    }

    /**
     * الگوریتم انتخاب برنده بر اساس شانس (وزن)
     */
    private function calculate_winner( $slices ) {
        $total_weight = 0;
        
        // محاسبه مجموع کل شانس‌ها (مثلاً جمع کل می‌شود ۱۰۰ یا ۱۰۰۰)
        foreach ( $slices as $slice ) {
            // اگر شانس تعریف نشده بود، پیش‌فرض ۱ در نظر می‌گیریم
            $weight = isset($slice['probability']) ? intval($slice['probability']) : 1;
            $total_weight += $weight;
        }

        // انتخاب یک عدد تصادفی بین ۱ تا مجموع وزن‌ها
        // استفاده از mt_rand برای تولید عدد تصادفی بهتر نسبت به rand معمولی
        $random_point = mt_rand( 1, $total_weight );
        
        $current_point = 0;

        foreach ( $slices as $index => $slice ) {
            $weight = isset($slice['probability']) ? intval($slice['probability']) : 1;
            $current_point += $weight;

            // اگر عدد تصادفی در بازه این اسلایس بود، این برنده است
            if ( $random_point <= $current_point ) {
                $slice['index'] = $index; // ذخیره شماره اسلایس برای فرانت
                return $slice;
            }
        }
        
        // جهت اطمینان، اگر باگی رخ داد، آخرین گزینه را برمی‌گرداند (Fallback)
        $last_slice = end($slices);
        $last_slice['index'] = count($slices) - 1;
        return $last_slice; 
    }

    /**
     * خواندن تنظیمات از دیتابیس (شبیه‌سازی فعلی)
     */
    private function get_campaign_config( $id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'gardoonak_campaigns';
        
        // دریافت رکورد از دیتابیس
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT config FROM $table WHERE id = %d", $id ) );

        if ( $row ) {
            return json_decode( $row->config, true );
        }
        return false;
    }

    /**
     * ثبت لاگ در دیتابیس
     */
    private function log_result( $campaign_id, $user_data, $slice ) {
        global $wpdb;
        $table = $wpdb->prefix . 'gardoonak_logs';

        $wpdb->insert(
            $table,
            [
                'campaign_id'     => $campaign_id,
                'user_identifier' => $user_data['mobile'] ?? 'unknown', // شماره موبایل یا IP
                'prize_index'     => $slice['index'],
                'prize_code'      => $slice['value'], // کد تخفیف برنده شده
                'ip_address'      => $_SERVER['REMOTE_ADDR'],
                'user_agent'      => $_SERVER['HTTP_USER_AGENT'],
                'created_at'      => current_time( 'mysql' )
            ]
        );
    }
}