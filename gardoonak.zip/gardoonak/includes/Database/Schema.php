<?php
namespace Gardoonak\Database;

defined( 'ABSPATH' ) || exit;

/**
 * کلاس مدیریت ساختار دیتابیس افزونه گردونک
 */
class Schema {

    /**
     * متد اصلی برای ساخت جداول اختصاصی در هنگام فعال‌سازی
     */
    public static function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();
        $table_prefix    = $wpdb->prefix;

        // فراخوانی فایل ارتقای دیتابیس وردپرس
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // ۱. جدول اصلی گردونه‌ها
        // نکته مهم: dbDelta با IF NOT EXISTS کار نمی‌کند.
        $table_wheels = $table_prefix . 'gardoonak_wheels';
        $sql_wheels = "CREATE TABLE $table_wheels (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            settings longtext DEFAULT NULL,
            status varchar(20) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // ۲. جدول اسلایس‌ها
        $table_slices = $table_prefix . 'gardoonak_slices';
        $sql_slices = "CREATE TABLE $table_slices (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            wheel_id bigint(20) UNSIGNED NOT NULL,
            label varchar(255) NOT NULL,
            prize_type varchar(50) NOT NULL,
            prize_value text DEFAULT NULL,
            probability int(3) NOT NULL DEFAULT 0,
            slice_color varchar(20) DEFAULT '#ffffff',
            PRIMARY KEY  (id),
            KEY wheel_id (wheel_id)
        ) $charset_collate;";

        // ۳. جدول لاگ‌ها
        $table_logs = $table_prefix . 'gardoonak_logs';
        $sql_logs = "CREATE TABLE $table_logs (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            wheel_id bigint(20) UNSIGNED NOT NULL,
            slice_id bigint(20) UNSIGNED NOT NULL,
            user_identifier varchar(255) NOT NULL,
            ip_address varchar(45) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY wheel_id (wheel_id),
            KEY slice_id (slice_id)
        ) $charset_collate;";

        // اجرای کوئری‌ها
        dbDelta( $sql_wheels );
        dbDelta( $sql_slices );
        dbDelta( $sql_logs );
    }
}