/* assets/js/frontend/ajax.js */
jQuery(document).ready(function ($) {
    'use strict';

    let wheel = null;

    // ۱. باز کردن پاپ آپ با کلیک روی دکمه شناور
    $(document).on('click', '#gn_trigger_btn', function () {
        $('#gn_wheel_modal').addClass('open');
        $('body').css('overflow', 'hidden');

        // مقداردهی گردونه فقط در صورت وجود داده‌ها
        if (!wheel && typeof gardoonak_data !== 'undefined' && gardoonak_data.slices) {
            wheel = new GardoonakWheel('gardoonak-canvas', gardoonak_data.slices);
        }
    });

    // ۲. بستن پاپ آپ
    $(document).on('click', '#gn_close_wheel', function () {
        $('#gn_wheel_modal').removeClass('open');
        $('body').css('overflow', 'auto');
    });

    // ۳. لاجیک دکمه چرخش (بچرخون و برنده شو)
    $(document).on('click', '#gn_start_spin', function (e) {
        e.preventDefault();
        const $btn = $(this);
        const mobile = $('#gn_user_phone').val();

        // بررسی وجود داده‌های گردونه قبل از ارسال درخواست
        if (typeof gardoonak_data === 'undefined' || !gardoonak_data.slices) {
            alert('مهندس جان، داده‌های گردونه هنوز بارگذاری نشده‌اند!');
            return;
        }

        if (!mobile || mobile.length < 11) {
            alert('لطفاً شماره موبایل معتبر وارد کنید.');
            return;
        }

        $btn.prop('disabled', true).text('در حال قرعه‌کشی...');

        $.ajax({
            url: gardoonak_data.api_url,
            method: 'POST',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', gardoonak_data.nonce);
            },
            data: {
                mobile: mobile,
            },
            success: function (res) {
                if (res.success && wheel) {
                    wheel.spinTo(res.slice_index, function () {
                        alert('تبریک! ' + res.prize_title); // حالا دیگر undefined نخواهد بود
                        $btn.prop('disabled', false).text('دوباره!');
                    });
                } else {
                    alert(res.message || 'خطای غیرمنتظره');
                    $btn.prop('disabled', false);
                }
            },
            error: function () {
                alert('خطا در ارتباط با سرور.');
                $btn.prop('disabled', false);
            }
        });
    });
});