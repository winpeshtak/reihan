class GardoonakWheel {
    constructor(canvasId, slices) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.slices = slices;
        this.sliceCount = slices.length;
        this.angle = 0; // زاویه فعلی
        this.isSpinning = false;

        this.draw();
    }

    // رسم گردونه
    draw() {
        const { ctx, canvas, slices, sliceCount } = this;
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const radius = centerX - 10;
        const sliceAngle = (2 * Math.PI) / sliceCount;

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        slices.forEach((slice, i) => {
            const startAngle = this.angle + i * sliceAngle;
            const endAngle = startAngle + sliceAngle;

            // رسم قاچ
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.arc(centerX, centerY, radius, startAngle, endAngle);
            ctx.fillStyle = slice.color;
            ctx.fill();
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 2;
            ctx.stroke();

            // رسم متن جایزه
            ctx.save();
            ctx.translate(centerX, centerY);
            ctx.rotate(startAngle + sliceAngle / 2);
            ctx.textAlign = "right";
            ctx.fillStyle = "#fff";
            ctx.font = "bold 18px Tahoma";
            ctx.fillText(slice.title, radius - 30, 10);
            ctx.restore();
        });
    }

    // انیمیشن چرخش
    spinTo(winnerIndex, callback) {
        if (this.isSpinning) return;
        this.isSpinning = true;

        const sliceAngle = (360 / this.sliceCount);
        const totalRotation = 360 * 5; // ۵ دور کامل برای جذابیت
        const stopAngle = (360 - (winnerIndex * sliceAngle)) - (sliceAngle / 2);
        const finalRotation = totalRotation + stopAngle;

        let currentRotation = 0;
        const duration = 5000; // ۵ ثانیه چرخش
        const start = performance.now();

        const animate = (time) => {
            let elapsed = time - start;
            let t = Math.min(elapsed / duration, 1);

            // تابع Easing برای شروع سریع و توقف نرم
            let easeOut = 1 - Math.pow(1 - t, 3);

            let rotation = easeOut * finalRotation;
            this.angle = (rotation * Math.PI) / 180;
            this.draw();

            if (t < 1) {
                requestAnimationFrame(animate);
            } else {
                this.isSpinning = false;
                if (callback) callback();
            }
        };

        requestAnimationFrame(animate);
    }
}