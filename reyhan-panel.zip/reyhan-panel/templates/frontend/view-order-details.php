<?php 
if ( ! defined( 'ABSPATH' ) ) { exit; } 

if ( ! isset($order) || ! $order ) {
    echo '<div class="rp-error">' . esc_html__('اطلاعات سفارش یافت نشد.', 'reyhan-panel') . '</div>';
    return;
}
?>

<div class="rp-order-details-header">
    <button class="rp-btn-back" onclick="ReyhanApp.backToOrderList()">
        <span class="dashicons dashicons-arrow-right-alt2"></span> <?php esc_html_e('بازگشت به لیست', 'reyhan-panel'); ?>
    </button>
    <h3>
        <?php printf( esc_html__( 'سفارش #%s', 'reyhan-panel' ), esc_html( $order->get_order_number() ) ); ?>
        <span class="rp-badge rp-status-<?php echo esc_attr( $order->get_status() ); ?>">
            <?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?>
        </span>
    </h3>
</div>

<div class="rp-order-items-box">
    <table class="rp-order-items-table">
        <thead>
            <tr>
                <th><?php esc_html_e( 'محصول', 'reyhan-panel' ); ?></th>
                <th><?php esc_html_e( 'تعداد', 'reyhan-panel' ); ?></th>
                <th><?php esc_html_e( 'قیمت کل', 'reyhan-panel' ); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ( $order->get_items() as $item_id => $item ) : 
                $product = $item->get_product();
                ?>
                <tr>
                    <td>
                        <div class="rp-product-name">
                            <?php echo esc_html( $item->get_name() ); ?>
                            <?php 
                            if ( $metadata = wc_display_item_meta( $item, ['echo' => false] ) ) {
                                echo '<div class="rp-item-meta">' . wp_kses_post( $metadata ) . '</div>';
                            }
                            ?>
                        </div>
                    </td>
                    <td>x <?php echo esc_html( $item->get_quantity() ); ?></td>
                    <td>
                        <?php echo wp_kses_post( $order->get_formatted_line_subtotal( $item ) ); ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="2"><strong><?php esc_html_e( 'مجموع کل:', 'reyhan-panel' ); ?></strong></td>
                <td><strong><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></strong></td>
            </tr>
        </tfoot>
    </table>
</div>

<div class="rp-order-addresses-grid">
    <div class="rp-address-box">
        <h4><?php esc_html_e( 'آدرس صورت‌حساب', 'reyhan-panel' ); ?></h4>
        <address>
            <?php 
            echo wp_kses_post( $order->get_formatted_billing_address() ); 
            ?>
        </address>
    </div>
    
    <?php if ( $order->needs_shipping_address() ) : ?>
    <div class="rp-address-box">
        <h4><?php esc_html_e( 'آدرس حمل و نقل', 'reyhan-panel' ); ?></h4>
        <address>
            <?php echo wp_kses_post( $order->get_formatted_shipping_address() ); ?>
        </address>
    </div>
    <?php endif; ?>
</div>

<?php if ( $order->get_customer_note() ) : ?>
<div class="rp-order-note">
    <h4><?php esc_html_e( 'یادداشت شما:', 'reyhan-panel' ); ?></h4>
    <p><?php echo nl2br( esc_html( $order->get_customer_note() ) ); ?></p>
</div>
<?php endif; ?>