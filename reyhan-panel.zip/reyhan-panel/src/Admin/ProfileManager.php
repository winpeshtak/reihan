<?php
namespace ReyhanPanel\Admin;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class ProfileManager {

    public function __construct() {
        add_action( 'admin_init', [ $this, 'handle_agent_profile_save' ] );
    }

    public function render_page() {
        // 1. آماده‌سازی داده‌ها برای ارسال به ویو
        $uid = get_current_user_id();
        $fname = get_user_meta($uid, 'first_name', true);
        $lname = get_user_meta($uid, 'last_name', true);
        $avatar = get_user_meta($uid, 'reyhan_user_avatar', true);
        
        $default_avatar = \REYHAN_URL . 'assets/images/user.png';
        $preview_src = !empty($avatar) ? $avatar : $default_avatar;
        
        $canned = get_user_meta($uid, 'rp_user_canned_responses', true);
        if(!is_array($canned)) $canned = [];

        // 2. فراخوانی فایل قالب جدید (جایگزین کدهای HTML قدیمی)
        // این خط باعث می‌شود فایل view-agent-profile.php که طراحی کردیم نمایش داده شود
        if ( file_exists( \REYHAN_DIR . 'templates/admin/view-agent-profile.php' ) ) {
            include \REYHAN_DIR . 'templates/admin/view-agent-profile.php';
        } else {
            echo '<div class="error"><p>' . __('فایل قالب پروفایل یافت نشد.', 'reyhan-panel') . '</p></div>';
        }
    }

    public function handle_agent_profile_save() {
        if ( isset($_POST['rp_agent_profile_nonce']) && wp_verify_nonce($_POST['rp_agent_profile_nonce'], 'save_agent_profile') ) {
            $uid = get_current_user_id();
            if(isset($_POST['first_name'])) update_user_meta($uid, 'first_name', sanitize_text_field($_POST['first_name']));
            if(isset($_POST['last_name'])) update_user_meta($uid, 'last_name', sanitize_text_field($_POST['last_name']));
            $display_name = trim(sanitize_text_field($_POST['first_name']) . ' ' . sanitize_text_field($_POST['last_name']));
            if(!empty($display_name)) wp_update_user([ 'ID' => $uid, 'display_name' => $display_name ]);

            if ( !empty($_FILES['agent_avatar_file']['name']) ) {
                require_once( ABSPATH . 'wp-admin/includes/image.php' );
                require_once( ABSPATH . 'wp-admin/includes/file.php' );
                require_once( ABSPATH . 'wp-admin/includes/media.php' );


$file = $_FILES['agent_avatar_file'];
$check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
$ext   = strtolower( (string) $check['ext'] );
$type  = strtolower( (string) $check['type'] );

$allowed_exts = [ 'jpg','jpeg','png','webp','gif' ];
if ( empty($ext) || empty($type) || ! in_array( $ext, $allowed_exts, true ) || strpos( $type, 'image/' ) !== 0 ) {
    // جلوگیری از آپلود فایل غیرتصویری به عنوان آواتار
    wp_safe_redirect( add_query_arg( 'updated', 'true', admin_url('admin.php?page=reyhan-agent-profile') ) );
    exit;
}
                $attachment_id = media_handle_upload( 'agent_avatar_file', 0 );
                if ( ! is_wp_error( $attachment_id ) ) {
                    $image_url = wp_get_attachment_url( $attachment_id );
                    update_user_meta($uid, 'reyhan_user_avatar', $image_url);
                }
            } elseif ( isset($_POST['reyhan_user_avatar_status']) && $_POST['reyhan_user_avatar_status'] === 'removed' ) {
                delete_user_meta($uid, 'reyhan_user_avatar');
            }

            if ( isset($_POST['reyhan_options']['rp_user_canned_responses']) ) {
                $canned = $_POST['reyhan_options']['rp_user_canned_responses'];
                if ( is_array( $canned ) ) {
                    $clean = [];
                    foreach ( $canned as $item ) {
                        $item = sanitize_textarea_field( (string) $item );
                        if ( $item !== '' ) {
                            $clean[] = $item;
                        }
                    }
                    update_user_meta( $uid, 'rp_user_canned_responses', array_values( $clean ) );
                }
            } else { delete_user_meta($uid, 'rp_user_canned_responses'); }

            do_action( 'reyhan_agent_profile_updated', $uid, $_POST );
            wp_redirect( add_query_arg( 'updated', 'true', admin_url('admin.php?page=reyhan-agent-profile') ) );
            exit;
        }
    }
}