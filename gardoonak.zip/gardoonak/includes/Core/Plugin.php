<?php
namespace Gardoonak\Core;

defined( 'ABSPATH' ) || exit;

/**
 * کلاس اصلی افزونه گردونک
 * این کلاس به صورت Singleton طراحی شده تا از مصرف بیهوده منابع جلوگیری شود.
 */
class Plugin {

    public function enqueue_shared_assets() {
    wp_enqueue_style( 
        'gardoonak-branding', 
        GARDOONAK_URL . 'assets/css/branding.css', 
        [], 
        GARDOONAK_VERSION 
    );
    }

    /**
     * نگهداری تنها نمونه از کلاس
     */
    private static $_instance = null;

    /**
     * متغیرهای نگهدارنده ماژول‌ها
     */
    public $license_manager;
    public $api_handler;
    public $game_engine;

    /**
     * متد Instance برای دسترسی به کلاس در سراسر وردپرس
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * سازنده کلاس - خصوصی شده برای امنیت
     */
    private function __construct() {
        $this->define_constants();
        $this->load_dependencies();
        $this->init_hooks();
    }

    /**
     * تعریف ثابت‌های مورد نیاز افزونه
     */
    private function define_constants() {
        if ( ! defined( 'GARDOONAK_VERSION' ) ) {
            define( 'GARDOONAK_VERSION', '1.0.0' );
        }
    }

    /**
     * بارگذاری خودکار و نمونه‌سازی از کلاس‌های ماژولار
     */
    private function load_dependencies() {
        // ۱. ماژول لایسنسینگ
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'License/Manager.php';
        $this->license_manager = new \Gardoonak\License\Manager();

        // ۲. موتور اصلی بازی
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'Game/Engine.php';
        $this->game_engine = new \Gardoonak\Game\Engine();

        // ۳. هندلر API (برای ارتباط فرانت و بک‌ان)
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'Api/Handler.php';
        $this->api_handler = new \Gardoonak\Api\Handler();

        // ۴. بخش ادمین (فقط در صورت حضور در پیشخوان)
        if ( is_admin() ) {
            $this->init_admin();
        }
    }

    /**
     * راه‌اندازی بخش مدیریت
     */
    private function init_admin() {
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'Admin/Menu.php';
        new \Gardoonak\Admin\Menu();
    }

    /**
     * ثبت هوک‌های عمومی وردپرس
     */
    private function init_hooks() {
        // هوک برای بارگذاری استایل‌ها و اسکریپت‌های سمت کاربر
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend_assets' ] );
    }

    /**
     * بارگذاری منظم فایل‌های CSS و JS طبق دستور مهندس
     */
    public function enqueue_frontend_assets() {
        // ثبت CSS فرانت‌ند
        wp_enqueue_style( 
            'gardoonak-frontend-style', 
            plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/css/frontend/wheel.css', 
            [], 
            GARDOONAK_VERSION 
        );

        // ثبت JS فرانت‌ند
        wp_enqueue_script( 
            'gardoonak-canvas-engine', 
            plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/js/frontend/canvas.js', 
            [], 
            GARDOONAK_VERSION, 
            true 
        );

        wp_enqueue_script( 
            'gardoonak-ajax-handler', 
            plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/js/frontend/ajax.js', 
            ['jquery'], 
            GARDOONAK_VERSION, 
            true 
        );

        // پاس دادن متغیرهای لازم به JS (مثل آدرس API)
        wp_localize_script( 'gardoonak-ajax-handler', 'gardoonak_data', [
            'api_url' => get_rest_url( null, 'gardoonak/v1/spin' ),
            'nonce'   => wp_create_nonce( 'wp_rest' )
        ]);
    }

    /**
     * جلوگیری از کپی شدن نمونه کلاس (امنیت Singleton)
     */
    public function __clone() {
        _doing_it_wrong( __FUNCTION__, __( 'کپی کردن این کلاس مجاز نیست.', 'gardoonak' ), '1.0.0' );
    }
}

add_shortcode('gardoonak_wheel', function($atts) {
    // ۱. دریافت تنظیمات از دیتابیس
    $slices = get_option('gardoonak_slices', []);
    
    if (empty($slices)) return 'مهندس جان، هنوز هیچ اسلایسی برای گردونه تعریف نشده است!';

    // ۲. آماده‌سازی داده‌ها برای پاس دادن به جاوااسکریپت
    wp_localize_script('gardoonak-ajax-handler', 'gardoonak_settings', [
        'campaign_id' => 1, // فعلا به صورت ثابت
        'slices'      => $slices
    ]);

    // ۳. خروجی HTML
    ob_start();
    ?>
    <div class="gardoonak-container">
        <div class="gardoonak-wrapper">
            <div class="gardoonak-pointer"></div>
            <canvas id="gardoonak-canvas" width="500" height="500"></canvas>
        </div>
        <div class="gardoonak-controls">
            <input type="text" id="gardoonak-mobile" placeholder="شماره موبایل (مثلا ۰۹۱۲۳۴۵۶۷۸۹)">
            <button id="gardoonak-spin-btn">شروع قرعه‌کشی</button>
        </div>
    </div>
    <?php
    return ob_get_clean();
});