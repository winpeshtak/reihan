jQuery(document).ready(function ($) {
    // افزودن ردیف جدید اسلایس
    $('.add-slice').on('click', function (e) {
        e.preventDefault();
        var index = $('.slice-row').length;
        var html = `
            <div class="slice-row" style="background:#fff; padding:15px; margin-bottom:10px; border:1px solid #ccc; border-radius:5px;">
                <h4>اسلایس شماره ${index + 1}</h4>
                <div class="field-group">
                    <label>عنوان جایزه:</label>
                    <input type="text" name="gardoonak_slices[${index}][title]" value="" placeholder="مثلا: ۲۰٪ تخفیف">
                </div>
                <div class="field-group">
                    <label>رنگ اسلایس:</label>
                    <input type="color" name="gardoonak_slices[${index}][color]" value="#ffffff">
                </div>
                <div class="field-group">
                    <label>شانس برنده شدن (۰ تا ۱۰۰):</label>
                    <input type="number" name="gardoonak_slices[${index}][probability]" value="10" min="0" max="100">
                </div>
                <div class="field-group">
                    <label>نوع جایزه:</label>
                    <select name="gardoonak_slices[${index}][type]">
                        <option value="coupon">کد تخفیف ووکامرس</option>
                        <option value="link">لینک مستقیم</option>
                        <option value="empty">پوچ</option>
                    </select>
                </div>
                <button class="button remove-slice" style="color:red; margin-top:10px;">حذف این اسلایس</button>
            </div>
        `;
        $('#slices-container').append(html);
    });

    // حذف ردیف اسلایس
    $(document).on('click', '.remove-slice', function (e) {
        e.preventDefault();
        $(this).closest('.slice-row').remove();
    });
});