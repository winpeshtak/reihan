<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="wrap reyhanpanel-wrap rp-agent-profile-modern">
    
    <form method="post" action="" enctype="multipart/form-data">
        <?php wp_nonce_field('save_agent_profile', 'rp_agent_profile_nonce'); ?>

        <div class="rp-profile-header-hero">
            <div class="rp-hero-split-right" style="display:flex; align-items:center; gap:15px;">
                <div class="rp-mod-hero-icon" style="background:#fff; width:50px; height:50px; display:flex; align-items:center; justify-content:center; border-radius:12px; color:#FF5722; box-shadow:0 5px 15px rgba(0,0,0,0.05);">
                    <span class="dashicons dashicons-id-alt" style="font-size:26px; width:26px; height:26px;"></span>
                </div>
                <div>
                    <h1 style="margin:0; font-size:20px; font-weight:900; color:#333;"><?php esc_html_e('پروفایل من', 'reyhan-panel'); ?></h1>
                    <p style="margin:2px 0 0 0; font-size:13px; color:#777;"><?php esc_html_e('ویرایش اطلاعات شخصی و پاسخ‌های آماده', 'reyhan-panel'); ?></p>
                </div>
            </div>

            <div class="rp-hero-split-left">
                <button type="submit" class="rp-btn-primary-hero">
                    <span class="dashicons dashicons-saved"></span>
                    <?php esc_html_e('ذخیره تغییرات', 'reyhan-panel'); ?>
                </button>
            </div>
        </div>
        
        <?php if(isset($_GET['updated'])): ?>
            <div class="rp-toast-success">
                <span class="dashicons dashicons-yes-alt"></span> 
                <span><?php esc_html_e('تغییرات با موفقیت ذخیره شد.', 'reyhan-panel'); ?></span>
            </div>
        <?php endif; ?>

        <div class="rp-profile-body-grid">
            
            <div class="rp-mod-card">
                <div class="rp-mod-card-header">
                    <span class="dashicons dashicons-admin-users"></span>
                    <h3><?php esc_html_e('اطلاعات هویتی', 'reyhan-panel'); ?></h3>
                </div>
                <div class="rp-mod-card-body">
                    
                    <div class="rp-avatar-wrapper">
                        <div class="rp-mod-avatar-circle" onclick="document.getElementById('real_file_input').click()">
                            <img src="<?php echo esc_url($preview_src); ?>" id="agent-profile-img">
                            <div class="rp-mod-avatar-overlay">
                                <span class="dashicons dashicons-camera"></span>
                            </div>
                        </div>
                        <input type="file" name="agent_avatar_file" id="real_file_input" style="display:none;" accept="image/*" onchange="previewLocalImage(this)">
                        <input type="hidden" name="reyhan_user_avatar_status" id="avatar_status_input" value="kept">
                        
                        <div class="rp-upload-actions">
                            <button type="button" class="rp-btn-outline" onclick="document.getElementById('real_file_input').click()"><?php esc_html_e('تغییر عکس', 'reyhan-panel'); ?></button>
                            <?php if(!empty($avatar)): ?>
                                <button type="button" class="rp-btn-outline" style="color:#d32f2f; border-color:#ffcdd2;" id="btn-remove-sys-avatar"><?php esc_html_e('حذف', 'reyhan-panel'); ?></button>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="rp-identity-fields">
                        <div class="rp-field-group">
                            <label><?php esc_html_e('نام', 'reyhan-panel'); ?></label>
                            <input type="text" name="first_name" value="<?php echo esc_attr($fname); ?>" class="rp-mod-input" placeholder="<?php _e('نام...', 'reyhan-panel'); ?>">
                        </div>
                        <div class="rp-field-group">
                            <label><?php esc_html_e('نام خانوادگی', 'reyhan-panel'); ?></label>
                            <input type="text" name="last_name" value="<?php echo esc_attr($lname); ?>" class="rp-mod-input" placeholder="<?php _e('نام خانوادگی...', 'reyhan-panel'); ?>">
                        </div>
                        <div style="background:#f0f7ff; padding:10px; border-radius:8px; font-size:12px; color:#0d47a1; margin-top:20px;">
                            <span class="dashicons dashicons-info" style="font-size:16px; vertical-align:middle;"></span>
                            <?php esc_html_e('نام و تصویر به کاربر نمایش داده میشود.', 'reyhan-panel'); ?>
                        </div>
                    </div>

                </div>
            </div>

            <div class="rp-mod-card">
                <div class="rp-mod-card-header">
                    <span class="dashicons dashicons-format-chat"></span>
                    <h3><?php esc_html_e('پاسخ‌های آماده شخصی', 'reyhan-panel'); ?></h3>
                </div>
                <div class="rp-mod-card-body">
                    <p style="color:#666; font-size:13px; margin-bottom:20px; line-height:1.6;"><?php esc_html_e('جملاتی که زیاد استفاده می‌کنید را اینجا ذخیره کنید تا در صفحه چت با یک کلیک ارسال شوند.', 'reyhan-panel'); ?></p>
                    
                    <div class="rp-repeater-wrap" data-id="rp_user_canned_responses">
                        <div class="rp-canned-list-wrapper rp-repeater-list">
                            <?php if(!empty($canned)): foreach($canned as $idx => $item): ?>
                            <div class="rp-canned-item">
                                <div class="rp-drag-handle"><span class="dashicons dashicons-move"></span></div>
                                <div class="rp-canned-inputs">
                                    <div>
                                        <input type="text" name="reyhan_options[rp_user_canned_responses][<?php echo absint( $idx ); ?>][title]" value="<?php echo esc_attr($item['title']??''); ?>" class="rp-mod-input-sm" placeholder="<?php _e('عنوان پاسخ', 'reyhan-panel'); ?>">
                                    </div>
                                    <div>
                                        <textarea name="reyhan_options[rp_user_canned_responses][<?php echo absint( $idx ); ?>][content]" class="rp-mod-input-sm" placeholder="<?php _e('متن کامل پاسخ', 'reyhan-panel'); ?>"><?php echo esc_textarea($item['content']??''); ?></textarea>
                                    </div>
                                </div>
                                <button type="button" class="rp-btn-delete rp-remove-row-circle" title="<?php _e('حذف', 'reyhan-panel'); ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                </button>
                            </div>
                            <?php endforeach; endif; ?>
                        </div>
                        
                        <div style="margin-top:20px;">
                            <button type="button" class="rp-btn-add-canned rp-add-row-modern" data-fields='{"title":"","content":""}'>
                                <span class="dashicons dashicons-plus"></span> <?php esc_html_e('افزودن پاسخ آماده جدید', 'reyhan-panel'); ?>
                            </button>
                        </div>
                    </div>

                </div>
            </div>

        </div>

    </form>
</div>